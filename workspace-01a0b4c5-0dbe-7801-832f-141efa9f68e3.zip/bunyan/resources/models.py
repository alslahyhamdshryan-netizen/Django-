from django.db import models


class Worker(models.Model):
    WAGE_TYPES = [('day', 'يومي'), ('month', 'شهري'), ('project', 'بالأجرة للمشروع')]
    worker_no = models.CharField('رقم العامل', max_length=30, unique=True)
    name = models.CharField('اسم العامل', max_length=150)
    trade = models.CharField('المهنة', max_length=100, blank=True)
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    wage = models.DecimalField('الأجر', max_digits=14, decimal_places=2, default=0)
    wage_type = models.CharField('نوع الأجر', max_length=20, choices=WAGE_TYPES, default='day')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='workers', verbose_name='المشروع')
    active = models.BooleanField('مفعل', default=True)

    class Meta:
        verbose_name = 'العامل'
        verbose_name_plural = 'العمال'

    def __str__(self):
        return self.name

    @property
    def total_earned(self):
        from .services import worker_earnings
        return worker_earnings(self)

    @property
    def settlement(self):
        from .services import worker_settlement
        return worker_settlement(self)


class Attendance(models.Model):
    STATUSES = [('present', 'حاضر'), ('absent', 'غائب'), ('leave', 'إجازة')]
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='attendance', verbose_name='العامل')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                verbose_name='المشروع')
    date = models.DateField('التاريخ')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='present')
    hours = models.FloatField('الساعات', default=8)
    overtime_hours = models.FloatField('ساعات إضافية', default=0)
    overtime_rate = models.FloatField('معامل الإضافي', default=1.5)
    note = models.CharField('ملاحظة', max_length=200, blank=True)

    class Meta:
        verbose_name = 'سجل حضور'
        verbose_name_plural = 'سجلات الحضور'
        unique_together = ['worker', 'date']
        ordering = ['-date']

    def __str__(self):
        return f'{self.worker} — {self.date}'

    @property
    def day_pay(self):
        from .services import attendance_day_pay
        return attendance_day_pay(self)


class WorkerAdvance(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='advances', verbose_name='العامل')
    amount = models.DecimalField('المبلغ', max_digits=14, decimal_places=2)
    date = models.DateField('التاريخ')
    note = models.CharField('ملاحظة', max_length=200, blank=True)

    class Meta:
        verbose_name = 'سلفة'
        verbose_name_plural = 'السلف'

    def __str__(self):
        return f'سلفة {self.worker} — {self.amount}'


class WorkerDeduction(models.Model):
    worker = models.ForeignKey(Worker, on_delete=models.CASCADE, related_name='deductions', verbose_name='العامل')
    amount = models.DecimalField('المبلغ', max_digits=14, decimal_places=2)
    date = models.DateField('التاريخ')
    note = models.CharField('ملاحظة', max_length=200, blank=True)

    class Meta:
        verbose_name = 'خصم'
        verbose_name_plural = 'الخصومات'

    def __str__(self):
        return f'خصم {self.worker} — {self.amount}'


class Employee(models.Model):
    user = models.OneToOneField('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المستخدم')
    name = models.CharField('الاسم', max_length=150)
    department = models.ForeignKey('core.Department', null=True, blank=True, on_delete=models.SET_NULL,
                                   verbose_name='الإدارة')
    position = models.CharField('الوظيفة', max_length=100, blank=True)
    salary = models.DecimalField('الراتب الشهري', max_digits=14, decimal_places=2, default=0)
    branch = models.ForeignKey('core.Branch', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الفرع')
    join_date = models.DateField('تاريخ التعيين', null=True, blank=True)

    class Meta:
        verbose_name = 'الموظف'
        verbose_name_plural = 'الموظفون'

    def __str__(self):
        return self.name


class Equipment(models.Model):
    TYPES = [
        ('excavator', 'حفار'),
        ('mixer', 'خلاطة خرسانة'),
        ('generator', 'مولد كهرباء'),
        ('truck', 'شاحنة'),
        ('crane', 'رافعة'),
        ('other', 'أخرى'),
    ]
    STATUSES = [('available', 'متاح'), ('in_use', 'قيد الاستخدام'), ('maintenance', 'صيانة'), ('broken', 'معطل')]
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم المعدة', max_length=150)
    equipment_type = models.CharField('النوع', max_length=20, choices=TYPES, default='other')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='available')
    hourly_cost = models.DecimalField('تكلفة الساعة', max_digits=14, decimal_places=2, default=0)
    purchase_cost = models.DecimalField('ثمن الشراء', max_digits=16, decimal_places=2, null=True, blank=True)
    purchase_date = models.DateField('تاريخ الشراء', null=True, blank=True)
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='equipment', verbose_name='المشروع الحالي')

    class Meta:
        verbose_name = 'المعدة'
        verbose_name_plural = 'المعدات'

    def __str__(self):
        return self.name

    @property
    def total_hours(self):
        return self.logs.aggregate(s=models.Sum('hours'))['s'] or 0

    @property
    def total_cost(self):
        from .services import equipment_total_cost
        return equipment_total_cost(self)


class EquipmentLog(models.Model):
    """ساعة تشغيل + وقود + ملاحظة"""
    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE, related_name='logs', verbose_name='المعدة')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                verbose_name='المشروع')
    date = models.DateField('التاريخ')
    hours = models.FloatField('عدد الساعات', default=0)
    fuel_liters = models.FloatField('الوقود (لتر)', default=0)
    fuel_cost = models.DecimalField('تكلفة الوقود', max_digits=14, decimal_places=2, default=0)
    note = models.CharField('ملاحظة', max_length=200, blank=True)

    class Meta:
        verbose_name = 'سجل تشغيل'
        verbose_name_plural = 'سجلات التشغيل'
        ordering = ['-date']

    def __str__(self):
        return f'{self.equipment} — {self.date}'


class EquipmentMaintenance(models.Model):
    MTYPES = [('preventive', 'وقائية'), ('repair', 'إصلاح'), ('fault', 'عطل')]
    STATUSES = [('open', 'مفتوحة'), ('in_progress', 'قيد المعالجة'), ('closed', 'مغلقة')]
    equipment = models.ForeignKey(Equipment, on_delete=models.CASCADE, related_name='maintenances', verbose_name='المعدة')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                verbose_name='المشروع')
    mtype = models.CharField('النوع', max_length=20, choices=MTYPES, default='repair')
    description = models.TextField('الوصف')
    cost = models.DecimalField('التكلفة', max_digits=14, decimal_places=2, default=0)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    date = models.DateField('التاريخ')
    closed_at = models.DateField('تاريخ الإغلاق', null=True, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'صيانة معدة'
        verbose_name_plural = 'صيانة المعدات'

    def __str__(self):
        return f'صيانة {self.equipment} — {self.mtype}'


class Subcontractor(models.Model):
    """مقاول من الباطن (كهرباء، سباكة، ألمنيوم، دهان، بلاط، نجارة...)"""
    TRADES = [
        ('electrical', 'كهرباء'),
        ('plumbing', 'سباكة'),
        ('aluminum', 'ألمنيوم'),
        ('painting', 'دهان'),
        ('tiling', 'بلاط'),
        ('carpentry', 'نجارة'),
        ('hvac', 'تكييف'),
        ('other', 'أخرى'),
    ]
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم المقاول', max_length=200)
    trade = models.CharField('التخصص', max_length=20, choices=TRADES, default='other')
    contact_name = models.CharField('جهة الاتصال', max_length=150, blank=True)
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    address = models.CharField('العنوان', max_length=250, blank=True)
    rating = models.PositiveIntegerField('التقييم (0-5)', default=3)
    final_rating = models.PositiveIntegerField('التقييم النهائي (0-5)', null=True, blank=True)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'مقاول باطن'
        verbose_name_plural = 'المقاولون من الباطن'

    def __str__(self):
        return self.name

    @property
    def total_contracts(self):
        from django.db.models import Sum
        return self.contracts.filter(status__in=['active', 'completed'])\
            .aggregate(s=Sum('value'))['s'] or 0

    @property
    def total_paid(self):
        from finance.models import Payment
        from django.db.models import Sum
        return Payment.objects.filter(pay_type='outgoing', party_type='subcontractor',
                                      party_id=self.pk).aggregate(s=Sum('amount'))['s'] or 0

    @property
    def payable(self):
        return self.total_contracts - self.total_paid


class SubcontractorContract(models.Model):
    STATUSES = [('draft', 'مسودة'), ('active', 'نشط'), ('completed', 'منتهي'), ('closed', 'مغلق')]
    subcontractor = models.ForeignKey(Subcontractor, on_delete=models.CASCADE, related_name='contracts',
                                      verbose_name='المقاول')
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='subcontractor_contracts',
                                verbose_name='المشروع')
    scope = models.CharField('نطاق الأعمال', max_length=250)
    value = models.DecimalField('القيمة', max_digits=16, decimal_places=2, default=0)
    start_date = models.DateField('البداية', null=True, blank=True)
    end_date = models.DateField('النهاية', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')

    class Meta:
        verbose_name = 'عقد مقاول'
        verbose_name_plural = 'عقود المقاولين'

    def __str__(self):
        return f'{self.subcontractor.name} — {self.scope}'
