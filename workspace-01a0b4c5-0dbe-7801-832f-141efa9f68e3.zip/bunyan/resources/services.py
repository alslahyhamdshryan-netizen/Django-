"""خدمات الموارد: حساب مستحقات العمال وتكاليف المعدات."""
from decimal import Decimal

from django.db.models import Sum


def attendance_day_pay(att):
    """أجر اليوم = (الأجر الأساسي للساعة × الساعات) + (الإضافي × المعامل)."""
    if att.status != 'present':
        return Decimal('0')
    worker = att.worker
    if worker is None:
        return Decimal('0')
    base_day = worker.wage if worker.wage_type == 'day' else (worker.wage / 30)
    pay = base_day * Decimal(str(att.hours or 0)) / 8
    ot = base_day * Decimal(str(att.overtime_hours or 0)) / 8 * Decimal(str(att.overtime_rate or 1))
    return (pay + ot)


def worker_earnings(worker):
    from .models import Attendance
    return sum((a.day_pay for a in Attendance.objects.filter(worker=worker)), Decimal('0'))


def worker_settlement(worker):
    earned = worker_earnings(worker)
    advances = worker.advances.aggregate(s=Sum('amount'))['s'] or Decimal('0')
    deductions = worker.deductions.aggregate(s=Sum('amount'))['s'] or Decimal('0')
    return {
        'earned': earned,
        'advances': advances,
        'deductions': deductions,
        'net': earned - advances - deductions,
    }


def equipment_total_cost(eq):
    """تكلفة تشغيل المعدة = ساعات × تكلفة الساعة + وقود + صيانة."""
    fuel = eq.logs.aggregate(s=Sum('fuel_cost'))['s'] or Decimal('0')
    maint = eq.maintenances.aggregate(s=Sum('cost'))['s'] or Decimal('0')
    hours_cost = Decimal(str(eq.total_hours or 0)) * (eq.hourly_cost or 0)
    return hours_cost + fuel + maint
