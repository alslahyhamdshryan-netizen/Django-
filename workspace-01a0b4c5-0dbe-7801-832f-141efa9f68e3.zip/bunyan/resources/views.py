from decimal import Decimal

from django import forms
from django.shortcuts import get_object_or_404, redirect, render

from core.crud import crud as _crud
from core.utils import field_list, row_for
from .models import (Attendance, Employee, Equipment, EquipmentLog,
                     EquipmentMaintenance, Subcontractor,
                     SubcontractorContract, Worker, WorkerAdvance, WorkerDeduction)
from .services import equipment_total_cost, worker_settlement

worker_list, worker_create, worker_update = _crud(
    Worker, 'العمال', ['worker_no', 'name', 'trade', 'phone', 'wage', 'wage_type', 'project', 'active'])
attendance_list, attendance_create, attendance_update = _crud(
    Attendance, 'سجلات الحضور', ['worker', 'project', 'date', 'status', 'hours', 'overtime_hours', 'note'],
    order_by=['-date'])
advance_list, advance_create, advance_update = _crud(
    WorkerAdvance, 'السلف', ['worker', 'amount', 'date', 'note'])
deduction_list, deduction_create, deduction_update = _crud(
    WorkerDeduction, 'الخصومات', ['worker', 'amount', 'date', 'note'])
employee_list, employee_create, employee_update = _crud(
    Employee, 'الموظفون', ['name', 'position', 'department', 'salary', 'branch'])
equipment_list, equipment_create, equipment_update = _crud(
    Equipment, 'المعدات', ['code', 'name', 'equipment_type', 'status', 'hourly_cost', 'project'])
maint_list, maint_create, maint_update = _crud(
    EquipmentMaintenance, 'صيانة المعدات', ['equipment', 'mtype', 'description', 'cost', 'status', 'date'],
    order_by=['-date'])

subcontractor_list, subcontractor_create, subcontractor_update = _crud(
    Subcontractor, 'المقاولون من الباطن',
    ['code', 'name', 'trade', 'contact_name', 'phone', 'rating', 'final_rating'])
subcontractor_contract_list, subcontractor_contract_create, subcontractor_contract_update = _crud(
    SubcontractorContract, 'عقود المقاولين',
    ['subcontractor', 'project', 'scope', 'value', 'start_date', 'end_date', 'status'])


def subcontractor_detail(request, pk):
    from finance.models import Payment
    sc = get_object_or_404(Subcontractor, pk=pk)
    payments = Payment.objects.filter(pay_type='outgoing', party_type='subcontractor',
                                      party_id=sc.pk).order_by('-date')
    if request.method == 'POST' and request.POST.get('form') == 'rating':
        sc.rating = int(request.POST.get('rating') or 0)
        if request.POST.get('final'):
            sc.final_rating = int(request.POST.get('rating') or 0)
        sc.save()
        return redirect(f'/resources/subcontractors/{sc.pk}/')
    return render(request, 'resources/subcontractor_detail.html', {
        'page_title': sc.name,
        'sc': sc,
        'contracts': sc.contracts.all(),
        'payments': payments,
        'total_contracts': sc.total_contracts,
        'total_paid': sc.total_paid,
        'payable': sc.payable,
    })


def worker_detail(request, pk):
    w = get_object_or_404(Worker, pk=pk)
    s = worker_settlement(w)
    if request.method == 'POST' and request.POST.get('form') == 'attendance':
        a = Attendance(worker=w, project=w.project,
                       date=request.POST.get('date'),
                       status=request.POST.get('status', 'present'),
                       hours=float(request.POST.get('hours') or 8),
                       overtime_hours=float(request.POST.get('overtime_hours') or 0),
                       overtime_rate=float(request.POST.get('overtime_rate') or 1.5),
                       note=request.POST.get('note', ''))
        a.save()
        return redirect(f'/resources/workers/{w.pk}/')
    atts = w.attendance.all()[:30]
    return render(request, 'resources/worker_detail.html', {
        'page_title': w.name,
        'worker': w,
        'settlement': s,
        'attendance': atts,
        'advances': w.advances.all(),
        'deductions': w.deductions.all(),
    })


def equipment_detail(request, pk):
    e = get_object_or_404(Equipment, pk=pk)
    logs = e.logs.all()[:30]
    total_fuel = sum((l.fuel_cost for l in logs), 0)
    return render(request, 'resources/equipment_detail.html', {
        'page_title': e.name,
        'equipment': e,
        'logs': logs,
        'maintenances': e.maintenances.all(),
        'total_cost': equipment_total_cost(e),
        'total_fuel': total_fuel,
        'hours_cost': Decimal(str(e.total_hours or 0)) * (e.hourly_cost or 0),
    })


class EquipmentLogForm(forms.ModelForm):
    class Meta:
        model = EquipmentLog
        fields = '__all__'


def eq_log_form(request, pk=None):
    l = get_object_or_404(EquipmentLog, pk=pk) if pk else None
    if request.method == 'POST':
        form = EquipmentLogForm(request.POST, instance=l)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/resources/equipment/{obj.equipment_id}/')
    else:
        form = EquipmentLogForm(instance=l)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل سجل تشغيل' if l else 'إضافة سجل تشغيل (ساعات/وقود)', 'form': form})
