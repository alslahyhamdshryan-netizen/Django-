from django.urls import path

from . import views

app_name = 'resources'

urlpatterns = [
    path('workers/', views.worker_list, name='worker_list'),
    path('workers/add/', views.worker_create, name='worker_create'),
    path('workers/<int:pk>/', views.worker_detail, name='worker_detail'),
    path('workers/<int:pk>/edit/', views.worker_update, name='worker_update'),
    path('attendance/', views.attendance_list, name='attendance_list'),
    path('attendance/add/', views.attendance_create, name='attendance_create'),
    path('attendance/<int:pk>/edit/', views.attendance_update, name='attendance_update'),
    path('advances/', views.advance_list, name='advance_list'),
    path('advances/add/', views.advance_create, name='advance_create'),
    path('advances/<int:pk>/edit/', views.advance_update, name='advance_update'),
    path('deductions/', views.deduction_list, name='deduction_list'),
    path('deductions/add/', views.deduction_create, name='deduction_create'),
    path('deductions/<int:pk>/edit/', views.deduction_update, name='deduction_update'),
    path('employees/', views.employee_list, name='employee_list'),
    path('employees/add/', views.employee_create, name='employee_create'),
    path('employees/<int:pk>/edit/', views.employee_update, name='employee_update'),
    path('equipment/', views.equipment_list, name='equipment_list'),
    path('equipment/add/', views.equipment_create, name='equipment_create'),
    path('equipment/<int:pk>/', views.equipment_detail, name='equipment_detail'),
    path('equipment/<int:pk>/edit/', views.equipment_update, name='equipment_update'),
    path('equipment-logs/', views.eq_log_form, name='eq_log_create'),
    path('equipment-logs/add/', views.eq_log_form, name='eq_log_add'),
    path('equipment-logs/<int:pk>/edit/', views.eq_log_form, name='eq_log_update'),
    path('maintenance/', views.maint_list, name='maint_list'),
    path('maintenance/add/', views.maint_create, name='maint_create'),
    path('maintenance/<int:pk>/edit/', views.maint_update, name='maint_update'),
    path('subcontractors/', views.subcontractor_list, name='subcontractor_list'),
    path('subcontractors/add/', views.subcontractor_create, name='subcontractor_create'),
    path('subcontractors/<int:pk>/', views.subcontractor_detail, name='subcontractor_detail'),
    path('subcontractors/<int:pk>/edit/', views.subcontractor_update, name='subcontractor_update'),
    path('subcontractor-contracts/add/', views.subcontractor_contract_create, name='subcontractor_contract_create'),
    path('subcontractor-contracts/<int:pk>/edit/', views.subcontractor_contract_update, name='subcontractor_contract_update'),
]
