from django.urls import path

from . import views

app_name = 'crm'

urlpatterns = [
    path('clients/', views.client_list, name='client_list'),
    path('clients/add/', views.client_create, name='client_create'),
    path('clients/<int:pk>/', views.client_detail, name='client_detail'),
    path('clients/<int:pk>/edit/', views.client_update, name='client_update'),
    path('contacts/', views.contact_list, name='contact_list'),
    path('contacts/add/', views.contact_create, name='contact_create'),
    path('contacts/<int:pk>/edit/', views.contact_update, name='contact_update'),
    path('communications/', views.comm_list, name='comm_list'),
    path('communications/add/', views.comm_create, name='comm_create'),
]
