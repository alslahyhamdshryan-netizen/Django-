from django.db import models


class Client(models.Model):
    CLIENT_TYPES = [
        ('individual', 'فرد'),
        ('company', 'شركة'),
        ('government', 'جهة حكومية'),
    ]
    name = models.CharField('اسم العميل', max_length=200)
    client_type = models.CharField('نوع العميل', max_length=20, choices=CLIENT_TYPES, default='company')
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    email = models.EmailField('البريد الإلكتروني', blank=True)
    address = models.CharField('العنوان', max_length=250, blank=True)
    tax_no = models.CharField('الرقم الضريبي', max_length=50, blank=True)
    credit_limit = models.DecimalField('الحد الائتماني', max_digits=16, decimal_places=2, null=True, blank=True)
    notes = models.TextField('ملاحظات', blank=True)
    created = models.DateTimeField('تاريخ التسجيل', auto_now_add=True)

    class Meta:
        verbose_name = 'العميل'
        verbose_name_plural = 'العملاء'

    def __str__(self):
        return self.name

    @property
    def receivable(self):
        from finance.services import client_receivable
        return client_receivable(self)


class Contact(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='contacts', verbose_name='العميل')
    name = models.CharField('الاسم', max_length=150)
    title = models.CharField('المسمى الوظيفي', max_length=100, blank=True)
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    email = models.EmailField('البريد الإلكتروني', blank=True)

    class Meta:
        verbose_name = 'جهة الاتصال'
        verbose_name_plural = 'جهات الاتصال'

    def __str__(self):
        return self.name


class Communication(models.Model):
    COMM_TYPES = [
        ('call', 'مكالمة'),
        ('email', 'بريد إلكتروني'),
        ('meeting', 'اجتماع'),
        ('letter', 'مراسلة'),
        ('visit', 'زيارة'),
    ]
    DIRECTIONS = [('in', 'وارد'), ('out', 'صادر')]
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='communications', verbose_name='العميل')
    comm_type = models.CharField('النوع', max_length=20, choices=COMM_TYPES, default='call')
    direction = models.CharField('الاتجاه', max_length=10, choices=DIRECTIONS, default='out')
    subject = models.CharField('الموضوع', max_length=250, blank=True)
    body = models.TextField('المحتوى', blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                             verbose_name='بواسطة')
    comm_date = models.DateField('التاريخ')

    class Meta:
        verbose_name = 'مراسلة'
        verbose_name_plural = 'المراسلات'
        ordering = ['-comm_date']

    def __str__(self):
        return f'{self.get_comm_type_display()} — {self.subject or self.client}'
