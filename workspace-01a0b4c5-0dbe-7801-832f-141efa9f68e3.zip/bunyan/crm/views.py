from django.shortcuts import get_object_or_404, render

from core.crud import crud
from .models import Client, Communication, Contact

client_list, client_create, client_update = crud(
    Client, 'العملاء', ['name', 'client_type', 'phone', 'address', 'credit_limit'],
    detail='crm:client_detail', create='crm:client_create')
contact_list, contact_create, contact_update = crud(
    Contact, 'جهات الاتصال', ['client', 'name', 'title', 'phone'], order_by=['id'])
comm_list, comm_create, comm_update = crud(
    Communication, 'المراسلات', ['client', 'comm_type', 'direction', 'subject', 'comm_date'],
    order_by=['-comm_date'])


def client_detail(request, pk):
    from contracts.models import Quote
    from finance.models import Payment
    from finance.services import client_receivable

    c = get_object_or_404(Client, pk=pk)
    receivable = client_receivable(c)
    invoices = c.invoices.all()[:10]
    payments = Payment.objects.filter(pay_type='incoming')\
        .filter(project__client=c).order_by('-date')[:10]
    quotes = Quote.objects.filter(project__client=c)
    return render(request, 'crm/client_detail.html', {
        'page_title': c.name,
        'client': c,
        'receivable': receivable,
        'projects': c.projects.all(),
        'quotes': quotes,
        'invoices': invoices,
        'payments': payments,
        'communications': c.communications.all()[:10],
    })
