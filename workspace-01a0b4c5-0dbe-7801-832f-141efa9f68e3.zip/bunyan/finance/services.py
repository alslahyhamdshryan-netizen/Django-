"""الخدمات المالية: الربط بين العمليات، المراقبة المالية للمشروع، التقارير."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Q, Sum
from django.utils import timezone


def record_expense(project=None, stage=None, category='other', amount=0,
                   description='', date=None, user=None, **refs):
    from .models import Expense
    data = dict(project=project, stage=stage, category=category, amount=amount,
                description=description, date=date or timezone.localdate(), user=user)
    data.update({k: v for k, v in refs.items() if k in
                 ('account', 'supplier', 'worker', 'po', 'issue')})
    return Expense.objects.create(**data)


def record_income(project=None, category='other', amount=0, description='',
                  date=None, user=None):
    from .models import Income
    return Income.objects.create(
        project=project, category=category, amount=amount,
        description=description, date=date or timezone.localdate(), user=user)


def apply_payment(payment):
    """آثار تسجيل دفعة جديدة على بقية الوحدات."""
    from .models import Income

    if payment.pay_type == 'incoming':
        # 1) إيراد
        record_income(project=payment.project, category='client_payment',
                      amount=payment.amount,
                      description=f'دفعة عميل — {payment.reference or payment.note or str(payment.contract or payment.project or "")}',
                      date=payment.date, user=payment.user)
        # 2) مستخلص: تحديث المدفوع
        if payment.statement_id:
            st = payment.statement
            st.paid_amount = (st.paid_amount or 0) + payment.amount
            st.status = 'paid' if st.paid_amount >= st.net else 'partial'
            st.save()
        # 3) فاتورة عميل
        if payment.invoice_id:
            inv = payment.invoice
            inv.paid_amount = (inv.paid_amount or 0) + payment.amount
            inv.status = 'paid' if inv.paid_amount >= inv.total else 'partial'
            inv.save()
        # 4) جدول دفعات العقد (FIFO على الدفعات غير المسددة)
        if payment.contract_id:
            remaining = payment.amount
            for s in payment.contract.schedules.filter(status__in=['open', 'partial']).order_by('seq'):
                if remaining <= 0:
                    break
                unpaid = s.amount - (s.paid_amount or 0)
                pay = min(unpaid, remaining)
                s.paid_amount = (s.paid_amount or 0) + pay
                s.status = 'paid' if s.paid_amount >= s.amount else 'partial'
                s.save()
                remaining -= pay

    else:  # outgoing
        # فاتورة مورد
        if payment.pi_id:
            pi = payment.pi
            pi.paid_amount = (pi.paid_amount or 0) + payment.amount
            pi.status = 'paid' if pi.paid_amount >= pi.total else 'partial'
            pi.save()


def project_financials(project):
    """المراقبة المالية الكاملة للمشروع (الميزانية مقابل الفعلي مقابل المتوقع عند الإنهاء)."""
    from projects.services import boq_totals, project_progress
    from .models import Expense, Payment, Statement

    contract = project.contract
    contract_value = contract.value if contract else Decimal('0')
    planned_cost, _price, _exp = boq_totals(project)

    actual_cost = Expense.objects.filter(project=project).aggregate(s=Sum('amount'))['s'] or Decimal('0')

    work_value = Decimal('0')
    for st in Statement.objects.filter(project=project, status__in=['approved', 'partial', 'paid']):
        work_value += st.net

    received = Payment.objects.filter(pay_type='incoming', project=project)\
        .aggregate(s=Sum('amount'))['s'] or Decimal('0')
    paid_out = Payment.objects.filter(pay_type='outgoing', project=project)\
        .aggregate(s=Sum('amount'))['s'] or Decimal('0')

    progress = float(project_progress(project))
    remaining_cost = planned_cost * (Decimal('1') - Decimal(str(progress)) / 100)
    forecast_cost = actual_cost + remaining_cost  # التكلفة المتوقعة عند النهاية
    expected_profit = contract_value - forecast_cost  # الربح المتوقع عند الانتهاء
    current_profit = received - actual_cost  # الربح الفعلي حتى الآن

    return {
        'contract': contract,
        'contract_value': contract_value,
        'budget': contract_value,
        'planned_cost': planned_cost,
        'actual_cost': actual_cost,
        'work_value': work_value,
        'received': received,
        'paid_out': paid_out,
        'progress': progress,
        'remaining_cost': remaining_cost,
        'forecast_cost': forecast_cost,
        'expected_profit': expected_profit,
        'current_profit': current_profit,
    }


def client_receivable(client):
    """مستحق على العميل = قيمة عقوده (+ أوامر التغيير المطبقة) − إجمالي ما سدّده."""
    from .models import Payment
    from contracts.models import Contract
    contracts = Contract.objects.filter(project__client=client)
    total_value = contracts.aggregate(s=Sum('value'))['s'] or Decimal('0')
    received = Payment.objects.filter(pay_type='incoming').filter(
        Q(project__client=client) | Q(contract__project__client=client)
    ).aggregate(s=Sum('amount'))['s'] or Decimal('0')
    return total_value - received


def supplier_payable(supplier):
    """مستحقات المورد = فواتيره − المسدّد."""
    from procurement.models import PurchaseInvoice
    invoices = PurchaseInvoice.objects.filter(supplier=supplier)
    total = invoices.aggregate(s=Sum('total'))['s'] or Decimal('0')
    paid = invoices.aggregate(s=Sum('paid_amount'))['s'] or Decimal('0')
    return total - paid


def statement_net(st):
    return st.subtotal - (st.discount or 0) - (st.deductions or 0)


def approve_statement(st, user=None):
    """اعتماد المستخلص: ينشئ فاتورة للعميل (إن لم توجد) ويحدّث المديونية والإيرادات."""
    from .models import Invoice
    st.approved_by = user
    st.approved_at = timezone.now()
    if st.status not in ('approved', 'partial', 'paid'):
        st.status = 'approved'
    st.save()
    if not st.invoices.exists():
        Invoice.objects.create(
            invoice_no=f'INV-{st.statement_no}',
            project=st.project,
            contract=st.contract,
            client=st.project.client,
            statement=st,
            subtotal=st.subtotal,
            discount=st.discount or 0,
            tax=0,
            total=st.net,
            status='issued',
            issue_date=timezone.localdate(),
            due_date=timezone.localdate() + timedelta(days=15),
        )
    return st


def pnl(start=None, end=None):
    """قائمة الأرباح والخسائر المصغرة (نقدي) مع تفصيل المصروفات حسب التصنيف."""
    from .models import Expense, Income
    qs_i = Income.objects.all()
    qs_e = Expense.objects.all()
    if start:
        qs_i = qs_i.filter(date__gte=start)
        qs_e = qs_e.filter(date__gte=start)
    if end:
        qs_i = qs_i.filter(date__lte=end)
        qs_e = qs_e.filter(date__lte=end)
    income_total = qs_i.aggregate(s=Sum('amount'))['s'] or Decimal('0')
    expense_total = qs_e.aggregate(s=Sum('amount'))['s'] or Decimal('0')
    by_expense = {}
    for cat, _label in Expense.CATEGORIES:
        by_expense[cat] = qs_e.filter(category=cat).aggregate(s=Sum('amount'))['s'] or Decimal('0')
    by_income = {}
    for cat, _label in Income.CATEGORIES:
        by_income[cat] = qs_i.filter(category=cat).aggregate(s=Sum('amount'))['s'] or Decimal('0')
    return {
        'income_total': income_total,
        'expense_total': expense_total,
        'profit': income_total - expense_total,
        'by_expense': by_expense,
        'by_income': by_income,
    }


def cashflow(start=None, end=None):
    """التدفق النقدي شهريًا: وارد − صادر."""
    from .models import Payment
    if start is None:
        start = (timezone.localdate() - timedelta(days=180)).replace(day=1)
    if end is None:
        end = timezone.localdate()
    data = {}
    for p in Payment.objects.filter(date__gte=start, date__lte=end):
        key = p.date.strftime('%Y-%m')
        d = data.setdefault(key, {'in': Decimal('0'), 'out': Decimal('0')})
        d['in' if p.pay_type == 'incoming' else 'out'] += p.amount
    rows = []
    for key in sorted(data, reverse=True):
        d = data[key]
        rows.append({'month': key, 'in': d['in'], 'out': d['out'], 'net': d['in'] - d['out']})
    return rows


def clients_receivable():
    from crm.models import Client
    out = []
    for c in Client.objects.all():
        r = client_receivable(c)
        if r != 0:
            out.append((c, r))
    return out


def suppliers_payable():
    from procurement.models import Supplier
    out = []
    for s in Supplier.objects.all():
        r = supplier_payable(s)
        if r != 0:
            out.append((s, r))
    return out


def subcontractor_payable(sc):
    """مستحق على المقاول = قيمة عقود النشطة/المنتهية − المسدَّد له."""
    return sc.payable


def subcontractors_payable():
    from resources.models import Subcontractor
    out = []
    for sc in Subcontractor.objects.all():
        r = sc.payable
        if r != 0:
            out.append((sc, r))
    return out
