from django import forms
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.crud import crud as _crud
from core.decorators import roles
from core.utils import field_list, row_for
from .models import (Account, Expense, Income, Invoice, Payment, Statement,
                     StatementItem)
from .services import (approve_statement, cashflow, clients_receivable, pnl,
                       project_financials, record_expense, record_income,
                       suppliers_payable)

expense_list, expense_create, expense_update = _crud(
    Expense, 'المصروفات', ['date', 'project', 'stage', 'category', 'supplier', 'amount', 'description'],
    order_by=['-date'])
income_list, income_create, income_update = _crud(
    Income, 'الإيرادات', ['date', 'project', 'category', 'amount', 'description'],
    order_by=['-date'])
account_list, account_create, account_update = _crud(
    Account, 'الحسابات', ['code', 'name', 'acc_type', 'parent'])


# ---------- المستخلصات ----------
def statement_list(request):
    columns = field_list(Statement, ['statement_no', 'project', 'period_start', 'period_end',
                                     'subtotal', 'net', 'paid_amount', 'status'])
    qs = Statement.objects.select_related('project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'المستخلصات', 'columns': columns,
        'create_url': 'finance:statement_create', 'create_label': 'إضافة مستخلص',
        'rows': [row_for(s, columns, f'/finance/statements/{s.pk}/') for s in qs]})


class StatementForm(forms.ModelForm):
    class Meta:
        model = Statement
        fields = ['statement_no', 'project', 'contract', 'period_start', 'period_end',
                  'subtotal', 'discount', 'deductions', 'notes']


def statement_form(request, pk=None):
    s = get_object_or_404(Statement, pk=pk) if pk else None
    if request.method == 'POST':
        form = StatementForm(request.POST, instance=s)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.statement_no = obj.statement_no or f'ST-{Statement.objects.count() + 1:03d}'
            obj.save()
            return redirect(f'/finance/statements/{obj.pk}/')
    else:
        form = StatementForm(instance=s,
                             initial={} if s else {'statement_no': f'ST-{Statement.objects.count() + 1:03d}'})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل مستخلص' if s else 'إضافة مستخلص', 'form': form})


class StatementItemForm(forms.ModelForm):
    class Meta:
        model = StatementItem
        fields = '__all__'


def statement_item_form(request, pk=None):
    it = get_object_or_404(StatementItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = StatementItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            st = obj.statement
            st.subtotal = sum((i.line_total for i in st.items.all()), 0)
            st.save()
            return redirect(f'/finance/statements/{st.pk}/')
    else:
        form = StatementItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند مستخلص' if it else 'إضافة بند لمستخلص', 'form': form})


def statement_detail(request, pk):
    s = get_object_or_404(Statement, pk=pk)
    items = s.items.select_related('boq_item')
    return render(request, 'finance/statement_detail.html', {
        'page_title': f'المستخلص {s.statement_no}',
        'statement': s,
        'items': items,
        'net': s.net,
        'payments': s.payments.all(),
        'invoices': s.invoices.all(),
    })


@roles('admin', 'pm', 'accountant')
def statement_approve(request, pk):
    """اعتماد المستخلص: إنشاء فاتورة + تحديث مديونية العميل + الإيرادات."""
    s = get_object_or_404(Statement, pk=pk)
    if request.method == 'POST':
        approve_statement(s, user=request.user)
    return redirect(f'/finance/statements/{s.pk}/')


# ---------- الدفعات ----------
class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['pay_type', 'party_type', 'party_id', 'project', 'contract', 'statement',
                  'invoice', 'pi', 'worker', 'date', 'amount', 'method', 'reference', 'note']


def payment_list(request):
    columns = field_list(Payment, ['date', 'pay_type', 'party_type', 'project', 'contract',
                                   'statement', 'amount', 'method', 'reference', 'note'])
    qs = Payment.objects.select_related('project').order_by('-date', '-id')
    if request.GET.get('type'):
        qs = qs.filter(pay_type=request.GET['type'])
    return render(request, 'core/generic_list.html', {
        'page_title': 'الدفعات', 'columns': columns,
        'create_url': 'finance:payment_create', 'create_label': 'تسجيل دفعة',
        'rows': [row_for(p, columns) for p in qs]})


def payment_form(request, pk=None):
    p = get_object_or_404(Payment, pk=pk) if pk else None
    if request.method == 'POST':
        form = PaymentForm(request.POST, instance=p)
        if form.is_valid():
            obj = form.save(commit=False)
            if obj.user_id is None:
                obj.user = request.user
            obj.save()  # يُطلق آثار الدفعة (إيرادات/مديونيات/جداول الدفع)
            return redirect('finance:payment_list')
    else:
        form = PaymentForm(instance=p)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل دفعة' if p else 'تسجيل دفعة (واردة/صادرة)', 'form': form})


# ---------- فواتير العملاء ----------
class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ['invoice_no', 'project', 'contract', 'client', 'statement',
                  'subtotal', 'discount', 'tax', 'total', 'status', 'issue_date', 'due_date']


def invoice_detail(request, pk):
    i = get_object_or_404(Invoice, pk=pk)
    return render(request, 'finance/invoice_detail.html', {
        'page_title': f'الفاتورة {i.invoice_no}',
        'invoice': i,
        'payments': i.payments.all(),
    })


def invoice_print(request, pk):
    i = get_object_or_404(Invoice, pk=pk)
    items = i.statement.items.all() if i.statement_id else []
    return render(request, 'finance/print_invoice.html', {
        'invoice': i,
        'items': items,
        'remaining': i.total - (i.paid_amount or 0),
        'print_date': timezone.localdate(),
    })


def statement_print(request, pk):
    s = get_object_or_404(Statement, pk=pk)
    return render(request, 'finance/print_statement.html', {
        'statement': s,
        'items': s.items.all(),
        'net': s.net,
        'payments': s.payments.all(),
        'print_date': timezone.localdate(),
    })


def invoice_list(request):
    columns = field_list(Invoice, ['invoice_no', 'client', 'issue_date', 'due_date',
                                   'total', 'paid_amount', 'status'])
    qs = Invoice.objects.select_related('client').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'فواتير العملاء', 'columns': columns,
        'create_url': 'finance:invoice_create', 'create_label': 'إضافة فاتورة',
        'rows': [row_for(i, columns, f'/finance/invoices/{i.pk}/') for i in qs]})


def invoice_form(request, pk=None):
    i = get_object_or_404(Invoice, pk=pk) if pk else None
    if request.method == 'POST':
        form = InvoiceForm(request.POST, instance=i)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.invoice_no = obj.invoice_no or f'INV-{Invoice.objects.count() + 1:03d}'
            obj.save()
            return redirect('finance:invoice_list')
    else:
        form = InvoiceForm(instance=i, initial={} if i else {'invoice_no': f'INV-{Invoice.objects.count() + 1:03d}'})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل فاتورة' if i else 'إضافة فاتورة عميل', 'form': form})


# ---------- التقارير ----------
def reports_view(request):
    from projects.models import Project
    start = timezone.localdate()
    end = timezone.localdate()
    if request.GET.get('start'):
        from django.utils.dateparse import parse_date
        start = parse_date(request.GET['start']) or start
    if request.GET.get('end'):
        from django.utils.dateparse import parse_date
        end = parse_date(request.GET['end']) or end

    p = pnl(start, end)
    cf = cashflow(start, end)
    debtors = clients_receivable()
    payables = suppliers_payable()
    from .services import subcontractors_payable
    sub_payables = subcontractors_payable()

    projects_rows = []
    for pr in Project.objects.all():
        f = project_financials(pr)
        projects_rows.append({'project': pr, **f})

    return render(request, 'finance/reports.html', {
        'page_title': 'التقارير المالية',
        'start': start, 'end': end,
        'pnl': p,
        'cashflow': cf,
        'debtors': debtors,
        'payables': payables,
        'sub_payables': sub_payables,
        'projects_rows': projects_rows,
    })


def report_csv(request):
    which = request.GET.get('report', 'costs')
    from projects.models import Project
    if which == 'projects':
        rows = [['المشروع', 'قيمة العقد', 'التكلفة المخططة', 'التكلفة الفعلية',
                 'قيمة الأعمال', 'المقبوضات', 'الربح الحالي', 'الربح المتوقع عند الإنهاء', 'الإنجاز %']]
        for pr in Project.objects.all():
            f = project_financials(pr)
            rows.append([pr.name, f'{f["contract_value"]}', f'{f["planned_cost"]}',
                         f'{f["actual_cost"]}', f'{f["work_value"]}', f'{f["received"]}',
                         f'{f["current_profit"]}', f'{f["expected_profit"]}', f'{f["progress"]:.0f}'])
    elif which == 'costs':
        rows = [['التصنيف', 'المبلغ']]
        p = pnl()
        for cat, _l in Expense.CATEGORIES:
            rows.append([cat, f'{p["by_expense"][cat]}'])
    elif which == 'debtors':
        rows = [['العميل', 'المستحق عليه']]
        rows.extend([[c.name, f'{r}'] for c, r in clients_receivable()])
    else:
        rows = [['الشهر', 'وارد', 'صادر', 'صافي']]
        rows.extend([[r['month'], f'{r["in"]}', f'{r["out"]}', f'{r["net"]}'] for r in cashflow()])
    resp = HttpResponse(content_type='text/csv; charset=utf-8')
    resp['Content-Disposition'] = f'attachment; filename="{which}.csv"'
    resp.write('\ufeff' + '\n'.join(','.join(r) for r in rows))
    return resp
