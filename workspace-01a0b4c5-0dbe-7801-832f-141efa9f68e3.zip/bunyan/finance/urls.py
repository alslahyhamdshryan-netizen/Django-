from django.urls import path

from . import views

app_name = 'finance'

urlpatterns = [
    path('statements/', views.statement_list, name='statement_list'),
    path('statements/add/', views.statement_form, name='statement_create'),
    path('statements/<int:pk>/', views.statement_detail, name='statement_detail'),
    path('statements/<int:pk>/edit/', views.statement_form, name='statement_update'),
    path('statements/<int:pk>/approve/', views.statement_approve, name='statement_approve'),
    path('statement-items/add/', views.statement_item_form, name='statement_item_create'),
    path('statement-items/<int:pk>/edit/', views.statement_item_form, name='statement_item_update'),
    path('payments/', views.payment_list, name='payment_list'),
    path('payments/add/', views.payment_form, name='payment_create'),
    path('payments/<int:pk>/edit/', views.payment_form, name='payment_update'),
    path('invoices/', views.invoice_list, name='invoice_list'),
    path('invoices/add/', views.invoice_form, name='invoice_create'),
    path('invoices/<int:pk>/', views.invoice_detail, name='invoice_detail'),
    path('invoices/<int:pk>/edit/', views.invoice_form, name='invoice_update'),
    path('invoices/<int:pk>/print/', views.invoice_print, name='invoice_print'),
    path('statements/<int:pk>/print/', views.statement_print, name='statement_print'),
    path('expenses/', views.expense_list, name='expense_list'),
    path('expenses/add/', views.expense_create, name='expense_create'),
    path('expenses/<int:pk>/edit/', views.expense_update, name='expense_update'),
    path('income/', views.income_list, name='income_list'),
    path('income/add/', views.income_create, name='income_create'),
    path('income/<int:pk>/edit/', views.income_update, name='income_update'),
    path('accounts/', views.account_list, name='account_list'),
    path('accounts/add/', views.account_create, name='account_create'),
    path('reports/', views.reports_view, name='reports'),
    path('reports/csv/', views.report_csv, name='report_csv'),
]
