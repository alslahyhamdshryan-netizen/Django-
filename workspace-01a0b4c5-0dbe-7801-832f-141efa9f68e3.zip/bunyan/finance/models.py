from django.db import models


class Account(models.Model):
    TYPES = [('income', 'إيراد'), ('expense', 'مصروف'), ('asset', 'أصل'), ('liability', 'التزام'), ('equity', 'حقوق ملكية')]
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم الحساب', max_length=150)
    acc_type = models.CharField('النوع', max_length=20, choices=TYPES, default='expense')
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE,
                               related_name='children', verbose_name='الحساب الأب')

    class Meta:
        verbose_name = 'الحساب'
        verbose_name_plural = 'الحسابات'

    def __str__(self):
        return f'{self.code} — {self.name}'


class Payment(models.Model):
    """دفعة واردة (عميل) أو صادرة (مورد/عامل/مقاول)"""
    PAY_TYPES = [('incoming', 'واردة'), ('outgoing', 'صادرة')]
    PARTY_TYPES = [('client', 'عميل'), ('supplier', 'مورد'), ('worker', 'عامل'), ('subcontractor', 'مقاول باطن'), ('other', 'أخرى')]
    METHODS = [('cash', 'نقدي'), ('bank', 'تحويل بنكي'), ('transfer', 'حوالة'), ('cheque', 'شيك')]
    pay_type = models.CharField('نوع الدفعة', max_length=10, choices=PAY_TYPES)
    party_type = models.CharField('الطرف', max_length=20, choices=PARTY_TYPES, default='other')
    party_id = models.PositiveIntegerField('معرّف الطرف', null=True, blank=True)
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='payments', verbose_name='المشروع')
    contract = models.ForeignKey('contracts.Contract', null=True, blank=True, on_delete=models.SET_NULL,
                                 related_name='payments', verbose_name='العقد')
    statement = models.ForeignKey('finance.Statement', null=True, blank=True, on_delete=models.SET_NULL,
                                  related_name='payments', verbose_name='المستخلص')
    invoice = models.ForeignKey('finance.Invoice', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='payments', verbose_name='فاتورة العميل')
    pi = models.ForeignKey('procurement.PurchaseInvoice', null=True, blank=True, on_delete=models.SET_NULL,
                           related_name='payments', verbose_name='فاتورة المورد')
    worker = models.ForeignKey('resources.Worker', null=True, blank=True, on_delete=models.SET_NULL,
                               verbose_name='العامل')
    date = models.DateField('التاريخ')
    amount = models.DecimalField('المبلغ', max_digits=16, decimal_places=2)
    method = models.CharField('الطريقة', max_length=20, choices=METHODS, default='cash')
    reference = models.CharField('المرجع', max_length=100, blank=True)
    note = models.CharField('ملاحظة', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')
    created = models.DateTimeField('تاريخ التسجيل', auto_now_add=True)

    class Meta:
        verbose_name = 'الدفعة'
        verbose_name_plural = 'الدفعات'
        ordering = ['-date', '-id']

    def __str__(self):
        arrow = '↓' if self.pay_type == 'incoming' else '↑'
        return f'{arrow} {self.amount} — {self.reference or self.note or self.get_pay_type_display()}'

    def save(self, *args, **kwargs):
        created = not self.pk
        super().save(*args, **kwargs)
        if created:
            from .services import apply_payment
            apply_payment(self)


class Income(models.Model):
    CATEGORIES = [
        ('client_payment', 'دفعة عميل'),
        ('statement', 'مستخلص'),
        ('other', 'إيراد آخر'),
    ]
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='incomes', verbose_name='المشروع')
    category = models.CharField('التصنيف', max_length=20, choices=CATEGORIES, default='other')
    account = models.ForeignKey(Account, null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الحساب')
    amount = models.DecimalField('المبلغ', max_digits=16, decimal_places=2)
    date = models.DateField('التاريخ')
    description = models.CharField('البيان', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'الإيراد'
        verbose_name_plural = 'الإيرادات'
        ordering = ['-date']

    def __str__(self):
        return f'{self.description or self.get_category_display()} — {self.amount}'


class Expense(models.Model):
    CATEGORIES = [
        ('material', 'مواد'),
        ('labor', 'عمالة'),
        ('subcontractor', 'مقاولون'),
        ('equipment', 'معدات'),
        ('transport', 'نقل'),
        ('maintenance', 'صيانة'),
        ('overhead', 'تشغيلية'),
        ('other', 'أخرى'),
    ]
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='expenses', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL,
                              related_name='expenses', verbose_name='المرحلة')
    category = models.CharField('التصنيف', max_length=20, choices=CATEGORIES, default='other')
    account = models.ForeignKey(Account, null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الحساب')
    supplier = models.ForeignKey('procurement.Supplier', null=True, blank=True, on_delete=models.SET_NULL,
                                 verbose_name='المورد')
    worker = models.ForeignKey('resources.Worker', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='العامل')
    po = models.ForeignKey('procurement.PurchaseOrder', null=True, blank=True, on_delete=models.SET_NULL,
                           verbose_name='أمر الشراء')
    issue = models.ForeignKey('inventory.MaterialIssue', null=True, blank=True, on_delete=models.SET_NULL,
                              verbose_name='تصرف مواد')
    amount = models.DecimalField('المبلغ', max_digits=16, decimal_places=2)
    date = models.DateField('التاريخ')
    description = models.CharField('البيان', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'المصروف'
        verbose_name_plural = 'المصروفات'
        ordering = ['-date']

    def __str__(self):
        return f'{self.description or self.get_category_display()} — {self.amount}'


class Invoice(models.Model):
    """فاتورة مبيعات للعميل"""
    STATUSES = [('draft', 'مسودة'), ('issued', 'مصروفة'), ('partial', 'مدفوعة جزئيًا'), ('paid', 'مدفوعة'), ('overdue', 'متأخرة')]
    invoice_no = models.CharField('رقم الفاتورة', max_length=30, unique=True)
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='invoices', verbose_name='المشروع')
    contract = models.ForeignKey('contracts.Contract', null=True, blank=True, on_delete=models.SET_NULL,
                                 related_name='invoices', verbose_name='العقد')
    client = models.ForeignKey('crm.Client', on_delete=models.PROTECT, related_name='invoices', verbose_name='العميل')
    statement = models.ForeignKey('finance.Statement', null=True, blank=True, on_delete=models.SET_NULL,
                                  related_name='invoices', verbose_name='المستخلص')
    subtotal = models.DecimalField('الصافي', max_digits=16, decimal_places=2, default=0)
    discount = models.DecimalField('الخصم', max_digits=16, decimal_places=2, default=0)
    tax = models.DecimalField('الضريبة', max_digits=16, decimal_places=2, default=0)
    total = models.DecimalField('الإجمالي', max_digits=16, decimal_places=2, default=0)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    issue_date = models.DateField('تاريخ الإصدار', null=True, blank=True)
    due_date = models.DateField('تاريخ الاستحقاق', null=True, blank=True)
    paid_amount = models.DecimalField('المسدّد', max_digits=16, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'فاتورة عميل'
        verbose_name_plural = 'فواتير العملاء'

    def __str__(self):
        return self.invoice_no


class Statement(models.Model):
    """مستخلص أعمال من تنفيذ"""
    STATUSES = [
        ('draft', 'مسودة'),
        ('submitted', 'مقدم'),
        ('approved', 'معتمد'),
        ('partial', 'مدفوع جزئيًا'),
        ('paid', 'مدفوع'),
    ]
    statement_no = models.CharField('رقم المستخلص', max_length=30, unique=True)
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='statements', verbose_name='المشروع')
    contract = models.ForeignKey('contracts.Contract', on_delete=models.PROTECT, related_name='statements', verbose_name='العقد')
    period_start = models.DateField('من', null=True, blank=True)
    period_end = models.DateField('إلى', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    subtotal = models.DecimalField('صافي الأعمال', max_digits=16, decimal_places=2, default=0)
    discount = models.DecimalField('الخصومات', max_digits=16, decimal_places=2, default=0)
    deductions = models.DecimalField('المحجوزات', max_digits=16, decimal_places=2, default=0)
    paid_amount = models.DecimalField('المدفوع', max_digits=16, decimal_places=2, default=0)
    approved_by = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name='approved_statements', verbose_name='اعتمده')
    approved_at = models.DateTimeField('تاريخ الاعتماد', null=True, blank=True)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'المستخلص'
        verbose_name_plural = 'المستخلصات'

    def __str__(self):
        return self.statement_no

    @property
    def net(self):
        return self.subtotal - self.discount - self.deductions

    @property
    def remaining(self):
        return self.net - self.paid_amount


class StatementItem(models.Model):
    statement = models.ForeignKey(Statement, on_delete=models.CASCADE, related_name='items', verbose_name='المستخلص')
    boq_item = models.ForeignKey('projects.BOQItem', null=True, blank=True, on_delete=models.SET_NULL,
                                 verbose_name='بند BOQ')
    description = models.CharField('الوصف', max_length=250)
    unit = models.CharField('الوحدة', max_length=30, default='قطعة')
    prev_qty = models.DecimalField('الكمية السابقة', max_digits=14, decimal_places=3, default=0)
    current_qty = models.DecimalField('الكمية الحالية (المنفذ)', max_digits=14, decimal_places=3, default=0)
    work_qty = models.DecimalField('كمية الأعمال', max_digits=14, decimal_places=3, default=0)
    unit_price = models.DecimalField('سعر الوحدة', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند مستخلص'
        verbose_name_plural = 'بنود المستخلص'

    def __str__(self):
        return self.description

    @property
    def line_total(self):
        return self.work_qty * self.unit_price


class CostCenter(models.Model):
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم مركز التكلفة', max_length=150)
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='cost_centers', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL,
                              verbose_name='المرحلة')

    class Meta:
        verbose_name = 'مركز التكلفة'
        verbose_name_plural = 'مراكز التكلفة'

    def __str__(self):
        return self.name
