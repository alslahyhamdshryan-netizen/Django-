from django.db import models
from django.utils import timezone


class PunchListItem(models.Model):
    PRIORITIES = [('low', 'منخفضة'), ('medium', 'متوسطة'), ('high', 'عالية'), ('critical', 'حرجة')]
    STATUSES = [
        ('open', 'مفتوحة'),
        ('in_progress', 'قيد المعالجة'),
        ('fixed', 'تم الإصلاح'),
        ('inspected', 'تم الفحص'),
        ('closed', 'مغلقة'),
    ]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='punch_items', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المرحلة')
    title = models.CharField('الملاحظة', max_length=250)
    location = models.CharField('الموقع', max_length=150, blank=True)
    priority = models.CharField('الأولوية', max_length=20, choices=PRIORITIES, default='medium')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    assignee = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المسؤول')
    due_date = models.DateField('تاريخ الاستحقاق', null=True, blank=True)
    note = models.TextField('ملاحظة', blank=True)
    resolved_at = models.DateTimeField('تاريخ الحل', null=True, blank=True)

    class Meta:
        verbose_name = 'ملاحظة (Punch)'
        verbose_name_plural = 'قائمة الملاحظات'
        ordering = ['-pk']

    def __str__(self):
        return self.title


class Handover(models.Model):
    TYPES = [('interim', 'استلام ابتدائي'), ('final', 'استلام نهائي')]
    STATUSES = [('scheduled', 'مجدول'), ('in_progress', 'قيد التنفيذ'), ('completed', 'مكتمل')]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='handovers', verbose_name='المشروع')
    ho_type = models.CharField('النوع', max_length=20, choices=TYPES, default='interim')
    date = models.DateField('التاريخ')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='scheduled')
    receiver_name = models.CharField('اسم المستلم', max_length=150, blank=True)
    notes = models.TextField('الملاحظات', blank=True)
    issues_count = models.PositiveIntegerField('عدد الملاحظات', default=0)
    completed_at = models.DateTimeField('تاريخ الاكتمال', null=True, blank=True)

    class Meta:
        verbose_name = 'التسليم'
        verbose_name_plural = 'التسليمات'

    def __str__(self):
        return f'{self.get_ho_type_display()} — {self.project.code}'


class Warranty(models.Model):
    project = models.OneToOneField('projects.Project', on_delete=models.PROTECT, related_name='warranty', verbose_name='المشروع')
    scope = models.TextField('نطاق الضمان', blank=True)
    start_date = models.DateField('بداية الضمان')
    end_date = models.DateField('نهاية الضمان')

    class Meta:
        verbose_name = 'الضمان'
        verbose_name_plural = 'الضمانات'

    def __str__(self):
        return f'ضمان {self.project.code}'

    @property
    def status(self):
        today = timezone.localdate()
        if today > self.end_date:
            return 'expired'
        if today < self.start_date:
            return 'scheduled'
        return 'active'


class MaintenanceRequest(models.Model):
    MTYPES = [('fault', 'عطل'), ('maintenance', 'صيانة دورية')]
    STATUSES = [
        ('open', 'مفتوح'),
        ('assigned', 'مسند'),
        ('in_progress', 'قيد المعالجة'),
        ('resolved', 'تم الإصلاح'),
        ('closed', 'مغلق'),
    ]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='maintenance_requests', verbose_name='المشروع')
    warranty = models.ForeignKey(Warranty, null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الضمان')
    mtype = models.CharField('النوع', max_length=20, choices=MTYPES, default='fault')
    location = models.CharField('الموقع', max_length=150, blank=True)
    description = models.TextField('وصف العطل')
    priority = models.CharField('الأولوية', max_length=20, choices=PunchListItem.PRIORITIES, default='medium')
    reported_date = models.DateField('تاريخ البلاغ')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    assignee = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المسؤول')
    resolved_date = models.DateField('تاريخ الإصلاح', null=True, blank=True)
    note = models.TextField('ملاحظة', blank=True)

    class Meta:
        verbose_name = 'طلب صيانة'
        verbose_name_plural = 'طلبات الصيانة'
        ordering = ['-reported_date']

    def __str__(self):
        return f'صيانة {self.project.code} — {self.description[:40]}'
