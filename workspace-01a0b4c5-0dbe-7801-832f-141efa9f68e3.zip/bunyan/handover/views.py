from django import forms
from django.shortcuts import redirect, render

from core.crud import crud as _crud
from core.utils import field_list, row_for
from .models import (Handover, MaintenanceRequest, PunchListItem, Warranty)

punch_list, punch_create, punch_update = _crud(
    PunchListItem, 'قائمة الملاحظات (Punch List)', ['project', 'title', 'location', 'priority',
                                                    'status', 'assignee', 'due_date'],
    order_by=['-pk'])

handover_list, handover_create, handover_update = _crud(
    Handover, 'التسليمات', ['project', 'ho_type', 'date', 'status', 'receiver_name', 'issues_count'])

warranty_list, warranty_create, warranty_update = _crud(
    Warranty, 'الضمانات', ['project', 'start_date', 'end_date', 'scope'])


class MaintenanceRequestForm(forms.ModelForm):
    class Meta:
        model = MaintenanceRequest
        fields = ['project', 'warranty', 'mtype', 'location', 'description', 'priority',
                  'reported_date', 'status', 'assignee', 'resolved_date', 'note']


def maint_req_list(request):
    columns = field_list(MaintenanceRequest, ['reported_date', 'project', 'mtype', 'description',
                                              'priority', 'status', 'assignee'])
    qs = MaintenanceRequest.objects.select_related('project').order_by('-reported_date')
    return render(request, 'core/generic_list.html', {
        'page_title': 'طلبات الصيانة (ما بعد التسليم)', 'columns': columns,
        'create_url': 'handover:maint_req_create', 'create_label': 'إضافة طلب',
        'rows': [row_for(m, columns) for m in qs]})


def maint_req_form(request, pk=None):
    from django.shortcuts import get_object_or_404
    m = get_object_or_404(MaintenanceRequest, pk=pk) if pk else None
    if request.method == 'POST':
        form = MaintenanceRequestForm(request.POST, instance=m)
        if form.is_valid():
            form.save()
            return redirect('handover:maint_req_list')
    else:
        form = MaintenanceRequestForm(instance=m)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل طلب صيانة' if m else 'إضافة طلب صيانة', 'form': form})
