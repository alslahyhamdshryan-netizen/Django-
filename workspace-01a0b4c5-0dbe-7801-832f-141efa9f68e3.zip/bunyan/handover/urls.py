from django.urls import path

from . import views

app_name = 'handover'

urlpatterns = [
    path('punch/', views.punch_list, name='punch_list'),
    path('punch/add/', views.punch_create, name='punch_create'),
    path('punch/<int:pk>/edit/', views.punch_update, name='punch_update'),
    path('handovers/', views.handover_list, name='handover_list'),
    path('handovers/add/', views.handover_create, name='handover_create'),
    path('handovers/<int:pk>/edit/', views.handover_update, name='handover_update'),
    path('warranties/', views.warranty_list, name='warranty_list'),
    path('warranties/add/', views.warranty_create, name='warranty_create'),
    path('warranties/<int:pk>/edit/', views.warranty_update, name='warranty_update'),
    path('maintenance-requests/', views.maint_req_list, name='maint_req_list'),
    path('maintenance-requests/add/', views.maint_req_form, name='maint_req_create'),
    path('maintenance-requests/<int:pk>/edit/', views.maint_req_form, name='maint_req_update'),
]
