"""مصانع عروض عامة (قائمة / إضافة / تعديل / تفاصيل) لتقليل التكرار."""
from django.forms import ModelForm
from django.urls import reverse
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from .utils import field_list, row_for


class BaseCrudList(ListView):
    template_name = 'core/generic_list.html'
    model = None
    page_title = ''
    columns = []
    create_url_name = None
    detail_url_name = None
    order_by_list = []

    def get_queryset(self):
        qs = self.model.objects.all()
        if self.order_by_list:
            qs = qs.order_by(*self.order_by_list)
        return qs

    def get_context_data(self, **kw):
        ctx = super().get_context_data(**kw)
        ctx.update(
            page_title=self.page_title,
            columns=self.columns,
            create_url=reverse(self.create_url_name) if self.create_url_name else None,
            create_label='إضافة جديد',
            rows=[row_for(o, self.columns,
                          reverse(self.detail_url_name, args=[o.pk]) if self.detail_url_name else None)
                  for o in ctx['object_list']],
        )
        return ctx


class BaseCrudForm:
    template_name = 'core/generic_form.html'
    form_class = None
    form_title = ''
    detail_url_name = None

    def get_context_data(self, **kw):
        ctx = super().get_context_data(**kw)
        ctx['form_title'] = self.form_title
        return ctx

    def get_success_url(self):
        referer = self.request.META.get('HTTP_REFERER')
        if referer:
            return referer
        if self.detail_url_name and getattr(self, 'object', None):
            return reverse(self.detail_url_name, args=[self.object.pk])
        return self.request.path


def _form_cls(model, fields, name='ModelCrudForm'):
    editable = []
    for f in fields:
        try:
            if model._meta.get_field(f).editable:
                editable.append(f)
        except Exception:
            pass
    meta = type('Meta', (), {'model': model, 'fields': editable or '__all__'})
    return type(name, (ModelForm,), {'Meta': meta})


def crud(model, title, fields, detail=None, create=None, order_by=None):
    """تُرجع (list_view, create_view, update_view)."""
    columns = field_list(model, fields)
    Form = _form_cls(model, fields)

    L = type('ModelListView', (BaseCrudList,), dict(
        model=model, page_title=title, columns=columns,
        create_url_name=create, detail_url_name=detail, order_by_list=order_by or []))

    C = type('ModelCreateView', (BaseCrudForm, CreateView), dict(
        form_class=Form, form_title=f'إضافة {title}', detail_url_name=detail))
    U = type('ModelUpdateView', (BaseCrudForm, UpdateView), dict(
        form_class=Form, form_title='تعديل', detail_url_name=detail))

    return L.as_view(), C.as_view(), U.as_view()


class BaseCrudDetail(DetailView):
    template_name = 'core/generic_detail.html'
    model = None
    page_title = ''
    columns = []
    extra_fn = None

    def get_context_data(self, **kw):
        ctx = super().get_context_data(**kw)
        ctx['page_title'] = self.page_title
        ctx['detail_columns'] = self.columns
        if self.extra_fn:
            ctx.update(self.extra_fn(self.object))
        return ctx


def detail(model, title, fields, template='core/generic_detail.html', extra_context=None):
    columns = field_list(model, fields)
    D = type('ModelDetailView', (BaseCrudDetail,), dict(
        model=model, page_title=title, columns=columns,
        template_name=template, extra_fn=extra_context))
    return D.as_view()
