from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models

ROLE_CHOICES = [
    ('admin', 'مدير عام'),
    ('pm', 'مدير مشروع'),
    ('accountant', 'محاسب'),
    ('warehouse', 'أمين مخزن'),
    ('procurement', 'مشتريات'),
    ('supervisor', 'مشرف موقع'),
    ('viewer', 'مطالع فقط'),
]


class User(AbstractUser):
    role = models.CharField('الدور', max_length=20, choices=ROLE_CHOICES, default='viewer')
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    department = models.ForeignKey('core.Department', null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name='users', verbose_name='الإدارة')

    class Meta:
        verbose_name = 'المستخدم'
        verbose_name_plural = 'المستخدمون'

    def __str__(self):
        return self.get_full_name() or self.username

    def has_role(self, *roles):
        return self.is_superuser or self.role in roles


class Branch(models.Model):
    name = models.CharField('اسم الفرع', max_length=120)
    code = models.CharField('الرمز', max_length=20, blank=True)
    address = models.CharField('العنوان', max_length=250, blank=True)
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    is_main = models.BooleanField('الفرع الرئيسي', default=False)

    class Meta:
        verbose_name = 'الفرع'
        verbose_name_plural = 'الفروع'

    def __str__(self):
        return self.name


class Department(models.Model):
    name = models.CharField('اسم الإدارة', max_length=120)
    branch = models.ForeignKey(Branch, null=True, blank=True, on_delete=models.SET_NULL,
                               related_name='departments', verbose_name='الفرع')

    class Meta:
        verbose_name = 'الإدارة'
        verbose_name_plural = 'الإدارات'

    def __str__(self):
        return self.name


class SystemSetting(models.Model):
    key = models.CharField('المفتاح', max_length=100, unique=True)
    value = models.TextField('القيمة', blank=True)

    class Meta:
        verbose_name = 'إعداد النظام'
        verbose_name_plural = 'إعدادات النظام'

    def __str__(self):
        return f'{self.key} = {self.value}'


class Notification(models.Model):
    key = models.CharField('مفتاح فريد', max_length=160, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.CASCADE,
                             related_name='notifications', verbose_name='المستخدم')
    title = models.CharField('العنوان', max_length=200)
    message = models.TextField('الرسالة', blank=True)
    link = models.CharField('الرابط', max_length=300, blank=True)
    is_read = models.BooleanField('تمت القراءة', default=False)
    created = models.DateTimeField('تاريخ الإنشاء', auto_now_add=True)

    class Meta:
        verbose_name = 'تنبيه'
        verbose_name_plural = 'التنبيهات'
        ordering = ['-created']

    def __str__(self):
        return self.title


class AuditLog(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                             related_name='audit_logs', verbose_name='المستخدم')
    action = models.CharField('الإجراء', max_length=20)  # create / update / delete
    app_label = models.CharField('التطبيق', max_length=50)
    model_name = models.CharField('النموذج', max_length=50)
    object_id = models.CharField('معرّف السجل', max_length=64, blank=True)
    object_repr = models.CharField('السجل', max_length=200, blank=True)
    changes = models.JSONField('التغييرات', default=dict, blank=True)
    created = models.DateTimeField('التاريخ', auto_now_add=True)

    class Meta:
        verbose_name = 'سجل تدقيق'
        verbose_name_plural = 'سجلات التدقيق'
        ordering = ['-created']

    def __str__(self):
        return f'{self.action} {self.model_name} #{self.object_id}'
