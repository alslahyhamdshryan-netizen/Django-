from django.shortcuts import get_object_or_404, redirect, render

from .crud import crud
from .models import Branch, Department, SystemSetting, User
from .notifications import run_alerts


def dashboard(request):
    from .dashboard import kpis
    ctx = kpis()
    return render(request, 'dashboard.html', ctx)


# ---------- الشركة ----------
branch_list, branch_create, branch_update = crud(
    Branch, 'الفروع', ['name', 'code', 'address', 'phone', 'is_main'], order_by=['id'])
department_list, department_create, department_update = crud(
    Department, 'الإدارات', ['name', 'branch'], order_by=['id'])
setting_list, setting_create, setting_update = crud(
    SystemSetting, 'إعدادات النظام', ['key', 'value'], order_by=['id'])

USER_FIELDS = ['username', 'first_name', 'last_name', 'email', 'phone', 'role', 'department', 'is_active']
user_list, user_create, user_update = crud(
    User, 'المستخدمون', USER_FIELDS, order_by=['id'])


def notification_list(request):
    run_alerts()
    from .models import Notification
    qs = Notification.objects.filter(user__isnull=True)
    if request.GET.get('read') == '1':
        qs = qs.filter(is_read=True)
    if request.GET.get('unread') == '1':
        qs = qs.filter(is_read=False)
    return render(request, 'notifications.html', {'page_title': 'التنبيهات', 'notifications': qs})


def notification_read(request, pk):
    from .models import Notification
    n = get_object_or_404(Notification, pk=pk)
    n.is_read = True
    n.save()
    return redirect('core:notifications')
