from django.shortcuts import redirect

from .context import set_user


class RequestUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        set_user(request.user if request.user.is_authenticated else None)
        return self.get_response(request)


class RequireAuthMiddleware:
    """كل صفحات النظام تتطلب تسجيل (صفحات الاستثناء: admin/static/media)."""

    EXEMPT_PREFIXES = ('/admin/', '/static/', '/media/')

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path
        if (not request.user.is_authenticated
                and not path.startswith(self.EXEMPT_PREFIXES)):
            return redirect(f'/admin/login/?next={path}')
        return self.get_response(request)
