"""تشغيل الفحص ثم إرسال التنبيهات بالبريد إن كان مفعّلًا."""
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'فحص التنبيهات وإرسال غير المقروء منها بالبريد (إن كان مفعّلًا)'

    def handle(self, *args, **opts):
        from core.notifications import email_alerts, run_alerts
        added = run_alerts()
        sent = email_alerts()
        self.stdout.write(self.style.SUCCESS(
            f'تم فحص التنبيهات: {added} جديد، {sent} أُرسلت بالبريد.'))
