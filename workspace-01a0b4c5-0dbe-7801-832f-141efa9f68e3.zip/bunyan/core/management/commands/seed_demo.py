"""بيانات تجريبية كاملة: عميل → دراسة → عقد → مشتريات → مخزون → عمال → مستخلص → دفعات.

جميع الأرقام مترابطة عبر الخدمات (ليست أرقامًا ثابتة) حتى تعمل لوحة التحكم مباشرة.
"""
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone


class Command(BaseCommand):
    help = 'إنشاء بيانات تجريبية (seed) للنظام'

    def handle(self, *args, **opts):
        from crm.models import Client
        if Client.objects.exists():
            self.stdout.write(self.style.WARNING('يوجد بيانات بالفعل — تم التخطي. احذف bunyan.sqlite3 لإعادة الإنشاء.'))
            return

        User = get_user_model()
        today = timezone.localdate()

        # ---------- المستخدمون والفروع ----------
        admin, _ = User.objects.get_or_create(username='admin', defaults={'role': 'admin', 'is_staff': True, 'is_superuser': True,
                                                                          'first_name': 'المدير', 'last_name': 'العامة'})
        admin.set_password('Admin@12345')
        admin.save()
        pm = User.objects.create(username='khaled', first_name='خالد', last_name='العمري', role='pm', is_staff=True, phone='771234567')
        acc = User.objects.create(username='mona', first_name='منى', last_name='السعيد', role='accountant', is_staff=True)
        wh = User.objects.create(username='salem', first_name='سالم', last_name='البدر', role='warehouse', is_staff=True)
        pur = User.objects.create(username='hana', first_name='هبة', last_name='الحميري', role='procurement', is_staff=True)
        sup = User.objects.create(username='yousef', first_name='يوسف', last_name='الزبيري', role='supervisor', is_staff=True)
        for u in (pm, acc, wh, pur, sup):
            u.set_password('123456')
            u.save()

        from core.models import Branch, Department
        branch = Branch.objects.create(name='الفرع الرئيسي – صنعاء', code='BR-01', address='صنعاء – شارع الستين', is_main=True)
        dept_eng = Department.objects.create(name='الإدارة الهندسية', branch=branch)
        dept_fin = Department.objects.create(name='الإدارة المالية', branch=branch)

        # ---------- العميل ----------
        client = Client.objects.create(
            name='شركة الرواد القابضة للتطوير العقاري', client_type='company',
            phone='01-222334', address='صنعاء – الجبل الأخضر', credit_limit=Decimal('20000000'))
        client.contacts.create(name='أحمد الرواد', title='مدير المشاريع', phone='735000111')

        # ---------- المشروع ----------
        from projects.models import Project, Stage, BOQItem, DailyReport, Task
        project = Project.objects.create(
            code='P-001', name='فيلا سكنية 3 أدوار – شارع حدة', client=client, branch=branch,
            location='صنعاء – شارع حدة', area=450, manager=pm, engineer=pm, supervisor=sup,
            start_date=today - timedelta(days=230), end_date=today + timedelta(days=75),
            status='in_progress', description='فيلا سكنية 3 أدوار مع ساحة ومطبخ خارجي')

        stages_data = [
            ('تجهيز الموقع', 5, 100, 100),
            ('الحفر والأساسات', 15, 100, 100),
            ('الهيكل الخرساني', 25, 100, 80),
            ('المباني (البلوك)', 10, 80, 60),
            ('الكهرباء', 8, 60, 35),
            ('السباكة', 7, 60, 40),
            ('اللياسة', 8, 50, 25),
            ('الأرضيات', 7, 40, 10),
            ('الدهانات', 5, 30, 5),
            ('الأبواب والنوافذ', 4, 30, 0),
            ('التكييف والإنارة', 4, 20, 0),
            ('التشطيبات النهائية والفحص', 2, 10, 0),
        ]
        stage_objs = {}
        for idx, (name, w, planned, actual) in enumerate(stages_data, start=1):
            s = Stage.objects.create(project=project, name=name, order=idx, weight=w,
                                     planned_pct=planned, actual_pct=actual)
            stage_objs[name] = s

        # ---------- BOQ (دراسة المشروع) ----------
        boq_data = [
            # name, unit, qty, material, labor, equipment, overhead%, profit%
            ('حفر وتأسيس', 'م3', 600, 35, 95, 150, 5, 15),
            ('خرسانة عادية', 'م3', 320, 5200, 900, 500, 5, 15),
            ('تسليح حديد', 'طن', 55, 6800, 1400, 120, 5, 12),
            ('مباني بلوك', 'م2', 2600, 95, 110, 0, 5, 15),
            ('أعمال سباكة', 'م2', 1500, 160, 160, 15, 8, 15),
            ('أعمال كهرباء', 'م2', 1500, 150, 190, 15, 8, 15),
            ('لياسة داخلية', 'م2', 3800, 35, 70, 5, 5, 15),
            ('أرضيات سيراميك', 'م2', 420, 260, 120, 0, 5, 18),
            ('دهانات', 'م2', 5200, 32, 48, 0, 5, 15),
            ('أبواب ونوافذ', 'قطعة', 48, 7500, 1500, 0, 5, 12),
            ('تكييف', 'قطعة', 12, 32000, 1200, 0, 5, 15),
            ('تجهيزات نهائية', 'قطعة', 1, 18000, 12000, 0, 10, 15),
        ]
        boq_items = []
        for idx, (name, unit, qty, mat, lab, eq, oh, pr) in enumerate(boq_data, start=1):
            it = BOQItem.objects.create(
                project=project, line_no=idx, name=name, unit=unit, qty=qty,
                material_cost=mat, labor_cost=lab, equipment_cost=eq,
                overhead_pct=oh, profit_pct=pr)
            boq_items.append(it)

        # ---------- عرض السعر ثم العقد ----------
        from contracts.models import Quote
        from contracts.services import create_contract_from_quote, refresh_quote_total
        quote = Quote.objects.create(
            project=project, ref_no=f'Q-{today.year}-001', status='draft',
            valid_until=today + timedelta(days=30), discount_pct=2, tax_pct=0,
            duration_days=270,
            terms='دفعات: 20% مقدمة، 40% عند 50%، 30% عند 80%، 10% عند التسليم. ضمان 12 شهرًا.')
        refresh_quote_total(quote)
        quote.status = 'accepted'
        quote.accepted_at = timezone.now()
        quote.save()

        contract = create_contract_from_quote(
            quote, f'C-{today.year}-001', project.start_date, project.end_date)

        # دفعة مقدمة مسددة
        from finance.models import Payment
        Payment.objects.create(
            pay_type='incoming', party_type='client', party_id=client.pk,
            project=project, contract=contract, date=project.start_date + timedelta(days=8),
            amount=contract.value * Decimal('0.20'), method='bank',
            reference='دفعة مقدمة — حوالة', user=acc)

        # ---------- المواد والمخازن ----------
        from inventory.models import Material, Warehouse
        from procurement.models import Supplier, PurchaseOrder, PurchaseOrderItem, GoodsReceipt, GoodsReceiptItem
        m_cement = Material.objects.create(code='MAT-001', name='أسمنت', category='مواد بناء', unit='كيس', min_qty=600, last_cost=1750)
        m_rebar = Material.objects.create(code='MAT-002', name='حديد تسليح', category='مواد بناء', unit='طن', min_qty=5, last_cost=6800)
        Material.objects.create(code='MAT-003', name='بلوك أسمنتي', category='مواد بناء', unit='م3', min_qty=20)
        Material.objects.create(code='MAT-004', name='سيراميك', category='تشطيبات', unit='م2', min_qty=100)
        Material.objects.create(code='MAT-005', name='دهان', category='تشطيبات', unit='جالون', min_qty=50)

        wh_main = Warehouse.objects.create(code='WH-01', name='المخزن الرئيسي', wh_type='main', branch=branch)
        wh_proj = Warehouse.objects.create(code='WH-P1', name='مخزن مشروع حدة', wh_type='project', project=project)

        sup_cement = Supplier.objects.create(code='SUP-001', name='مصنع الوحدة للأسمنت', contact_name='م. فهد',
                                             phone='711112222', supplier_type='material', rating=4)
        sup_steel = Supplier.objects.create(code='SUP-002', name='شركة النصر للحديد', contact_name='أ. سامي',
                                            phone='733334444', supplier_type='material', rating=4)

        # أمر شراء أسمنت → استلام → مخزن المشروع
        po1 = PurchaseOrder.objects.create(
            po_no=f'PO-{today.year}-001', supplier=sup_cement, project=project,
            order_date=project.start_date + timedelta(days=20), expected_date=project.start_date + timedelta(days=30),
            status='sent')
        poi1 = PurchaseOrderItem.objects.create(po=po1, material=m_cement, qty=1000, unit_price=1750)
        po1.total = poi1.line_total
        po1.save()

        gr1 = GoodsReceipt.objects.create(receipt_no=f'GR-{today.year}-001', po=po1, warehouse=wh_proj,
                                          date=project.start_date + timedelta(days=30), inspector=wh, status='pending')
        gri1 = GoodsReceiptItem.objects.create(receipt=gr1, po_item=poi1, qty_received=1000, qty_accepted=1000, qty_rejected=0)
        from procurement.services import perform_receipt
        perform_receipt(gr1)

        # حديد
        po2 = PurchaseOrder.objects.create(
            po_no=f'PO-{today.year}-002', supplier=sup_steel, project=project,
            order_date=project.start_date + timedelta(days=35), expected_date=project.start_date + timedelta(days=45),
            status='sent')
        poi2 = PurchaseOrderItem.objects.create(po=po2, material=m_rebar, qty=30, unit_price=6800)
        po2.total = poi2.line_total
        po2.save()
        gr2 = GoodsReceipt.objects.create(receipt_no=f'GR-{today.year}-002', po=po2, warehouse=wh_proj,
                                          date=project.start_date + timedelta(days=45), inspector=wh, status='pending')
        GoodsReceiptItem.objects.create(receipt=gr2, po_item=poi2, qty_received=30, qty_accepted=30, qty_rejected=0)
        perform_receipt(gr2)

        # فاتورة مورد غير مسددة بالكامل
        from procurement.models import PurchaseInvoice
        PurchaseInvoice.objects.create(
            invoice_no=f'PI-{today.year}-001', supplier=sup_cement, po=po1, project=project,
            invoice_date=gr1.date + timedelta(days=5), due_date=gr1.date + timedelta(days=35),
            subtotal=poi1.line_total, tax=0, total=poi1.line_total, status='open')

        # طلب شراء بانتظار الاعتماد (سيراميك)
        from procurement.models import PurchaseRequest, PurchaseRequestItem
        m_ceramic = Material.objects.filter(code='MAT-004').first()
        pr1 = PurchaseRequest.objects.create(
            pr_no=f'PR-{today.year}-001', project=project, warehouse=wh_proj,
            requester=sup, status='submitted', notes='سيراميك لغرف النوم')
        PurchaseRequestItem.objects.create(request=pr1, material=m_ceramic, qty=420, est_cost=280)

        # ---------- صرف مواد (450 كيس + 20 طن) إلى المرحلة ----------
        from inventory.models import MaterialIssue, MaterialIssueItem
        from inventory.services import perform_issue
        issue = MaterialIssue.objects.create(
            issue_no=f'ISS-{today.year}-001', project=project, stage=stage_objs['الهيكل الخرساني'],
            warehouse=wh_proj, date=today - timedelta(days=20), requester=sup, status='approved')
        MaterialIssueItem.objects.create(issue=issue, material=m_cement, qty=450, unit_cost=1750)
        MaterialIssueItem.objects.create(issue=issue, material=m_rebar, qty=20, unit_cost=6800)
        perform_issue(issue)  # المخزون ينقص ← تكلفة المرحلة/المشروع تزداد

        # ---------- العمال ----------
        from resources.models import Worker, Attendance
        trades = [('سالم الحربي', 'سباك', 1200), ('ماجد القباطي', 'كهربائي', 1200),
                  ('أحمد العماد', 'ملاط', 900), ('صالح الشرعبي', 'عامل بناء', 800),
                  ('حمود العريقي', 'نجار', 1100)]
        for idx, (name, trade, wage) in enumerate(trades, start=1):
            w = Worker.objects.create(worker_no=f'W-{idx:03d}', name=name, trade=trade,
                                      wage=wage, wage_type='day', project=project,
                                      phone=f'7770000{idx}')
            for day in range(1, 6):
                Attendance.objects.create(worker=w, project=project, date=today - timedelta(days=7 - day),
                                          status='present', hours=8)
        w1 = Worker.objects.filter(worker_no='W-001').first()
        w1.advances.create(amount=Decimal('15000'), date=today - timedelta(days=30), note='سلفة شهرية')

        # مصروف عمالة
        from finance.services import record_expense
        record_expense(project=project, stage=stage_objs['الهيكل الخرساني'], category='labor',
                       amount=Decimal('85000'), description='أجور عمال — الأسبوع 40', user=acc)
        record_expense(project=project, category='equipment', amount=Decimal('250000'),
                       description='إيجار حفار — شهر كامل', user=acc)

        # ---------- المعدات ----------
        from resources.models import Equipment, EquipmentLog, EquipmentMaintenance
        exc = Equipment.objects.create(code='EQ-001', name='حفار CAT 320', equipment_type='excavator',
                                       status='in_use', hourly_cost=Decimal('25000'),
                                       purchase_cost=Decimal('45000000'), project=project)
        for day in range(1, 4):
            EquipmentLog.objects.create(equipment=exc, project=project, date=today - timedelta(days=10 - day),
                                        hours=12, fuel_liters=90, fuel_cost=Decimal('108000'), note='حفر ساحة')
        EquipmentMaintenance.objects.create(equipment=exc, project=project, mtype='repair',
                                            description='تغيير زيت وفلاتر', cost=Decimal('45000'),
                                            status='open', date=today - timedelta(days=2))

        # ---------- المستخلص والدفعات ----------
        from finance.models import Statement, StatementItem
        from finance.services import approve_statement
        st = Statement.objects.create(
            statement_no=f'ST-{today.year}-001', project=project, contract=contract,
            period_start=project.start_date, period_end=today - timedelta(days=40),
            status='submitted')
        st_items = [
            (boq_items[0], 600, 600),   # حفر كامل
            (boq_items[1], 200, 200),   # خرسانة 200 م3
            (boq_items[2], 35, 35),     # حديد 35 طن
            (boq_items[3], 800, 800),   # مباني 800 م2
        ]
        for it, qty, wqty in st_items:
            StatementItem.objects.create(
                statement=st, boq_item=it, description=it.name, unit=it.unit,
                prev_qty=0, current_qty=qty, work_qty=wqty, unit_price=it.unit_price)
        st.subtotal = sum((i.line_total for i in st.items.all()), 0)
        st.save()
        approve_statement(st, user=acc)  # إنشاء فاتورة + مديونية العميل

        Payment.objects.create(
            pay_type='incoming', party_type='client', party_id=client.pk,
            project=project, contract=contract, statement=st,
            date=today - timedelta(days=30), amount=st.net * Decimal('0.75'),
            method='bank', reference='دفعة مستخلص 1 (75%)', user=acc)

        # ---------- الجودة والسلامة ----------
        from quality.models import ChecklistTemplate, ChecklistItem, Inspection, InspectionAnswer, Issue, Risk
        cl = ChecklistTemplate.objects.create(name='فحص الصبة الخرسانية', description='قبل اعتماد الصبة')
        cl_items = [
            ChecklistItem.objects.create(template=cl, question='هل تم فحص الحديد (أقطال/تباعد/تغطية)؟', order=1),
            ChecklistItem.objects.create(template=cl, question='هل تم التأكد من الأبعاد؟', order=2),
            ChecklistItem.objects.create(template=cl, question='هل تم التأكد من المناسيب؟', order=3),
            ChecklistItem.objects.create(template=cl, question='هل تمت معايرة القوالب؟', order=4),
        ]
        insp = Inspection.objects.create(project=project, stage=stage_objs['الهيكل الخرساني'],
                                         checklist=cl, inspector=pm, date=project.start_date + timedelta(days=90),
                                         status='pass')
        for ci in cl_items:
            InspectionAnswer.objects.create(inspection=insp, item=ci, answer='pass')

        Issue.objects.create(project=project, stage=stage_objs['الكهرباء'], title='تسريب مياه في حمام الدور الأول',
                             description='تسريب بعد اختبار السباكة', priority='high', status='open',
                             assignee=sup, due_date=today - timedelta(days=5))
        Issue.objects.create(project=project, stage=stage_objs['الأرضيات'], title='خدش في بلاط الصالة',
                             priority='medium', status='in_progress', assignee=sup)
        Risk.objects.create(project=project, description='تأخر توريد السيراميك → خطر تأخير التشطيب',
                            likelihood=3, impact=4, preventive='طلب بديل ومراجعة جدول التوريد', owner=pur)

        # ---------- المستندات والمخططات ----------
        from documents.models import Document, Drawing, DrawingVersion, ProjectImage
        Document.objects.create(project=project, category='contract', title='عقد التنفيذ الموقع', user=acc)
        d1 = Drawing.objects.create(project=project, drawing_no='A-001', title='المخطط المعماري')
        DrawingVersion.objects.create(drawing=d1, version_no=1, revision_date=project.start_date - timedelta(days=10), note='إصدار أولي')
        DrawingVersion.objects.create(drawing=d1, version_no=2, revision_date=project.start_date + timedelta(days=30), note='تعديل المدخل الرئيسي')
        ProjectImage.objects.create(project=project, stage=stage_objs['الهيكل الخرساني'],
                                    title='صبة الدور الثاني', date=today - timedelta(days=40))

        # ---------- التسليم والضمان ----------
        from handover.models import PunchListItem, Handover, Warranty, MaintenanceRequest
        Warranty.objects.create(project=project, scope='أعمال التشطيب والسباكة والكهرباء',
                                start_date=today + timedelta(days=70), end_date=today + timedelta(days=70 + 365))
        PunchListItem.objects.create(project=project, title='دهان تكميلي في السطح', location='السطح',
                                     priority='low', status='open', assignee=sup)
        PunchListItem.objects.create(project=project, title='إطار باب الحمام الرئيسي', location='الدور الأول',
                                     priority='high', status='in_progress', assignee=sup)
        MaintenanceRequest.objects.create(project=project, mtype='fault', location='الحمام الرئيسي',
                                          description='عطل في خلاط الماء', priority='medium',
                                          reported_date=today - timedelta(days=8), status='open')
        Handover.objects.create(project=project, ho_type='interim', date=today + timedelta(days=70),
                                status='scheduled', receiver_name='م. أحمد الرواد')

        # ---------- الجدول الزمني (مهام Gantt) ----------
        st1 = stage_objs['تجهيز الموقع']; st3 = stage_objs['الهيكل الخرساني']
        st4 = stage_objs['المباني (البلوك)']; st5 = stage_objs['الكهرباء']
        st6 = stage_objs['السباكة']; st7 = stage_objs['اللياسة']
        st8 = stage_objs['الأرضيات']; st9 = stage_objs['الدهانات']
        st10 = stage_objs['الأبواب والنوافذ']; st11 = stage_objs['التكييف والإنارة']
        st12 = stage_objs['التشطيبات النهائية والفحص']
        s0 = project.start_date
        task_data = [
            ('معايرة المناسيب وتجهيز الموقع', st1, 0, 10),
            ('حفر الأساسات والعمق', st1, 8, 25),
            ('صب بلاطة الأرضية', st3, 30, 20),
            ('صب الدور الأرضي', st3, 50, 25),
            ('صب الدور الأول', st3, 75, 25),
            ('صب الدور الثاني والأسقف', st3, 100, 25),
            ('مباني الدور الأرضي', st4, 40, 30),
            ('مباني الأدوار العليا', st4, 70, 40),
            ('تجهيزات سباكة كاملة', st6, 110, 35),
            ('تجهيزات كهرباء كاملة', st5, 115, 35),
            ('لياسة الدور الأول', st7, 145, 25),
            ('لياسة الأدوار الأخرى', st7, 170, 25),
            ('سيراميك الأرضيات', st8, 175, 30),
            ('دهانات داخلية', st9, 205, 25),
            ('تركيب الأبواب والنوافذ', st10, 210, 20),
            ('توريد وتركيب التكييف', st11, 215, 20),
            ('فحص نهائي وتسليم', st12, 245, 12),
        ]
        for name, stg, off, dur in task_data:
            s = s0 + timedelta(days=off)
            e = s + timedelta(days=dur)
            if e < today:
                status, pct = 'done', 100
            elif s <= today:
                status = 'in_progress'
                pct = float((today - s).days) / dur * 100
            else:
                status, pct = 'todo', 0
            Task.objects.create(project=project, stage=stg, name=name, start_date=s,
                                end_date=e, status=status, pct=pct)

        # ---------- التقرير اليومي ----------
        DailyReport.objects.create(
            project=project, date=today - timedelta(days=1), summary='عمل على الكهرباء والأرضيات',
            workers_count=14, works_done='تمديدات كهرباء الدور الثاني، بدء سيراميك المطبخ',
            materials_text='120 جالون دهان، 60 م2 سيراميك', equipment_text='حفار 4 ساعات',
            problems_text='تأخر سيراميك غرفة النوم', notes='الطقس مناسب',
            stage=stage_objs['الكهرباء'], stage_pct=35)

        # ---------- الاجتماعات ----------
        from projects.models import Meeting, MeetingTask
        mt = Meeting.objects.create(
            project=project, title='اجتماع متابعة التنفيذ', meeting_date=today - timedelta(days=3),
            location='موقع المشروع — المكتب الميداني',
            attendees='خالد العمري (مدير مشروع)، يوسف الزبيري (مشرف)، أ. أحمد الرواد (ممثل العميل)، هبة الحميري (مشتريات)',
            decisions='1) تعجيل توريد السيراميك 2) بدء دهانات الدور الأول بعد 3 أيام 3) اجتماع أسبوعي كل سبت',
            notes='حضور ممثّل العميل عن بُعد')
        MeetingTask.objects.create(meeting=mt, title='متابعة شركة السيراميك للتوريد', assignee=pur,
                                   due_date=today + timedelta(days=5), status='open')
        MeetingTask.objects.create(meeting=mt, title='جدولة طاقم الدهان', assignee=pm,
                                   due_date=today + timedelta(days=2), status='in_progress')

        # ---------- المقاولون من الباطن ----------
        from resources.models import Subcontractor, SubcontractorContract
        sub_elec = Subcontractor.objects.create(
            code='SUB-001', name='مؤسسة الإيمان للأعمال الكهربائية', trade='electrical',
            contact_name='م. سامي', phone='710000111', rating=4,
            notes='تقييم جيد، التزام بالمواعيد')
        SubcontractorContract.objects.create(
            subcontractor=sub_elec, project=project, scope='أعمال الكهرباء الكاملة',
            value=Decimal('350000'), start_date=project.start_date + timedelta(days=120),
            end_date=project.end_date, status='active')
        Payment.objects.create(
            pay_type='outgoing', party_type='subcontractor', party_id=sub_elec.pk,
            project=project, date=today - timedelta(days=12), amount=Decimal('150000'),
            method='bank', reference='دفعة 1 — كهرباء', user=acc)

        sub_paint = Subcontractor.objects.create(
            code='SUB-002', name='شركة الفهد للدهانات', trade='painting',
            contact_name='عادل', phone='720000222', rating=3)
        SubcontractorContract.objects.create(
            subcontractor=sub_paint, project=project, scope='دهانات داخلية وخارجية',
            value=Decimal('280000'), start_date=today + timedelta(days=10),
            end_date=today + timedelta(days=40), status='draft')

        # ---------- إعدادات النظام ----------
        from core.models import SystemSetting
        SystemSetting.objects.bulk_create([
            SystemSetting(key='company_name', value='شركة بنيان للمقاولات العامة'),
            SystemSetting(key='notify_email', value='0'),
            SystemSetting(key='notify_email_to', value='manager@example.com'),
        ])

        # ---------- تنبيهات ----------
        from core.notifications import run_alerts
        n = run_alerts()

        self.stdout.write(self.style.SUCCESS(
            f'تم إنشاء البيانات التجريبية: مشروع {project.code} بقيمة عقد {contract.value:,.0f} ر.ي '
            f'و{run_alerts() + n} تنبيهًا.\n'
            f'المستخدمون: admin/Admin@12345 | khaled-mona-salem-hana-yousef / 123456'))
