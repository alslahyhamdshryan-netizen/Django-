"""واجهة API JSON بسيطة للتكامل مع أنظمة خارجية (تتطلب تسجيل دخول)."""
from decimal import Decimal

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.http import JsonResponse


def _num(v):
    return float(v) if isinstance(v, Decimal) else v


@login_required
def api_kpis(request):
    from .dashboard import kpis
    d = kpis()
    return JsonResponse({
        'projects_total': d['projects_total'],
        'active': d['active'],
        'on_hold': d['on_hold'],
        'late': d['late'],
        'completed': d['completed'],
        'contracts_value': _num(d['contracts_value']),
        'total_costs': _num(d['total_costs']),
        'total_received': _num(d['total_received']),
        'total_paid_out': _num(d['total_paid_out']),
        'expected_profit': _num(d['expected_profit']),
        'actual_profit': _num(d['actual_profit']),
        'pending_purchase_requests': d['pending_po'],
        'open_issues': d['open_issues'],
        'unread_alerts': d['unread'],
    })


@login_required
def api_projects(request):
    from projects.models import Project
    from finance.services import project_financials
    out = []
    for p in Project.objects.all():
        f = project_financials(p)
        out.append({
            'id': p.pk,
            'code': p.code,
            'name': p.name,
            'client': p.client.name,
            'status': p.status,
            'start_date': str(p.start_date) if p.start_date else None,
            'end_date': str(p.end_date) if p.end_date else None,
            'progress': p.progress,
            'contract_value': _num(f['contract_value']),
            'planned_cost': _num(f['planned_cost']),
            'actual_cost': _num(f['actual_cost']),
            'work_value': _num(f['work_value']),
            'received': _num(f['received']),
            'forecast_cost_at_completion': _num(f['forecast_cost']),
            'expected_profit_at_completion': _num(f['expected_profit']),
        })
    return JsonResponse({'count': len(out), 'projects': out})


@login_required
def api_project_financials(request, pk):
    from projects.models import Project
    from finance.services import project_financials
    p = Project.objects.filter(pk=pk).first()
    if not p:
        return JsonResponse({'error': 'not found'}, status=404)
    f = project_financials(p)
    return JsonResponse({
        'project': p.code,
        'progress': f['progress'],
        'contract_value': _num(f['contract_value']),
        'planned_cost': _num(f['planned_cost']),
        'actual_cost': _num(f['actual_cost']),
        'work_value': _num(f['work_value']),
        'received': _num(f['received']),
        'paid_out': _num(f['paid_out']),
        'current_profit': _num(f['current_profit']),
        'remaining_cost': _num(f['remaining_cost']),
        'forecast_cost': _num(f['forecast_cost']),
        'expected_profit': _num(f['expected_profit']),
        'stages': [
            {'name': s.name, 'weight': s.weight, 'planned': s.planned_pct, 'actual': s.actual_pct}
            for s in p.stages.order_by('order')
        ],
    })


@login_required
def api_stock(request):
    from inventory.models import Material
    from inventory.services import total_stock
    out = []
    for m in Material.objects.filter(active=True):
        balance = total_stock(m)
        out.append({
            'code': m.code,
            'name': m.name,
            'unit': m.unit,
            'balance': _num(balance),
            'min_qty': _num(m.min_qty),
            'last_cost': _num(m.last_cost),
            'low_stock': bool(m.min_qty and balance <= m.min_qty),
        })
    return JsonResponse({'count': len(out), 'materials': out})


@login_required
def api_alerts(request):
    from .models import Notification
    qs = Notification.objects.filter(is_read=False).order_by('-created')
    return JsonResponse({
        'count': qs.count(),
        'alerts': [{'title': n.title, 'message': n.message, 'link': n.link,
                    'created': n.created.isoformat()} for n in qs[:50]],
    })


@login_required
def api_payments(request):
    from finance.models import Payment
    qs = Payment.objects.all().order_by('-date')[:300]
    if request.GET.get('type'):
        qs = qs.filter(pay_type=request.GET['type'])
    return JsonResponse({
        'count': qs.count(),
        'payments': [{
            'id': p.pk,
            'date': str(p.date),
            'type': p.pay_type,
            'party': p.party_type,
            'project': p.project.code if p.project else None,
            'amount': _num(p.amount),
            'method': p.method,
            'reference': p.reference,
        } for p in qs],
    })


@login_required
def api_statements(request):
    from finance.models import Statement
    out = []
    for s in Statement.objects.select_related('project', 'contract').order_by('-id'):
        out.append({
            'id': s.pk,
            'number': s.statement_no,
            'project': s.project.code,
            'status': s.status,
            'subtotal': _num(s.subtotal),
            'net': _num(s.net),
            'paid': _num(s.paid_amount),
            'remaining': _num(s.remaining),
            'approved_at': s.approved_at.isoformat() if s.approved_at else None,
        })
    return JsonResponse({'count': len(out), 'statements': out})


@login_required
def api_workers(request):
    from resources.models import Worker
    from resources.services import worker_settlement
    out = []
    for w in Worker.objects.filter(active=True):
        s = worker_settlement(w)
        out.append({
            'id': w.pk,
            'no': w.worker_no,
            'name': w.name,
            'trade': w.trade,
            'project': None,
            'wage': _num(w.wage),
            'wage_type': w.wage_type,
            'earned': _num(s['earned']),
            'advances': _num(s['advances']),
            'deductions': _num(s['deductions']),
            'net_due': _num(s['net']),
        })
    return JsonResponse({'count': len(out), 'workers': out})


@login_required
def api_suppliers(request):
    from procurement.models import Supplier
    from finance.services import supplier_payable
    out = []
    for s in Supplier.objects.all():
        out.append({
            'id': s.pk,
            'code': s.code,
            'name': s.name,
            'type': s.supplier_type,
            'rating': s.rating,
            'payable': _num(supplier_payable(s)),
        })
    return JsonResponse({'count': len(out), 'suppliers': out})
