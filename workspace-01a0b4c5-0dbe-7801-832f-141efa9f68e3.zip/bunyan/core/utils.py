"""أدوات مشتركة: أعمدة الجداول، الصفوف، الملخصات."""
from django.db import models
from django.db.models import (BooleanField, DateField, DateTimeField,
                              DecimalField, FloatField, ForeignKey,
                              IntegerField)

STATUS_BADGES = {
    'draft': ('مسودة', 'secondary'),
    'planning': ('قيد الدراسة', 'info'),
    'in_progress': ('قيد التنفيذ', 'primary'),
    'on_hold': ('متوقف', 'warning'),
    'completed': ('مكتمل', 'success'),
    'closed': ('مغلق', 'dark'),
    'active': ('نشط', 'success'),
    'review': ('قيد المراجعة', 'info'),
    'approved': ('معتمد', 'success'),
    'rejected': ('مرفوض', 'danger'),
    'sent': ('مرسل', 'primary'),
    'accepted': ('مقبول', 'success'),
    'applied': ('تم التطبيق', 'success'),
    'submitted': ('مقدم', 'info'),
    'partial': ('جزئي', 'warning'),
    'received': ('مستلم', 'success'),
    'paid': ('مدفوع', 'success'),
    'open': ('مفتوح', 'danger'),
    'fixed': ('تم الإصلاح', 'primary'),
    'inspected': ('تم الفحص', 'success'),
    'todo': ('لم تبدأ', 'secondary'),
    'done': ('منتهية', 'success'),
    'pass': ('ناجح', 'success'),
    'fail': ('مرفوض', 'danger'),
    'rework': ('يحتاج معالجة', 'warning'),
    'pending': ('بانتظار الفحص', 'warning'),
    'present': ('حاضر', 'success'),
    'absent': ('غائب', 'danger'),
    'leave': ('إجازة', 'secondary'),
    'available': ('متاح', 'success'),
    'maintenance': ('صيانة', 'warning'),
    'broken': ('معطل', 'danger'),
    'scheduled': ('مجدول', 'info'),
    'issued': ('مصدر', 'success'),
    'requested': ('مطلوب', 'info'),
    'confirmed': ('مؤكد', 'success'),
    'low': ('منخفضة', 'secondary'),
    'medium': ('متوسطة', 'warning'),
    'high': ('عالية', 'danger'),
    'critical': ('حرجة', 'dark'),
    'mitigated': ('تم التخفيف', 'info'),
    'resolved': ('تمت المعالجة', 'success'),
    'assigned': ('مسند', 'info'),
    'overdue': ('متأخر', 'danger'),
    'interim': ('ابتدائي', 'info'),
    'final': ('نهائي', 'primary'),
    'expired': ('منتهي', 'dark'),
    'incoming': ('واردة', 'success'),
    'outgoing': ('صادرة', 'danger'),
    'cancelled': ('ملغي', 'secondary'),
}


def badge(value):
    if value is None or value == '':
        return ('—', 'secondary')
    return STATUS_BADGES.get(str(value), (str(value), 'secondary'))


def field_list(model, names):
    """توليد قائمة أعمدة جدول من حقول النموذج مع التصنيف (نقود/نسبة/تاريخ/حالة...)."""
    out = []
    for name in names:
        try:
            f = model._meta.get_field(name)
        except Exception:
            continue
        label = f.verbose_name
        kind = 'str'
        if name == 'status' or name.endswith('_status'):
            kind = 'status'
        elif isinstance(f, BooleanField):
            kind = 'bool'
        elif isinstance(f, DecimalField):
            kind = 'money'
        elif isinstance(f, FloatField):
            kind = 'pct' if 'pct' in name else 'num'
        elif isinstance(f, IntegerField):
            kind = 'pct' if 'pct' in name else 'int'
        elif isinstance(f, (DateField, DateTimeField)):
            kind = 'date'
        elif isinstance(f, ForeignKey):
            kind = 'fk'
        out.append({'name': name, 'label': label, 'kind': kind})
    return out


def row_for(obj, columns, url=None):
    row = {'row_url': url or ''}
    for c in columns:
        v = getattr(obj, c['name'], None)
        if c['kind'] == 'status':
            row[c['name']] = badge(v)
        elif isinstance(v, models.Model):
            row[c['name']] = str(v)
        else:
            row[c['name']] = v
    return row
