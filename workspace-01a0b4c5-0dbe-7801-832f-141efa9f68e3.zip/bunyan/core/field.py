"""وضع الميدان: صفحة موبايل واحدة للمشرف (تقرير يومي + حضور + مشاكل + ملاحظات تسليم مع صور)."""
from django.contrib import messages
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.utils.dateparse import parse_date


def field_page(request):
    from projects.models import DailyReport, Project, Stage
    from documents.models import ProjectImage
    from resources.models import Attendance, Worker
    from quality.models import Issue
    from handover.models import PunchListItem

    projects = Project.objects.filter(status='in_progress')
    project = None
    if request.method == 'POST':
        project = get_object_or_404(Project, pk=request.POST.get('project_id'))
    else:
        p_id = request.GET.get('project')
        if p_id:
            project = get_object_or_404(Project, pk=p_id)
        elif projects.exists():
            project = projects.first()

    today = timezone.localdate()
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'daily':
            d = parse_date(request.POST.get('date')) or today
            stage = Stage.objects.filter(project=project, pk=request.POST.get('stage_id')).first() \
                if request.POST.get('stage_id') else None
            pct = request.POST.get('stage_pct') or None
            DailyReport.objects.create(
                project=project, date=d,
                summary=request.POST.get('summary', ''),
                workers_count=int(request.POST.get('workers_count') or 0),
                works_done=request.POST.get('works_done', ''),
                problems_text=request.POST.get('problems', ''),
                notes=request.POST.get('notes', ''),
                stage=stage, stage_pct=float(pct) if pct else None)
            for f in request.FILES.getlist('photos'):
                ProjectImage.objects.create(project=project, stage=stage,
                                             title=f'تقرير يوم {d} — {f.name}', image=f, date=d)
            messages.success(request, f'✓ تم حفظ تقرير يوم {d.isoformat()}')
            return _redirect(request, project, 'daily')
        elif action == 'attendance':
            d = parse_date(request.POST.get('date')) or today
            saved = 0
            for w in Worker.objects.filter(project=project):
                st = request.POST.get(f'w_{w.pk}_status')
                if not st:
                    continue
                Attendance.objects.update_or_create(
                    worker=w, date=d,
                    defaults={'status': st, 'project': project,
                              'hours': float(request.POST.get(f'w_{w.pk}_hours') or 8 or 0),
                              'overtime_hours': float(request.POST.get(f'w_{w.pk}_ot') or 0 or 0)})
                saved += 1
            messages.success(request, f'✓ تم حفظ حضور {saved} عامل ليوم {d.isoformat()}')
            return _redirect(request, project, 'attendance')
        elif action == 'issue':
            stage = Stage.objects.filter(project=project, pk=request.POST.get('stage_id')).first() \
                if request.POST.get('stage_id') else None
            it = Issue.objects.create(
                project=project, stage=stage,
                title=request.POST.get('title', 'مشكلة بدون عنوان'),
                description=request.POST.get('description', ''),
                priority=request.POST.get('priority', 'medium'),
                status='open')
            for f in request.FILES.getlist('photos'):
                ProjectImage.objects.create(project=project, stage=stage,
                                             title=f'مشكلة: {it.title} — {f.name}', image=f, date=today)
            messages.success(request, '✓ تم تسجيل المشكلة وإبلاغ الإدارة')
            return _redirect(request, project, 'issue')
        elif action == 'punch':
            PunchListItem.objects.create(
                project=project,
                title=request.POST.get('title', 'ملاحظة بدون عنوان'),
                location=request.POST.get('location', ''),
                priority=request.POST.get('priority', 'medium'),
                status='open')
            for f in request.FILES.getlist('photos'):
                ProjectImage.objects.create(project=project,
                                             title=f'ملاحظة تسليم — {f.name}', image=f, date=today)
            messages.success(request, '✓ أُضيفت الملاحظة لقائمة التسليم')
            return _redirect(request, project, 'punch')

    workers = list(Worker.objects.filter(project=project).order_by('id')) if project else []
    recent_reports = list(DailyReport.objects.filter(project=project).order_by('-date')[:5]) if project else []
    return render(request, 'field.html', {
        'projects': projects,
        'project': project,
        'workers': workers,
        'stages': project.stages.order_by('order') if project else [],
        'recent_reports': recent_reports,
        'open_issues': Issue.objects.filter(project=project, status__in=['open', 'in_progress']).count() if project else 0,
        'open_punch': PunchListItem.objects.filter(project=project, status__in=['open', 'in_progress']).count() if project else 0,
        'today': today,
        'active_tab': request.GET.get('tab', 'daily'),
    })


def _redirect(request, project, tab):
    from django.shortcuts import redirect
    return redirect(f'/field/?project={project.pk}&tab={tab}')
