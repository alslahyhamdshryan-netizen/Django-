from decimal import Decimal

from django import template

register = template.Library()


@register.filter
def money(v):
    try:
        d = Decimal(str(v or 0))
        s = f'{d:,.2f}'
        if s.endswith('.00'):
            s = s[:-3]
        return s
    except Exception:
        return str(v or '')


@register.filter
def get(obj, key):
    try:
        if isinstance(obj, dict):
            return obj.get(key, '')
        return obj[key]
    except Exception:
        return ''


@register.filter
def get_attr(obj, name):
    try:
        v = getattr(obj, name)
        if callable(v):
            return ''
        return v
    except Exception:
        return ''
