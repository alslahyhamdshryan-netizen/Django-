from django.urls import path

from . import api, field, views

app_name = 'core'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('field/', field.field_page, name='field'),
    path('branches/', views.branch_list, name='branch_list'),
    path('branches/add/', views.branch_create, name='branch_create'),
    path('branches/<int:pk>/edit/', views.branch_update, name='branch_update'),
    path('departments/', views.department_list, name='department_list'),
    path('departments/add/', views.department_create, name='department_create'),
    path('departments/<int:pk>/edit/', views.department_update, name='department_update'),
    path('settings/', views.setting_list, name='setting_list'),
    path('settings/add/', views.setting_create, name='setting_create'),
    path('settings/<int:pk>/edit/', views.setting_update, name='setting_update'),
    path('users/', views.user_list, name='user_list'),
    path('users/add/', views.user_create, name='user_create'),
    path('users/<int:pk>/edit/', views.user_update, name='user_update'),
    path('notifications/', views.notification_list, name='notifications'),
    path('notifications/<int:pk>/read/', views.notification_read, name='notification_read'),
    # API
    path('api/kpis/', api.api_kpis, name='api_kpis'),
    path('api/projects/', api.api_projects, name='api_projects'),
    path('api/projects/<int:pk>/financials/', api.api_project_financials, name='api_project_financials'),
    path('api/stock/', api.api_stock, name='api_stock'),
    path('api/alerts/', api.api_alerts, name='api_alerts'),
    path('api/payments/', api.api_payments, name='api_payments'),
    path('api/statements/', api.api_statements, name='api_statements'),
    path('api/workers/', api.api_workers, name='api_workers'),
    path('api/suppliers/', api.api_suppliers, name='api_suppliers'),
]
