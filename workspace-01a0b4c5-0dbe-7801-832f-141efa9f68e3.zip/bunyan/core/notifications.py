"""محرك التنبيهات: يفحص النظام ويبني تنبيهات لكل حالة تستدعي الانتباه."""
from decimal import Decimal
from django.utils import timezone


def _check_tasks(today):
    from projects.models import Task
    out = []
    for t in Task.objects.filter(status__in=['todo', 'in_progress']).exclude(end_date__isnull=True)\
            .filter(end_date__lt=today):
        out.append((f'task:{t.pk}', f'مهمة متأخرة: {t.name}',
                    f'المهمة "{t.name}" في مشروع {t.project.name} متأخرة (كانت تستحق {t.end_date})',
                    '/projects/'))
    return out


def _check_contracts(today):
    from datetime import timedelta
    from contracts.models import Contract
    out = []
    for c in Contract.objects.filter(status='active').filter(
            end_date__gte=today, end_date__lte=today + timedelta(days=30)):
        out.append((f'contract_end:{c.pk}', f'عقد يقترب من الانتهاء: {c.contract_no}',
                    f'عقد "{c.project.name}" ينتهي بتاريخ {c.end_date}', '/contracts/'))
    return out


def _check_payments(today):
    from datetime import timedelta
    from contracts.models import PaymentSchedule
    out = []
    for s in PaymentSchedule.objects.filter(status__in=['open', 'partial']
                                            ).exclude(due_date__isnull=True):
        if s.due_date <= today + timedelta(days=7):
            out.append((f'sched:{s.pk}', f'دفعة مستحقة: {s.name}',
                        f'دفعة "{s.name}" بقيمة {s.amount} من مشروع {s.contract.project.name} '
                        f'استحقاقها {s.due_date}', '/finance/statements/'))
    return out


def _check_stock(today=None):
    from inventory.services import low_stock_materials
    out = []
    for m, qty in low_stock_materials():
        out.append((f'stock:{m.pk}', f'نقص مادة: {m.name}',
                    f'رصيد "{m.name}" ({qty} {m.unit}) أقل من الحد الأدنى ({m.min_qty})',
                    '/inventory/stock/'))
    return out


def _check_requests(today=None):
    from procurement.models import PurchaseRequest
    out = []
    for r in PurchaseRequest.objects.filter(status='submitted'):
        out.append((f'pr:{r.pk}', f'طلب شراء بانتظار الاعتماد: {r.pr_no}',
                    f'طلب الشراء {r.pr_no} لمشروع {r.project.name} بانتظار الاعتماد',
                    f'/procurement/requests/{r.pk}/'))
    return out


def _check_issues(today):
    from quality.models import Issue
    out = []
    for i in Issue.objects.filter(status='open').exclude(due_date__isnull=True).filter(due_date__lt=today):
        out.append((f'issue:{i.pk}', f'مشكلة متأخرة: {i.title}',
                    f'المشكلة "{i.title}" (مشروع {i.project.code}) تجاوزت تاريخ الاستحقاق',
                    '/quality/issues/'))
    return out


def _check_maintenance(today=None):
    from resources.models import EquipmentMaintenance
    out = []
    for m in EquipmentMaintenance.objects.filter(status__in=['open', 'in_progress']):
        out.append((f'maint:{m.pk}', f'صيانة مفتوحة: {m.equipment.name}',
                    f'عملية صيانة "{m.description[:50]}" للمعدة {m.equipment.name} ما زالت مفتوحة',
                    '/resources/maintenance/'))
    return out


def _check_budget(today=None):
    out = []
    from projects.models import Project
    from finance.services import project_financials
    for p in Project.objects.filter(status='in_progress').exclude(contract__isnull=True):
        f = project_financials(p)
        if f['contract_value'] > 0 and f['actual_cost'] > f['contract_value'] * Decimal('0.9'):
            out.append((f'budget:{p.pk}', f'اقتراب من تجاوز الميزانية: {p.code}',
                        f'التكلفة الفعلية لمشروع {p.name} بلغت {f["actual_cost"]:,.0f} '
                        f'من قيمة العقد {f["contract_value"]:,.0f}',
                        f'/projects/{p.pk}/'))
    return out


def run_alerts():
    """تشغيل الفحص وبناء التنبيهات الجديدة. يعيد عدد التنبيهات المضافة."""
    from .models import Notification
    today = timezone.localdate()
    alerts = []
    for fn in (_check_tasks, _check_contracts, _check_payments, _check_stock,
               _check_requests, _check_issues, _check_maintenance, _check_budget):
        try:
            alerts.extend(fn(today))
        except Exception:
            continue
    added = 0
    for key, title, message, link in alerts:
        if not Notification.objects.filter(key=key).exists():
            Notification.objects.create(key=key, title=title, message=message, link=link)
            added += 1
    return added


def email_alerts():
    """إرسال التنبيهات غير المقروءة بالبريد (يُنشّط بإعداد النظام notify_email=1).
    افتراضيًا يستخدم Django الـ backend 'console' فيظهر البريد في سجل الخادم."""
    from django.conf import settings
    from django.core.mail import send_mail
    from .models import Notification, SystemSetting

    enabled = SystemSetting.objects.filter(key='notify_email', value='1').exists()
    if not enabled:
        return 0
    recipients = [x.strip() for x in
                  SystemSetting.objects.filter(key='notify_email_to').first().value.split(',')
                  if x.strip()] if SystemSetting.objects.filter(key='notify_email_to').exists() else []
    unread = Notification.objects.filter(is_read=False).order_by('-created')[:50]
    if not recipients or not unread.exists():
        return 0
    body = '\n'.join(f'• {n.title}\n  {n.message}\n  الرابط: {settings.ALLOWED_HOSTS and ""}{n.link}'
                     for n in unread)
    send_mail(
        subject='تنبيهات نظام بنيان',
        message=body,
        from_email='bunyan@local',
        recipient_list=recipients,
        fail_silently=True,
    )
    return unread.count()
