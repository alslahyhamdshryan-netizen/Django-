"""أرقام لوحة التحكم الرئيسية."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Sum
from django.utils import timezone


def kpis():
    today = timezone.localdate()
    from projects.models import Project, Task
    from projects.services import boq_totals
    from contracts.models import Contract, PaymentSchedule
    from finance.models import Payment, Expense, Income, Invoice
    from finance.services import project_financials
    from inventory.services import low_stock_materials
    from procurement.models import PurchaseRequest
    from quality.models import Issue
    from handover.models import MaintenanceRequest
    from core.models import AuditLog, Notification

    projs = Project.objects.all()
    projects_total = projs.count()
    active = projs.filter(status='in_progress').count()
    on_hold = projs.filter(status='on_hold').count()
    completed = projs.filter(status='completed').count()
    late = projs.filter(status__in=['in_progress', 'on_hold']).filter(end_date__lt=today).count()

    contracts_value = Contract.objects.aggregate(s=Sum('value'))['s'] or Decimal('0')
    total_costs = Expense.objects.aggregate(s=Sum('amount'))['s'] or Decimal('0')
    total_received = Payment.objects.filter(pay_type='incoming').aggregate(s=Sum('amount'))['s'] or Decimal('0')
    total_paid_out = Payment.objects.filter(pay_type='outgoing').aggregate(s=Sum('amount'))['s'] or Decimal('0')
    total_income = Income.objects.aggregate(s=Sum('amount'))['s'] or Decimal('0')

    # الربح المتوقع = مجموع (سعر البيع − التكلفة) لبنود BOQ لكل المشاريع
    expected_profit = Decimal('0')
    for p in projs:
        cost, price, _exp = boq_totals(p)
        expected_profit += (price - cost)

    # الربح الفعلي = الإيرادات − التكاليف (نظام نقدي)
    actual_profit = total_income - total_costs

    project_bars = []
    for p in projs.filter(status='in_progress')[:5]:
        project_bars.append({
            'project': p,
            'progress': p.progress,
            'financials': project_financials(p),
        })

    late_tasks = Task.objects.filter(status__in=['todo', 'in_progress'])\
        .exclude(end_date__isnull=True).filter(end_date__lt=today)[:8]

    upcoming = PaymentSchedule.objects.filter(status__in=['open', 'partial'])\
        .exclude(due_date__isnull=True)\
        .filter(due_date__gte=today, due_date__lte=today + timedelta(days=30))[:8]

    due_invoices = Invoice.objects.filter(status__in=['issued', 'partial', 'overdue'])\
        .exclude(due_date__isnull=True).filter(due_date__lte=today)[:8]

    low_stock = low_stock_materials()[:8]
    pending_po = PurchaseRequest.objects.filter(status='submitted').count()
    open_issues = Issue.objects.filter(status__in=['open', 'in_progress']).count()
    maint_reqs = MaintenanceRequest.objects.filter(status__in=['open', 'assigned', 'in_progress']).count()
    recent = AuditLog.objects.all()[:10]
    unread = Notification.objects.filter(is_read=False).count()
    alerts = Notification.objects.filter(is_read=False).order_by('-created')[:6]

    # تدفق نقدي آخر 6 أشهر (لرسم بياني)
    from finance.services import cashflow
    cf = cashflow((today - timedelta(days=180)).replace(day=1), today)[-6:]
    vals = [abs(r['in']) for r in cf] + [abs(r['out']) for r in cf]
    cf_max = max(vals) if vals else Decimal('1')
    if cf_max == 0:
        cf_max = Decimal('1')
    for r in cf:
        r['in_pct'] = float(abs(r['in']) / cf_max * 100)
        r['out_pct'] = float(abs(r['out']) / cf_max * 100)
        m = r['month']  # YYYY-MM
        r['label'] = f'{m[5:7]}/{m[2:4]}'
    cashflow_rows = cf

    return {
        'projects_total': projects_total,
        'active': active,
        'on_hold': on_hold,
        'late': late,
        'completed': completed,
        'contracts_value': contracts_value,
        'total_costs': total_costs,
        'total_received': total_received,
        'total_paid_out': total_paid_out,
        'expected_profit': expected_profit,
        'actual_profit': actual_profit,
        'project_bars': project_bars,
        'late_tasks': late_tasks,
        'upcoming_payments': upcoming,
        'due_invoices': due_invoices,
        'low_stock': low_stock,
        'pending_po': pending_po,
        'open_issues': open_issues,
        'maint_reqs': maint_reqs,
        'recent': recent,
        'unread': unread,
        'alerts': alerts,
        'cashflow': cashflow_rows,
        'today': today,
    }
