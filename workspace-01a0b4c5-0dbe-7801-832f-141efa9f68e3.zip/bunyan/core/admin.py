from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from . import models

for _name in dir(models):
    _obj = getattr(models, _name)
    if isinstance(_obj, type) and hasattr(_obj, '_meta') and not _obj._meta.abstract:
        if _name != 'User':
            admin.site.register(_obj)

admin.site.register(models.User, UserAdmin)
