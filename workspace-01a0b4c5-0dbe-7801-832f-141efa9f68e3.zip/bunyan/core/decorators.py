from functools import wraps

from django.core.exceptions import PermissionDenied


def roles(*allowed):
    """قيود الصلاحيات: يحدد الأدوار المسموح لها بتنفيذ الإجراء."""
    def deco(f):
        @wraps(f)
        def wrapper(request, *args, **kw):
            u = request.user
            if not (u.is_authenticated and (u.is_superuser or u.role in allowed)):
                raise PermissionDenied('ليست لديك صلاحية تنفيذ هذا الإجراء')
            return f(request, *args, **kw)
        return wrapper
    return deco
