"""مسار المستخدم الحالي (يستخدمه سجل التدقيق)."""
import threading

_local = threading.local()


def set_user(user):
    _local.u = user


def get_user():
    return getattr(_local, 'u', None)
