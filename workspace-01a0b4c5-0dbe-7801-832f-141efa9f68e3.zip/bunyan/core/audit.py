"""سجل التدقيق: من فعل؟ ماذا فعل؟ متى؟ وما الذي تغير؟"""
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver

SKIP = {'AuditLog', 'Notification'}


def _diff(old, new):
    d = {}
    for f in new._meta.concrete_fields:
        try:
            a, b = getattr(old, f.name, None), getattr(new, f.name, None)
            if a != b:
                d[f.name] = [str(a) if a is not None else None,
                             str(b) if b is not None else None]
        except Exception:
            pass
    return d


def _log(action, sender, instance, changes=None):
    try:
        from .context import get_user
        from .models import AuditLog
        AuditLog.objects.create(
            user=get_user(),
            action=action,
            app_label=sender.app_label,
            model_name=sender.__name__,
            object_id=str(instance.pk),
            object_repr=str(instance)[:200],
            changes=changes or {},
        )
    except Exception:
        pass


@receiver(post_save)
def _audit_save(sender, instance, created, **kw):
    if sender.__name__ in SKIP:
        return
    if created:
        _log('create', sender, instance)
    else:
        try:
            old = sender.objects.get(pk=instance.pk)
            changes = _diff(old, instance)
            if changes:
                _log('update', sender, instance, changes)
        except Exception:
            pass


@receiver(post_delete)
def _audit_delete(sender, instance, **kw):
    if sender.__name__ in SKIP:
        return
    _log('delete', sender, instance)
