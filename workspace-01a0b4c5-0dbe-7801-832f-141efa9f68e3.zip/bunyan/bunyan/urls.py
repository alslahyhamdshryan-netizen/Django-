from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('crm/', include('crm.urls')),
    path('projects/', include('projects.urls')),
    path('contracts/', include('contracts.urls')),
    path('procurement/', include('procurement.urls')),
    path('inventory/', include('inventory.urls')),
    path('resources/', include('resources.urls')),
    path('finance/', include('finance.urls')),
    path('quality/', include('quality.urls')),
    path('documents/', include('documents.urls')),
    path('handover/', include('handover.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
