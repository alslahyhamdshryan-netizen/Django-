"""اختبار دخان: يتحقق من أن كل الصفحات الرئيسية تُعرض بنجاح (HTTP 200)."""
import os
import sys

import django

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bunyan.settings')
django.setup()

from django.test import Client  # noqa: E402

URLS = [
    '/',
    '/branches/', '/departments/', '/users/', '/settings/', '/notifications/',
    '/crm/clients/', '/crm/clients/1/', '/crm/communications/',
    '/projects/', '/projects/1/', '/projects/1/boq/', '/projects/1/progress/', '/projects/1/gantt/',
    '/projects/1/print/', '/projects/stages/', '/projects/tasks/', '/projects/daily/',
    '/projects/meetings/', '/projects/meetings/1/',
    '/contracts/quotes/', '/contracts/quotes/1/', '/contracts/contracts/', '/contracts/contracts/1/',
    '/contracts/change-orders/',
    '/procurement/suppliers/', '/procurement/requests/', '/procurement/requests/1/',
    '/procurement/orders/', '/procurement/orders/1/', '/procurement/receipts/', '/procurement/receipts/1/',
    '/procurement/invoices/',
    '/inventory/materials/', '/inventory/warehouses/', '/inventory/stock/',
    '/inventory/issues/', '/inventory/issues/1/', '/inventory/transactions/',
    '/resources/workers/', '/resources/workers/1/', '/resources/attendance/', '/resources/equipment/',
    '/resources/equipment/1/', '/resources/maintenance/', '/resources/subcontractors/',
    '/resources/subcontractors/1/',
    '/finance/statements/', '/finance/statements/1/', '/finance/statements/1/print/',
    '/finance/payments/', '/finance/expenses/', '/finance/income/', '/finance/invoices/',
    '/finance/invoices/1/', '/finance/invoices/1/print/', '/finance/reports/',
    '/finance/reports/csv/?report=projects',
    '/api/kpis/', '/api/projects/', '/api/projects/1/financials/', '/api/stock/', '/api/alerts/',
    '/api/payments/', '/api/statements/', '/api/workers/', '/api/suppliers/',
    '/field/', '/field/?project=1&tab=attendance',
    '/quality/inspections/', '/quality/checklists/', '/quality/issues/', '/quality/risks/',
    '/documents/documents/', '/documents/drawings/', '/documents/images/',
    '/handover/punch/', '/handover/handovers/', '/handover/warranties/', '/handover/maintenance-requests/',
]


def main():
    c = Client()
    ok = c.login(username='admin', password='Admin@12345')
    if not ok:
        print('FAIL: login')
        sys.exit(1)
    failed = []
    for u in URLS:
        r = c.get(u)
        mark = 'OK ' if r.status_code == 200 else 'ERR'
        print(f'{mark} {r.status_code} {u}')
        if r.status_code != 200:
            failed.append(u)
    if failed:
        print(f'\nFAILED {len(failed)} urls: {failed}')
        sys.exit(1)
    print(f'\nALL OK — {len(URLS)} pages rendered')


if __name__ == '__main__':
    main()
