from django import forms
from django.shortcuts import get_object_or_404, redirect, render

from core.crud import crud as _crud
from core.utils import field_list, row_for
from .models import Document, Drawing, DrawingVersion, ProjectImage

document_list, document_create, document_update = _crud(
    Document, 'المستندات', ['category', 'title', 'project', 'note', 'created'],
    order_by=['-created'])

image_list, image_create, image_update = _crud(
    ProjectImage, 'صور المشروع', ['project', 'stage', 'title', 'date', 'note'],
    order_by=['-date'])


class DrawingForm(forms.ModelForm):
    class Meta:
        model = Drawing
        fields = ['project', 'drawing_no', 'title']


def drawing_list(request):
    columns = field_list(Drawing, ['project', 'drawing_no', 'title'])
    qs = Drawing.objects.select_related('project').order_by('project', 'drawing_no')
    return render(request, 'core/generic_list.html', {
        'page_title': 'المخططات', 'columns': columns,
        'create_url': 'documents: drawing_create'.replace(' ', ''),
        'create_label': 'إضافة مخطط',
        'rows': [row_for(d, columns) for d in qs]})


def drawing_form(request, pk=None):
    d = get_object_or_404(Drawing, pk=pk) if pk else None
    if request.method == 'POST':
        form = DrawingForm(request.POST, instance=d)
        if form.is_valid():
            form.save()
            return redirect('documents:drawing_list')
    else:
        form = DrawingForm(instance=d)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل مخطط' if d else 'إضافة مخطط', 'form': form})


class DrawingVersionForm(forms.ModelForm):
    class Meta:
        model = DrawingVersion
        fields = ['drawing', 'version_no', 'file', 'revision_date', 'note']


def drawing_version_form(request, pk=None):
    v = get_object_or_404(DrawingVersion, pk=pk) if pk else None
    if request.method == 'POST':
        form = DrawingVersionForm(request.POST, instance=v)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                existing = obj.drawing.versions.count()
                obj.version_no = obj.version_no or existing + 1
            if obj.user_id is None:
                obj.user = request.user
            obj.save()
            return redirect('documents:drawing_list')
    else:
        form = DrawingVersionForm(instance=v)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل إصدار' if v else 'إضافة إصدار مخطط', 'form': form})
