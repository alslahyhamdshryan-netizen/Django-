from django.db import models


class Document(models.Model):
    CATEGORIES = [
        ('contract', 'عقد'),
        ('drawing', 'مخطط'),
        ('invoice', 'فاتورة'),
        ('report', 'تقرير'),
        ('meeting', 'محضر اجتماع'),
        ('statement', 'مستخلص'),
        ('delivery', 'شهادة استلام'),
        ('other', 'أخرى'),
    ]
    project = models.ForeignKey('projects.Project', on_delete=models.CASCADE, related_name='documents', verbose_name='المشروع')
    category = models.CharField('التصنيف', max_length=20, choices=CATEGORIES, default='other')
    title = models.CharField('العنوان', max_length=250)
    file = models.FileField('الملف', upload_to='documents/%Y/%m/', null=True, blank=True)
    note = models.CharField('ملاحظة', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')
    created = models.DateTimeField('التاريخ', auto_now_add=True)

    class Meta:
        verbose_name = 'المستند'
        verbose_name_plural = 'المستندات'
        ordering = ['-created']

    def __str__(self):
        return self.title


class Drawing(models.Model):
    project = models.ForeignKey('projects.Project', on_delete=models.CASCADE, related_name='drawings', verbose_name='المشروع')
    drawing_no = models.CharField('رقم المخطط', max_length=30)
    title = models.CharField('العنوان', max_length=250)

    class Meta:
        verbose_name = 'المخطط'
        verbose_name_plural = 'المخططات'
        unique_together = ['project', 'drawing_no']

    def __str__(self):
        return f'{self.drawing_no} — {self.title}'

    @property
    def current_version(self):
        return self.versions.order_by('-version_no').first()


class DrawingVersion(models.Model):
    drawing = models.ForeignKey(Drawing, on_delete=models.CASCADE, related_name='versions', verbose_name='المخطط')
    version_no = models.PositiveIntegerField('رقم الإصدار')
    file = models.FileField('الملف', upload_to='drawings/%Y/%m/', null=True, blank=True)
    revision_date = models.DateField('تاريخ المراجعة', null=True, blank=True)
    note = models.CharField('ملاحظات المراجعة', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'إصدار مخطط'
        verbose_name_plural = 'إصدارات المخططات'
        unique_together = ['drawing', 'version_no']
        ordering = ['-version_no']

    def __str__(self):
        return f'{self.drawing.drawing_no} — إصدار {self.version_no:02d}'

    @property
    def is_current(self):
        return self.drawing.versions.order_by('-version_no').first() == self


class ProjectImage(models.Model):
    project = models.ForeignKey('projects.Project', on_delete=models.CASCADE, related_name='images', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المرحلة')
    title = models.CharField('العنوان', max_length=250)
    image = models.ImageField('الصورة', upload_to='images/%Y/%m/', null=True, blank=True)
    date = models.DateField('التاريخ', null=True, blank=True)
    note = models.CharField('ملاحظة', max_length=250, blank=True)

    class Meta:
        verbose_name = 'صورة المشروع'
        verbose_name_plural = 'صور المشروع'
        ordering = ['-date']

    def __str__(self):
        return self.title
