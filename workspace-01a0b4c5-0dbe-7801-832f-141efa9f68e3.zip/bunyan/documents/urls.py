from django.urls import path

from . import views

app_name = 'documents'

urlpatterns = [
    path('documents/', views.document_list, name='document_list'),
    path('documents/add/', views.document_create, name='document_create'),
    path('documents/<int:pk>/edit/', views.document_update, name='document_update'),
    path('drawings/', views.drawing_list, name='drawing_list'),
    path('drawings/add/', views.drawing_form, name='drawing_create'),
    path('drawings/<int:pk>/edit/', views.drawing_form, name='drawing_update'),
    path('versions/add/', views.drawing_version_form, name='version_create'),
    path('versions/<int:pk>/edit/', views.drawing_version_form, name='version_update'),
    path('images/', views.image_list, name='image_list'),
    path('images/add/', views.image_create, name='image_create'),
    path('images/<int:pk>/edit/', views.image_update, name='image_update'),
]
