from django import forms
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.crud import crud as _crud
from core.decorators import roles
from core.utils import field_list, row_for
from .models import (Material, MaterialIssue, MaterialIssueItem, MaterialReturn,
                     MaterialReturnItem, StockCount, StockCountLine,
                     StockTransaction, StockTransfer, StockTransferItem, Warehouse)
from .services import (confirm_count, low_stock_materials, perform_issue,
                       perform_return, perform_transfer, warehouse_balances)

material_list, material_create, material_update = _crud(
    Material, 'المواد', ['code', 'name', 'category', 'unit', 'min_qty', 'last_cost', 'active'])
warehouse_list, warehouse_create, warehouse_update = _crud(
    Warehouse, 'المخازن', ['code', 'name', 'wh_type', 'project', 'branch'])

tx_list, tx_create, tx_update = _crud(
    StockTransaction, 'حركات المخزون', ['date', 'warehouse', 'material', 'tx_type', 'qty', 'unit_cost', 'project', 'ref'],
    order_by=['-date'])


def stock_view(request):
    whs = Warehouse.objects.all()
    wh_id = request.GET.get('wh') or (whs.first().pk if whs.exists() else None)
    wh = get_object_or_404(Warehouse, pk=wh_id) if wh_id else None
    rows = warehouse_balances(wh) if wh else []
    total_qty_value = 0
    for r in rows:
        r['value'] = r['qty'] * r['material'].last_cost
        total_qty_value += r['value']
    low = low_stock_materials()
    return render(request, 'inventory/stock.html', {
        'page_title': 'أرصدة المخزون',
        'warehouses': whs,
        'warehouse': wh,
        'rows': rows,
        'low_stock': low,
        'total_value': total_qty_value,
    })


class MaterialIssueForm(forms.ModelForm):
    class Meta:
        model = MaterialIssue
        fields = ['issue_no', 'project', 'stage', 'warehouse', 'date', 'status', 'notes']


def issue_list(request):
    columns = field_list(MaterialIssue, ['issue_no', 'project', 'stage', 'warehouse', 'date', 'status'])
    qs = MaterialIssue.objects.select_related('project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'التصرفات (صرف مواد)', 'columns': columns,
        'create_url': 'inventory:issue_create', 'create_label': 'إضافة تصرف',
        'rows': [row_for(i, columns, f'/inventory/issues/{i.pk}/') for i in qs]})


def issue_form(request, pk=None):
    i = get_object_or_404(MaterialIssue, pk=pk) if pk else None
    if request.method == 'POST':
        form = MaterialIssueForm(request.POST, instance=i)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.issue_no = obj.issue_no or f'ISS-{timezone.localdate().year}-{MaterialIssue.objects.count() + 1:03d}'
            obj.save()
            return redirect(f'/inventory/issues/{obj.pk}/')
    else:
        form = MaterialIssueForm(instance=i,
                                 initial={} if i else {'issue_no': f'ISS-{timezone.localdate().year}-{MaterialIssue.objects.count() + 1:03d}'})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل تصرف' if i else 'إضافة تصرف مواد', 'form': form})


class IssueItemForm(forms.ModelForm):
    class Meta:
        model = MaterialIssueItem
        fields = '__all__'


def issue_item_form(request, pk=None):
    it = get_object_or_404(MaterialIssueItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = IssueItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/inventory/issues/{obj.issue_id}/')
    else:
        form = IssueItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند للتصرف', 'form': form})


def issue_detail(request, pk):
    i = get_object_or_404(MaterialIssue, pk=pk)
    items = i.items.select_related('material')
    total = sum((it.qty * (it.unit_cost or it.material.last_cost) for it in items), 0)
    return render(request, 'inventory/issue_detail.html', {
        'page_title': f'التصرف {i.issue_no}',
        'issue': i,
        'items': items,
        'total': total,
        'returns': i.returns.all(),
    })


@roles('admin', 'pm', 'warehouse')
def issue_status(request, pk):
    i = get_object_or_404(MaterialIssue, pk=pk)
    status = request.POST.get('status')
    allowed = {'requested': ['approved'], 'approved': ['requested']}
    if status in allowed.get(i.status, []):
        i.status = status
        i.save()
    return redirect(f'/inventory/issues/{i.pk}/')


@roles('admin', 'warehouse')
def issue_perform(request, pk):
    """تنفيذ الصرف: المخزون ينقص ← تكلفة المشروع/المرحلة تزداد ← التقارير تتحدث."""
    i = get_object_or_404(MaterialIssue, pk=pk)
    if request.method == 'POST':
        try:
            perform_issue(i)
        except ValueError:
            pass
    return redirect(f'/inventory/issues/{i.pk}/')


class MaterialReturnForm(forms.ModelForm):
    class Meta:
        model = MaterialReturn
        fields = ['issue', 'date', 'reason']


def return_list(request):
    columns = field_list(MaterialReturn, ['issue', 'date', 'reason'])
    qs = MaterialReturn.objects.select_related('issue').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'إرجاعات المواد', 'columns': columns,
        'create_url': 'inventory:return_create', 'create_label': 'إضافة إرجاع',
        'rows': [row_for(r, columns) for r in qs]})


def return_form(request, pk=None):
    r = get_object_or_404(MaterialReturn, pk=pk) if pk else None
    if request.method == 'POST':
        form = MaterialReturnForm(request.POST, instance=r)
        if form.is_valid():
            form.save()
            return redirect('inventory:return_list')
    else:
        form = MaterialReturnForm(instance=r)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل إرجاع' if r else 'إضافة إرجاع مواد', 'form': form})


class ReturnItemForm(forms.ModelForm):
    class Meta:
        model = MaterialReturnItem
        fields = '__all__'


def return_item_form(request, pk=None):
    it = get_object_or_404(MaterialReturnItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = ReturnItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect('inventory:return_list')
    else:
        form = ReturnItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند إرجاع' if it else 'إضافة بند إرجاع', 'form': form})


@roles('admin', 'warehouse')
def return_perform(request, pk):
    r = get_object_or_404(MaterialReturn, pk=pk)
    if request.method == 'POST':
        perform_return(r)
    return redirect('inventory:return_list')


class StockTransferForm(forms.ModelForm):
    class Meta:
        model = StockTransfer
        fields = ['transfer_no', 'from_warehouse', 'to_warehouse', 'date', 'notes']


def transfer_list(request):
    columns = field_list(StockTransfer, ['transfer_no', 'from_warehouse', 'to_warehouse', 'date'])
    qs = StockTransfer.objects.select_related('from_warehouse', 'to_warehouse').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'التحويلات بين المخازن', 'columns': columns,
        'create_url': 'inventory:transfer_create', 'create_label': 'إضافة تحويل',
        'rows': [row_for(t, columns) for t in qs]})


def transfer_form(request, pk=None):
    t = get_object_or_404(StockTransfer, pk=pk) if pk else None
    if request.method == 'POST':
        form = StockTransferForm(request.POST, instance=t)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.transfer_no = obj.transfer_no or f'TR-{StockTransfer.objects.count() + 1:03d}'
            obj.save()
            return redirect('inventory:transfer_list')
    else:
        form = StockTransferForm(instance=t, initial={} if t else {'transfer_no': f'TR-{StockTransfer.objects.count() + 1:03d}'})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل تحويل' if t else 'إضافة تحويل', 'form': form})


class TransferItemForm(forms.ModelForm):
    class Meta:
        model = StockTransferItem
        fields = '__all__'


def transfer_item_form(request, pk=None):
    it = get_object_or_404(StockTransferItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = TransferItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect('inventory:transfer_list')
    else:
        form = TransferItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند تحويل' if it else 'إضافة بند تحويل', 'form': form})


@roles('admin', 'warehouse')
def transfer_perform(request, pk):
    t = get_object_or_404(StockTransfer, pk=pk)
    if request.method == 'POST':
        perform_transfer(t)
    return redirect('inventory:transfer_list')


class StockCountForm(forms.ModelForm):
    class Meta:
        model = StockCount
        fields = ['count_no', 'warehouse', 'date', 'status']


def count_list(request):
    columns = field_list(StockCount, ['count_no', 'warehouse', 'date', 'status'])
    qs = StockCount.objects.select_related('warehouse').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'جداول الجرد', 'columns': columns,
        'create_url': 'inventory:count_create', 'create_label': 'إضافة جرد',
        'rows': [row_for(c, columns) for c in qs]})


def count_form(request, pk=None):
    c = get_object_or_404(StockCount, pk=pk) if pk else None
    if request.method == 'POST':
        form = StockCountForm(request.POST, instance=c)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.count_no = obj.count_no or f'CN-{StockCount.objects.count() + 1:03d}'
            obj.save()
            return redirect('inventory:count_list')
    else:
        form = StockCountForm(instance=c, initial={} if c else {'count_no': f'CN-{StockCount.objects.count() + 1:03d}'})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل جرد' if c else 'إضافة جرد', 'form': form})


class CountLineForm(forms.ModelForm):
    class Meta:
        model = StockCountLine
        fields = '__all__'


def count_line_form(request, pk=None):
    it = get_object_or_404(StockCountLine, pk=pk) if pk else None
    if request.method == 'POST':
        form = CountLineForm(request.POST, instance=it)
        if form.is_valid():
            form.save()
            return redirect('inventory:count_list')
    else:
        form = CountLineForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل سطر جرد' if it else 'إضافة سطر جرد', 'form': form})


@roles('admin', 'warehouse')
def count_confirm(request, pk):
    c = get_object_or_404(StockCount, pk=pk)
    if request.method == 'POST':
        confirm_count(c)
    return redirect('inventory:count_list')
