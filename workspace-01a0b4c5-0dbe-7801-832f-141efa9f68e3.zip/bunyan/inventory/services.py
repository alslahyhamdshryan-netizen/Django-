"""خدمات المخزون: الأرصدة، الصرف، الإرجاع، التحويل، الجرد.

قاعدة احتساب التكلفة:
- الاستلام (شراء): يُحمَّل التكلفة على المشروع عند الاستلام إذا كان الأمر الشراء
  مرتبطًا بمشروع (المواد دخلت مباشرة لمخزن المشروع).
- الصرف: يُحمَّل التكلفة على المشروع عند الصرف إذا كانت المادة تخرج من مخزن
  آخر (رئيسي/فرعي) إلى مخزن مشروع مختلف — لتفادي الازدواج.
"""
from decimal import Decimal

from django.db.models import Q


def total_stock(material):
    return stock_balance_all(material)


def stock_balance(warehouse, material):
    qs = warehouse.transactions.filter(material=material)
    return sum((t.signed_qty for t in qs), Decimal('0'))


def stock_balance_all(material):
    return sum((t.signed_qty for t in material.stock_transactions.all()), Decimal('0'))


def warehouse_balances(warehouse):
    """رصيد كل مادة في المخزن + التالف + المصروف."""
    from .models import Material
    rows = []
    for m in Material.objects.filter(active=True):
        qs = warehouse.transactions.filter(material=m)
        if not qs.exists():
            continue
        qty = sum((t.signed_qty for t in qs), Decimal('0'))
        damaged = sum((t.qty for t in qs if t.tx_type == 'damage'), Decimal('0'))
        issued = sum((t.qty for t in qs if t.tx_type == 'issue'), Decimal('0'))
        rows.append({'material': m, 'qty': qty, 'damaged': damaged, 'issued': issued})
    return rows


def low_stock_materials():
    """المواد التي وصل رصيدها (كل المخازن) للحد الأدنى."""
    from .models import Material
    out = []
    for m in Material.objects.filter(active=True, min_qty__gt=0):
        balance = stock_balance_all(m)
        if balance <= m.min_qty:
            out.append((m, balance))
    return out


def perform_issue(issue):
    """تنفيذ صرف مواد: خصم المخزون + تحميل التكلفة على المشروع والمرحلة (إن لزم)."""
    from .models import StockTransaction
    from finance.models import Expense
    from core.context import get_user as get_request_user

    if issue.status != 'approved':
        raise ValueError('يجب اعتماد التصرف أولًا')
    user = get_request_user()
    charge_cost = issue.warehouse.project_id in (None,) or \
        issue.warehouse.project_id != issue.project_id

    for it in issue.items.all():
        unit_cost = it.unit_cost or it.material.last_cost or Decimal('0')
        StockTransaction.objects.create(
            warehouse=issue.warehouse,
            material=it.material,
            tx_type='issue',
            qty=it.qty,
            unit_cost=unit_cost,
            project=issue.project,
            stage=issue.stage,
            ref=issue.issue_no,
            user=user,
            note='صرف لمشروع',
        )
        if charge_cost:
            Expense.objects.create(
                project=issue.project,
                stage=issue.stage,
                category='material',
                amount=it.qty * unit_cost,
                date=issue.date,
                description=f'مواد — {it.material.name} × {it.qty} ({issue.issue_no})',
                issue=issue,
                user=user,
            )
    issue.status = 'issued'
    issue.save()
    return issue


def perform_return(mreturn):
    """إرجاع مواد من مشروع إلى مخزن: إضافة للمخزون − التكلفة."""
    from .models import StockTransaction
    from finance.models import Expense
    from core.context import get_user as get_request_user

    user = get_request_user()
    issue = mreturn.issue
    for it in mreturn.items.all():
        unit_cost = it.unit_cost or it.material.last_cost or Decimal('0')
        StockTransaction.objects.create(
            warehouse=issue.warehouse,
            material=it.material,
            tx_type='return',
            qty=it.qty,
            unit_cost=unit_cost,
            project=issue.project,
            stage=issue.stage,
            ref=issue.issue_no,
            user=user,
            note='إرجاع مواد',
        )
        if issue.warehouse.project_id in (None,) or issue.warehouse.project_id != issue.project_id:
            Expense.objects.create(
                project=issue.project,
                stage=issue.stage,
                category='material',
                amount=-(it.qty * unit_cost),
                date=mreturn.date,
                description=f'عكس مواد مرحجة — {it.material.name} × {it.qty}',
                issue=issue,
                user=user,
            )
    return mreturn


def perform_transfer(transfer):
    """تحويل بين مخازن: صادر من الأول + وارد للثاني (بدون تكلفة جديدة)."""
    from .models import StockTransaction
    from core.context import get_user as get_request_user

    user = get_request_user()
    for it in transfer.items.all():
        unit_cost = it.unit_cost or it.material.last_cost or Decimal('0')
        StockTransaction.objects.create(
            warehouse=transfer.from_warehouse,
            material=it.material,
            tx_type='transfer_out',
            qty=it.qty,
            unit_cost=unit_cost,
            ref=transfer.transfer_no,
            user=user,
            note=f'تحويل إلى {transfer.to_warehouse.name}',
        )
        StockTransaction.objects.create(
            warehouse=transfer.to_warehouse,
            material=it.material,
            tx_type='transfer_in',
            qty=it.qty,
            unit_cost=unit_cost,
            ref=transfer.transfer_no,
            user=user,
            note=f'تحويل من {transfer.from_warehouse.name}',
        )
    return transfer


def confirm_count(count):
    """تأكيد الجرد: تسوية الفروقات بحركة adjust."""
    from .models import StockTransaction
    from core.context import get_user as get_request_user

    user = get_request_user()
    for line in count.lines.all():
        diff = line.diff
        if diff == 0:
            continue
        # عجز = حركة سالبة (تالف/نقص)، زيادة = حركة موجبة (تسوية)
        StockTransaction.objects.create(
            warehouse=count.warehouse,
            material=line.material,
            tx_type='damage' if diff < 0 else 'adjust',
            qty=abs(diff),
            unit_cost=line.unit_cost,
            ref=count.count_no,
            user=user,
            note='تسوية جرد' + (' (عجز)' if diff < 0 else ' (زيادة)'),
        )
    count.status = 'confirmed'
    count.save()
    return count
