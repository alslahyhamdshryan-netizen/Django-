from django.urls import path

from . import views

app_name = 'inventory'

urlpatterns = [
    path('materials/', views.material_list, name='material_list'),
    path('materials/add/', views.material_create, name='material_create'),
    path('materials/<int:pk>/edit/', views.material_update, name='material_update'),
    path('warehouses/', views.warehouse_list, name='warehouse_list'),
    path('warehouses/add/', views.warehouse_create, name='warehouse_create'),
    path('warehouses/<int:pk>/edit/', views.warehouse_update, name='warehouse_update'),
    path('stock/', views.stock_view, name='stock'),
    path('issues/', views.issue_list, name='issue_list'),
    path('issues/add/', views.issue_form, name='issue_create'),
    path('issues/<int:pk>/', views.issue_detail, name='issue_detail'),
    path('issues/<int:pk>/edit/', views.issue_form, name='issue_update'),
    path('issues/<int:pk>/status/', views.issue_status, name='issue_status'),
    path('issues/<int:pk>/perform/', views.issue_perform, name='issue_perform'),
    path('issue-items/add/', views.issue_item_form, name='issue_item_create'),
    path('issue-items/<int:pk>/edit/', views.issue_item_form, name='issue_item_update'),
    path('returns/', views.return_list, name='return_list'),
    path('returns/add/', views.return_form, name='return_create'),
    path('returns/<int:pk>/perform/', views.return_perform, name='return_perform'),
    path('return-items/add/', views.return_item_form, name='return_item_create'),
    path('return-items/<int:pk>/edit/', views.return_item_form, name='return_item_update'),
    path('transfers/', views.transfer_list, name='transfer_list'),
    path('transfers/add/', views.transfer_form, name='transfer_create'),
    path('transfers/<int:pk>/perform/', views.transfer_perform, name='transfer_perform'),
    path('transfer-items/add/', views.transfer_item_form, name='transfer_item_create'),
    path('transfer-items/<int:pk>/edit/', views.transfer_item_form, name='transfer_item_update'),
    path('counts/', views.count_list, name='count_list'),
    path('counts/add/', views.count_form, name='count_create'),
    path('counts/<int:pk>/confirm/', views.count_confirm, name='count_confirm'),
    path('count-lines/add/', views.count_line_form, name='count_line_create'),
    path('count-lines/<int:pk>/edit/', views.count_line_form, name='count_line_update'),
    path('transactions/', views.tx_list, name='tx_list'),
]
