from django.db import models


class Material(models.Model):
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم المادة', max_length=200)
    category = models.CharField('التصنيف', max_length=100, blank=True)
    unit = models.CharField('الوحدة', max_length=30, default='قطعة')
    min_qty = models.DecimalField('الحد الأدنى', max_digits=14, decimal_places=2, default=0)
    last_cost = models.DecimalField('آخر تكلفة', max_digits=14, decimal_places=3, default=0)
    active = models.BooleanField('مفعل', default=True)

    class Meta:
        verbose_name = 'المادة'
        verbose_name_plural = 'المواد'

    def __str__(self):
        return self.name

    @property
    def total_stock(self):
        from inventory.services import total_stock
        return total_stock(self)

    @property
    def total_used(self):
        return self.stock_transactions.filter(tx_type='issue')\
            .aggregate(s=models.Sum('qty'))['s'] or 0


class Warehouse(models.Model):
    WH_TYPES = [
        ('main', 'مخزن رئيسي'),
        ('project', 'مخزن مشروع'),
        ('sub', 'مخزن فرعي'),
    ]
    code = models.CharField('الرمز', max_length=30, unique=True)
    name = models.CharField('اسم المخزن', max_length=150)
    wh_type = models.CharField('النوع', max_length=20, choices=WH_TYPES, default='main')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='warehouses', verbose_name='المشروع')
    branch = models.ForeignKey('core.Branch', null=True, blank=True, on_delete=models.SET_NULL,
                               related_name='warehouses', verbose_name='الفرع')

    class Meta:
        verbose_name = 'المخزن'
        verbose_name_plural = 'المخازن'

    def __str__(self):
        return self.name


class StockTransaction(models.Model):
    TX_TYPES = [
        ('purchase', 'استلام شراء'),
        ('issue', 'صرف لمشروع'),
        ('return', 'إرجاع'),
        ('transfer_in', 'تحويل وارد'),
        ('transfer_out', 'تحويل صادر'),
        ('damage', 'تالف'),
        ('adjust', 'جرد/تسوية'),
    ]
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name='transactions', verbose_name='المخزن')
    material = models.ForeignKey(Material, on_delete=models.PROTECT, related_name='stock_transactions', verbose_name='المادة')
    tx_type = models.CharField('نوع الحركة', max_length=20, choices=TX_TYPES)
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='stock_transactions', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL,
                              related_name='stock_transactions', verbose_name='المرحلة')
    ref = models.CharField('مرجع', max_length=60, blank=True)
    note = models.CharField('ملاحظة', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')
    date = models.DateTimeField('التاريخ', auto_now_add=True)

    class Meta:
        verbose_name = 'حركة مخزون'
        verbose_name_plural = 'حركات المخزون'
        ordering = ['-date']

    def __str__(self):
        return f'{self.get_tx_type_display()} — {self.material} ({self.qty})'

    @property
    def signed_qty(self):
        sign = {'issue': -1, 'transfer_out': -1, 'damage': -1}.get(self.tx_type, 1)
        return self.qty * sign


class MaterialIssue(models.Model):
    STATUSES = [('requested', 'مطلوب'), ('approved', 'معتمد'), ('issued', 'مصدر')]
    issue_no = models.CharField('رقم التصرف', max_length=30, unique=True)
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='material_issues',
                                verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL,
                              verbose_name='المرحلة')
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, verbose_name='من مخزن')
    date = models.DateField('التاريخ')
    requester = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الطالب')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='requested')
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'تصرف مواد'
        verbose_name_plural = 'التصرفات (صرف مواد)'

    def __str__(self):
        return f'{self.issue_no} — {self.project.code}'


class MaterialIssueItem(models.Model):
    issue = models.ForeignKey(MaterialIssue, on_delete=models.CASCADE, related_name='items', verbose_name='التصرف')
    material = models.ForeignKey(Material, on_delete=models.PROTECT, verbose_name='المادة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند تصرف'
        verbose_name_plural = 'بنود التصرف'

    def __str__(self):
        return f'{self.material} × {self.qty}'


class MaterialReturn(models.Model):
    issue = models.ForeignKey(MaterialIssue, on_delete=models.PROTECT, related_name='returns', verbose_name='التصرف')
    date = models.DateField('التاريخ')
    reason = models.CharField('السبب', max_length=250, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'إرجاع مواد'
        verbose_name_plural = 'إرجاعات المواد'

    def __str__(self):
        return f'إرجاع {self.issue_id}'


class MaterialReturnItem(models.Model):
    mreturn = models.ForeignKey(MaterialReturn, on_delete=models.CASCADE, related_name='items', verbose_name='الإرجاع')
    material = models.ForeignKey(Material, on_delete=models.PROTECT, verbose_name='المادة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند إرجاع'
        verbose_name_plural = 'بنود الإرجاع'

    def __str__(self):
        return f'{self.material} × {self.qty}'


class StockTransfer(models.Model):
    transfer_no = models.CharField('رقم التحويل', max_length=30, unique=True)
    from_warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name='transfers_out',
                                       verbose_name='من مخزن')
    to_warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, related_name='transfers_in',
                                     verbose_name='إلى مخزن')
    date = models.DateField('التاريخ')
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'تحويل مخزني'
        verbose_name_plural = 'التحويلات'

    def __str__(self):
        return self.transfer_no


class StockTransferItem(models.Model):
    transfer = models.ForeignKey(StockTransfer, on_delete=models.CASCADE, related_name='items', verbose_name='التحويل')
    material = models.ForeignKey(Material, on_delete=models.PROTECT, verbose_name='المادة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند تحويل'
        verbose_name_plural = 'بنود التحويل'

    def __str__(self):
        return f'{self.material} × {self.qty}'


class StockCount(models.Model):
    STATUSES = [('draft', 'مسودة'), ('confirmed', 'مؤكد')]
    count_no = models.CharField('رقم الجرد', max_length=30, unique=True)
    warehouse = models.ForeignKey(Warehouse, on_delete=models.PROTECT, verbose_name='المخزن')
    date = models.DateField('التاريخ')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'الجرد'
        verbose_name_plural = 'جداول الجرد'

    def __str__(self):
        return self.count_no


class StockCountLine(models.Model):
    count = models.ForeignKey(StockCount, on_delete=models.CASCADE, related_name='lines', verbose_name='الجرد')
    material = models.ForeignKey(Material, on_delete=models.PROTECT, verbose_name='المادة')
    book_qty = models.DecimalField('رصيد الدفاتر', max_digits=14, decimal_places=3, default=0)
    counted_qty = models.DecimalField('رصيد الفعلي', max_digits=14, decimal_places=3, default=0)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'سطر جرد'
        verbose_name_plural = 'أسطر الجرد'

    def __str__(self):
        return f'{self.material}'

    @property
    def diff(self):
        return self.counted_qty - self.book_qty
