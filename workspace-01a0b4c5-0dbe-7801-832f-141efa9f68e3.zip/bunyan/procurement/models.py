from django.db import models


class Supplier(models.Model):
    TYPES = [('material', 'مواد'), ('service', 'خدمات'), ('both', 'مواد وخدمات')]
    name = models.CharField('اسم المورد', max_length=200)
    code = models.CharField('الرمز', max_length=30, unique=True)
    contact_name = models.CharField('جهة الاتصال', max_length=150, blank=True)
    phone = models.CharField('الهاتف', max_length=30, blank=True)
    email = models.EmailField('البريد الإلكتروني', blank=True)
    address = models.CharField('العنوان', max_length=250, blank=True)
    supplier_type = models.CharField('النوع', max_length=20, choices=TYPES, default='both')
    rating = models.PositiveIntegerField('التقييم (0-5)', default=3)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'المورد'
        verbose_name_plural = 'الموردون'

    def __str__(self):
        return self.name

    @property
    def payable(self):
        from finance.services import supplier_payable
        return supplier_payable(self)


class PurchaseRequest(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('submitted', 'بانتظار الاعتماد'),
        ('approved', 'معتمد'),
        ('rejected', 'مرفوض'),
        ('partial', 'مستلم جزئيًا'),
        ('received', 'مستلم'),
    ]
    pr_no = models.CharField('رقم الطلب', max_length=30, unique=True)
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='purchase_requests',
                                verbose_name='المشروع')
    warehouse = models.ForeignKey('inventory.Warehouse', on_delete=models.PROTECT, verbose_name='المخزن المستلم')
    requester = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الطالب')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    notes = models.TextField('ملاحظات', blank=True)
    created = models.DateTimeField('التاريخ', auto_now_add=True)

    class Meta:
        verbose_name = 'طلب شراء'
        verbose_name_plural = 'طلبات الشراء'

    def __str__(self):
        return self.pr_no


class PurchaseRequestItem(models.Model):
    request = models.ForeignKey(PurchaseRequest, on_delete=models.CASCADE, related_name='items', verbose_name='الطلب')
    material = models.ForeignKey('inventory.Material', on_delete=models.PROTECT, verbose_name='المادة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    est_cost = models.DecimalField('التكلفة التقديرية (للوحة)', max_digits=14, decimal_places=3, default=0)
    received_qty = models.DecimalField('المستلم', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند طلب شراء'
        verbose_name_plural = 'بنود طلبات الشراء'

    def __str__(self):
        return f'{self.material} × {self.qty}'


class PurchaseOrder(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('sent', 'مرسل'),
        ('partial', 'مستلم جزئيًا'),
        ('received', 'مستلم'),
        ('closed', 'مغلق'),
        ('cancelled', 'ملغي'),
    ]
    po_no = models.CharField('رقم أمر الشراء', max_length=30, unique=True)
    request = models.ForeignKey(PurchaseRequest, null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='purchase_orders', verbose_name='طلب الشراء')
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name='purchase_orders', verbose_name='المورد')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='purchase_orders', verbose_name='المشروع')
    order_date = models.DateField('تاريخ الطلب')
    expected_date = models.DateField('الاستلام المتوقع', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    total = models.DecimalField('الإجمالي', max_digits=16, decimal_places=2, default=0)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'أمر شراء'
        verbose_name_plural = 'أوامر الشراء'

    def __str__(self):
        return self.po_no


class PurchaseOrderItem(models.Model):
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='items', verbose_name='أمر الشراء')
    material = models.ForeignKey('inventory.Material', on_delete=models.PROTECT, verbose_name='المادة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_price = models.DecimalField('سعر الوحدة', max_digits=14, decimal_places=3, default=0)
    received_qty = models.DecimalField('المستلم', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند أمر شراء'
        verbose_name_plural = 'بنود أوامر الشراء'

    def __str__(self):
        return f'{self.material} × {self.qty}'

    @property
    def line_total(self):
        return self.qty * self.unit_price


class GoodsReceipt(models.Model):
    STATUSES = [('pending', 'بانتظار الفحص'), ('inspected', 'فاحص ومعتمد'), ('rejected', 'مرفوض')]
    receipt_no = models.CharField('رقم الاستلام', max_length=30, unique=True)
    po = models.ForeignKey(PurchaseOrder, on_delete=models.PROTECT, related_name='receipts', verbose_name='أمر الشراء')
    warehouse = models.ForeignKey('inventory.Warehouse', on_delete=models.PROTECT, verbose_name='المخزن')
    date = models.DateField('تاريخ الاستلام')
    inspector = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الفاحص')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='pending')
    notes = models.TextField('ملاحظات الفحص', blank=True)

    class Meta:
        verbose_name = 'استلام مواد'
        verbose_name_plural = 'استلامات المواد'

    def __str__(self):
        return self.receipt_no


class GoodsReceiptItem(models.Model):
    receipt = models.ForeignKey(GoodsReceipt, on_delete=models.CASCADE, related_name='items', verbose_name='الاستلام')
    po_item = models.ForeignKey(PurchaseOrderItem, on_delete=models.PROTECT, verbose_name='بند أمر الشراء')
    qty_received = models.DecimalField('الكمية المستلمة', max_digits=14, decimal_places=3, default=0)
    qty_accepted = models.DecimalField('المقبول', max_digits=14, decimal_places=3, default=0)
    qty_rejected = models.DecimalField('المرفوض', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند استلام'
        verbose_name_plural = 'بنود الاستلام'

    def __str__(self):
        return f'{self.po_item.material} × {self.qty_received}'


class PurchaseInvoice(models.Model):
    STATUSES = [('open', 'مفتوحة'), ('partial', 'مدفوعة جزئيًا'), ('paid', 'مدفوعة')]
    invoice_no = models.CharField('رقم الفاتورة', max_length=30, unique=True)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name='invoices', verbose_name='المورد')
    po = models.ForeignKey(PurchaseOrder, null=True, blank=True, on_delete=models.SET_NULL,
                           related_name='invoices', verbose_name='أمر الشراء')
    project = models.ForeignKey('projects.Project', null=True, blank=True, on_delete=models.SET_NULL,
                                verbose_name='المشروع')
    invoice_date = models.DateField('تاريخ الفاتورة')
    due_date = models.DateField('تاريخ الاستحقاق', null=True, blank=True)
    subtotal = models.DecimalField('الصافي', max_digits=16, decimal_places=2, default=0)
    tax = models.DecimalField('الضريبة', max_digits=16, decimal_places=2, default=0)
    total = models.DecimalField('الإجمالي', max_digits=16, decimal_places=2, default=0)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    paid_amount = models.DecimalField('المسدّد', max_digits=16, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'فاتورة مورد'
        verbose_name_plural = 'فواتير الموردين'

    def __str__(self):
        return self.invoice_no
