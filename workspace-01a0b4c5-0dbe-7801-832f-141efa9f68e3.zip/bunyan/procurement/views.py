from django import forms
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.crud import crud as _crud
from core.decorators import roles
from core.utils import field_list, row_for
from .models import (GoodsReceipt, GoodsReceiptItem, PurchaseInvoice,
                     PurchaseOrder, PurchaseOrderItem, PurchaseRequest,
                     PurchaseRequestItem, Supplier)
from .services import create_po_from_request, perform_receipt


def _no(prefix, qs):
    return f'{prefix}-{timezone.localdate().year}-{qs.count() + 1:03d}'


supplier_list, supplier_create, supplier_update = _crud(
    Supplier, 'الموردون', ['name', 'code', 'contact_name', 'phone', 'supplier_type', 'rating'])


class PurchaseRequestForm(forms.ModelForm):
    class Meta:
        model = PurchaseRequest
        fields = ['pr_no', 'project', 'warehouse', 'status', 'notes']


def pr_list(request):
    columns = field_list(PurchaseRequest, ['pr_no', 'project', 'warehouse', 'requester', 'status', 'created'])
    qs = PurchaseRequest.objects.select_related('project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'طلبات الشراء', 'columns': columns,
        'create_url': 'procurement:pr_create', 'create_label': 'إضافة طلب',
        'rows': [row_for(r, columns, f'/procurement/requests/{r.pk}/') for r in qs]})


def pr_form(request, pk=None):
    r = get_object_or_404(PurchaseRequest, pk=pk) if pk else None
    if request.method == 'POST':
        form = PurchaseRequestForm(request.POST, instance=r)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.pr_no = obj.pr_no or _no('PR', PurchaseRequest.objects.all())
            obj.save()
            return redirect(f'/procurement/requests/{obj.pk}/')
    else:
        form = PurchaseRequestForm(instance=r, initial={} if r else {'pr_no': _no('PR', PurchaseRequest.objects.all())})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل طلب شراء' if r else 'إضافة طلب شراء', 'form': form})


class PRItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseRequestItem
        fields = '__all__'


def pr_item_form(request, pk=None):
    it = get_object_or_404(PurchaseRequestItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = PRItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/procurement/requests/{obj.request_id}/')
    else:
        form = PRItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند لطلب الشراء', 'form': form})


def pr_detail(request, pk):
    r = get_object_or_404(PurchaseRequest, pk=pk)
    return render(request, 'procurement/pr_detail.html', {
        'page_title': f'طلب الشراء {r.pr_no}',
        'object': r,
        'detail_columns': field_list(PurchaseRequest, ['pr_no', 'project', 'warehouse', 'requester', 'status', 'notes']),
        'pr_items': r.items.all(),
        'pos': r.purchase_orders.all(),
    })


@roles('admin', 'pm', 'procurement')
def pr_status(request, pk):
    r = get_object_or_404(PurchaseRequest, pk=pk)
    status = request.POST.get('status')
    allowed = {'draft': ['submitted', 'rejected'], 'submitted': ['approved', 'rejected']}
    if status in allowed.get(r.status, []):
        r.status = status
        r.save()
    return redirect(f'/procurement/requests/{r.pk}/')


class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = ['po_no', 'request', 'supplier', 'project', 'order_date', 'expected_date', 'status', 'notes']


def po_list(request):
    columns = field_list(PurchaseOrder, ['po_no', 'supplier', 'project', 'order_date', 'expected_date', 'total', 'status'])
    qs = PurchaseOrder.objects.select_related('supplier', 'project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'أوامر الشراء', 'columns': columns,
        'create_url': 'procurement:po_create', 'create_label': 'إضافة أمر شراء',
        'rows': [row_for(p, columns, f'/procurement/orders/{p.pk}/') for p in qs]})


def po_form(request, pk=None):
    p = get_object_or_404(PurchaseOrder, pk=pk) if pk else None
    if request.method == 'POST':
        form = PurchaseOrderForm(request.POST, instance=p)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.po_no = obj.po_no or _no('PO', PurchaseOrder.objects.all())
            obj.save()
            return redirect(f'/procurement/orders/{obj.pk}/')
    else:
        form = PurchaseOrderForm(instance=p, initial={} if p else {'po_no': _no('PO', PurchaseOrder.objects.all())})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل أمر شراء' if p else 'إضافة أمر شراء', 'form': form})


def po_create_from_request(request, pk):
    """إنشاء أمر شراء من طلب شراء معتمد."""
    r = get_object_or_404(PurchaseRequest, pk=pk)
    if r.status != 'approved':
        return render(request, 'core/generic_list.html',
                      {'page_title': 'خطأ', 'columns': [], 'rows': [],
                       'error_msg': 'لا يمكن إنشاء أمر شراء إلا من طلب معتمد'})
    if request.method == 'POST':
        sup = Supplier.objects.get(pk=request.POST['supplier'])
        po = create_po_from_request(
            r, sup, request.POST.get('po_no') or _no('PO', PurchaseOrder.objects.all()),
            timezone.localdate(),
            expected_date=r.project.end_date if r.project else None)
        return redirect(f'/procurement/orders/{po.pk}/')
    return render(request, 'procurement/po_from_request.html', {
        'page_title': 'إنشاء أمر شراء من طلب', 'request': r,
        'suppliers': Supplier.objects.all(),
        'po_no': _no('PO', PurchaseOrder.objects.all())})


class POItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrderItem
        fields = '__all__'


def po_item_form(request, pk=None):
    it = get_object_or_404(PurchaseOrderItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = POItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            total = sum((i.line_total for i in obj.po.items.all()), 0)
            obj.po.total = total
            obj.po.save()
            return redirect(f'/procurement/orders/{obj.po_id}/')
    else:
        form = POItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند لأمر الشراء', 'form': form})


def po_detail(request, pk):
    p = get_object_or_404(PurchaseOrder, pk=pk)
    return render(request, 'procurement/po_detail.html', {
        'page_title': f'أمر الشراء {p.po_no}',
        'po': p,
        'items': p.items.select_related('material'),
        'receipts': p.receipts.all(),
        'invoices': p.invoices.all(),
        'total': p.total,
    })


@roles('admin', 'procurement')
def po_send(request, pk):
    p = get_object_or_404(PurchaseOrder, pk=pk)
    if p.status == 'draft':
        p.status = 'sent'
        p.save()
    return redirect(f'/procurement/orders/{p.pk}/')


class ReceiptForm(forms.ModelForm):
    class Meta:
        model = GoodsReceipt
        fields = ['receipt_no', 'po', 'warehouse', 'date', 'inspector', 'status', 'notes']


def receipt_list(request):
    columns = field_list(GoodsReceipt, ['receipt_no', 'po', 'warehouse', 'date', 'status'])
    qs = GoodsReceipt.objects.select_related('po').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'استلامات المواد', 'columns': columns,
        'create_url': 'procurement:receipt_create', 'create_label': 'إضافة استلام',
        'rows': [row_for(r, columns, f'/procurement/receipts/{r.pk}/') for r in qs]})


def receipt_form(request, pk=None):
    r = get_object_or_404(GoodsReceipt, pk=pk) if pk else None
    if request.method == 'POST':
        form = ReceiptForm(request.POST, instance=r)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.receipt_no = obj.receipt_no or _no('GR', GoodsReceipt.objects.all())
            obj.save()
            return redirect(f'/procurement/receipts/{obj.pk}/')
    else:
        form = ReceiptForm(instance=r, initial={} if r else {'receipt_no': _no('GR', GoodsReceipt.objects.all())})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل استلام' if r else 'إضافة استلام', 'form': form})


class ReceiptItemForm(forms.ModelForm):
    class Meta:
        model = GoodsReceiptItem
        fields = '__all__'


def receipt_item_form(request, pk=None):
    it = get_object_or_404(GoodsReceiptItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = ReceiptItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/procurement/receipts/{obj.receipt_id}/')
    else:
        form = ReceiptItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند استلام' if it else 'إضافة بند استلام', 'form': form})


def receipt_detail(request, pk):
    r = get_object_or_404(GoodsReceipt, pk=pk)
    return render(request, 'procurement/receipt_detail.html', {
        'page_title': f'الاستلام {r.receipt_no}',
        'receipt': r,
        'items': r.items.select_related('po_item__material'),
    })


@roles('admin', 'procurement', 'warehouse')
def receipt_inspect(request, pk):
    """اعتماد الفحص: إدخال المخزون + تحميل التكلفة + تحديث الكميات."""
    r = get_object_or_404(GoodsReceipt, pk=pk)
    if request.method == 'POST':
        if request.POST.get('status') == 'rejected':
            r.status = 'rejected'
            r.save()
        else:
            try:
                perform_receipt(r)
            except ValueError:
                pass
    return redirect(f'/procurement/receipts/{r.pk}/')


class PurchaseInvoiceForm(forms.ModelForm):
    class Meta:
        model = PurchaseInvoice
        fields = ['invoice_no', 'supplier', 'po', 'project', 'invoice_date', 'due_date',
                  'subtotal', 'tax', 'total', 'status']


def pi_list(request):
    columns = field_list(PurchaseInvoice, ['invoice_no', 'supplier', 'invoice_date', 'due_date', 'total', 'paid_amount', 'status'])
    qs = PurchaseInvoice.objects.select_related('supplier').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'فواتير الموردين', 'columns': columns,
        'create_url': 'procurement:pi_create', 'create_label': 'إضافة فاتورة',
        'rows': [row_for(i, columns) for i in qs]})


def pi_form(request, pk=None):
    i = get_object_or_404(PurchaseInvoice, pk=pk) if pk else None
    if request.method == 'POST':
        form = PurchaseInvoiceForm(request.POST, instance=i)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.invoice_no = obj.invoice_no or _no('PI', PurchaseInvoice.objects.all())
            obj.save()
            return redirect('procurement:pi_list')
    else:
        form = PurchaseInvoiceForm(instance=i, initial={} if i else {'invoice_no': _no('PI', PurchaseInvoice.objects.all())})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل فاتورة مورد' if i else 'إضافة فاتورة مورد', 'form': form})
