"""خدمات المشتريات: أوامر الشراء، الاستلام والفحص، وربط التكلفة."""
from decimal import Decimal


def create_po_from_request(request, supplier, po_no, order_date, expected_date=None):
    """إنشاء أمر شراء من طلب شراء معتمد."""
    from .models import PurchaseOrder, PurchaseOrderItem

    po = PurchaseOrder.objects.create(
        po_no=po_no,
        request=request,
        supplier=supplier,
        project=request.project,
        order_date=order_date,
        expected_date=expected_date,
        status='draft',
    )
    total = Decimal('0')
    for it in request.items.all():
        po_item = PurchaseOrderItem.objects.create(
            po=po,
            material=it.material,
            qty=it.qty,
            unit_price=it.est_cost or it.material.last_cost or Decimal('0'),
        )
        total += po_item.line_total
    po.total = total
    po.save()
    return po


def perform_receipt(receipt):
    """اعتماد استلام بعد الفحص:
    - إدخال المخزون (حركة purchase)
    - تحديث كميات المستلمة في أمر الشراء وطلب الشراء
    - تحميل التكلفة على المشروع (Expense) إذا كان أمر الشراء مرتبطًا بمشروع
    - تحديث آخر تكلفة للمادة
    """
    from inventory.models import StockTransaction
    from finance.models import Expense
    from core.context import get_user as get_request_user

    if receipt.status == 'rejected':
        raise ValueError('الاستلام مرفوض')

    user = get_request_user()
    po = receipt.po
    for it in receipt.items.all():
        if it.qty_accepted <= 0:
            continue
        material = it.po_item.material
        unit_price = it.po_item.unit_price
        material.last_cost = unit_price
        material.save(update_fields=['last_cost'])

        StockTransaction.objects.create(
            warehouse=receipt.warehouse,
            material=material,
            tx_type='purchase',
            qty=it.qty_accepted,
            unit_cost=unit_price,
            project=po.project,
            ref=receipt.receipt_no,
            user=user,
            note=f'استلام {po.po_no}',
        )

        if po.project_id:
            Expense.objects.create(
                project=po.project,
                category='material',
                amount=it.qty_accepted * unit_price,
                date=receipt.date,
                description=f'شراء مواد — {it.po_item.material.name} × {it.qty_accepted} ({po.po_no})',
                supplier=po.supplier,
                po=po,
                user=user,
            )

        it.po_item.received_qty = (it.po_item.received_qty or 0) + it.qty_accepted
        it.po_item.save(update_fields=['received_qty'])

    # تحديث حالة أمر الشراء
    items = list(po.items.all())
    if all((i.received_qty or 0) >= i.qty for i in items):
        po.status = 'received'
    elif any((i.received_qty or 0) > 0 for i in items):
        po.status = 'partial'
    po.save()

    if po.request_id:
        req = po.request
        req_items = list(req.items.all())
        if all((i.received_qty or 0) >= i.qty for i in req_items):
            req.status = 'received'
        elif any((i.received_qty or 0) > 0 for i in req_items):
            req.status = 'partial'
        req.save()

    receipt.status = 'inspected'
    receipt.save()
    return receipt
