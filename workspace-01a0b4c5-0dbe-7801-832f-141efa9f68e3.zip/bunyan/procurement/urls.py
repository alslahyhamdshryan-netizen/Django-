from django.urls import path

from . import views

app_name = 'procurement'

urlpatterns = [
    path('suppliers/', views.supplier_list, name='supplier_list'),
    path('suppliers/add/', views.supplier_create, name='supplier_create'),
    path('suppliers/<int:pk>/edit/', views.supplier_update, name='supplier_update'),
    path('requests/', views.pr_list, name='pr_list'),
    path('requests/add/', views.pr_form, name='pr_create'),
    path('requests/<int:pk>/', views.pr_detail, name='pr_detail'),
    path('requests/<int:pk>/edit/', views.pr_form, name='pr_update'),
    path('requests/<int:pk>/status/', views.pr_status, name='pr_status'),
    path('requests/<int:pk>/to-po/', views.po_create_from_request, name='po_from_request'),
    path('pr-items/add/', views.pr_item_form, name='pr_item_create'),
    path('pr-items/<int:pk>/edit/', views.pr_item_form, name='pr_item_update'),
    path('orders/', views.po_list, name='po_list'),
    path('orders/add/', views.po_form, name='po_create'),
    path('orders/<int:pk>/', views.po_detail, name='po_detail'),
    path('orders/<int:pk>/edit/', views.po_form, name='po_update'),
    path('orders/<int:pk>/send/', views.po_send, name='po_send'),
    path('po-items/add/', views.po_item_form, name='po_item_create'),
    path('po-items/<int:pk>/edit/', views.po_item_form, name='po_item_update'),
    path('receipts/', views.receipt_list, name='receipt_list'),
    path('receipts/add/', views.receipt_form, name='receipt_create'),
    path('receipts/<int:pk>/', views.receipt_detail, name='receipt_detail'),
    path('receipts/<int:pk>/edit/', views.receipt_form, name='receipt_update'),
    path('receipts/<int:pk>/inspect/', views.receipt_inspect, name='receipt_inspect'),
    path('receipt-items/add/', views.receipt_item_form, name='receipt_item_create'),
    path('receipt-items/<int:pk>/edit/', views.receipt_item_form, name='receipt_item_update'),
    path('invoices/', views.pi_list, name='pi_list'),
    path('invoices/add/', views.pi_form, name='pi_create'),
    path('invoices/<int:pk>/edit/', views.pi_form, name='pi_update'),
]
