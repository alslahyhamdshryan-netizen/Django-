from django.db import models


class Project(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('planning', 'قيد الدراسة'),
        ('in_progress', 'قيد التنفيذ'),
        ('on_hold', 'متوقف'),
        ('completed', 'مكتمل'),
        ('closed', 'مغلق'),
    ]
    code = models.CharField('رمز المشروع', max_length=30, unique=True)
    name = models.CharField('اسم المشروع', max_length=250)
    client = models.ForeignKey('crm.Client', on_delete=models.PROTECT, related_name='projects', verbose_name='العميل')
    branch = models.ForeignKey('core.Branch', null=True, blank=True, on_delete=models.SET_NULL,
                               related_name='projects', verbose_name='الفرع')
    location = models.CharField('الموقع', max_length=250, blank=True)
    area = models.DecimalField('المساحة (م2)', max_digits=12, decimal_places=2, null=True, blank=True)
    manager = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                related_name='managed_projects', verbose_name='مدير المشروع')
    engineer = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                 related_name='engineer_projects', verbose_name='المهندس')
    supervisor = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name='supervised_projects', verbose_name='المشرف')
    start_date = models.DateField('تاريخ البداية', null=True, blank=True)
    end_date = models.DateField('تاريخ النهاية', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    description = models.TextField('الوصف', blank=True)

    class Meta:
        verbose_name = 'المشروع'
        verbose_name_plural = 'المشاريع'

    def __str__(self):
        return f'{self.code} — {self.name}'

    @property
    def progress(self):
        from .services import project_progress
        return project_progress(self)

    @property
    def contract(self):
        from contracts.models import Contract
        return Contract.objects.filter(project=self).order_by('-pk').first()

    @property
    def budget(self):
        c = self.contract
        return c.value if c else 0


class Stage(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='stages', verbose_name='المشروع')
    name = models.CharField('اسم المرحلة', max_length=150)
    order = models.PositiveIntegerField('الترتيب', default=0)
    start_date = models.DateField('بداية مخططة', null=True, blank=True)
    end_date = models.DateField('نهاية مخططة', null=True, blank=True)
    weight = models.FloatField('الوزن (% من المشروع)', default=0)
    planned_pct = models.FloatField('المخطط %', default=0)
    actual_pct = models.FloatField('المنفذ %', default=0)
    manager = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                verbose_name='مسؤول المرحلة')

    class Meta:
        verbose_name = 'المرحلة'
        verbose_name_plural = 'المراحل'
        ordering = ['project', 'order', 'id']

    def __str__(self):
        return self.name


class Task(models.Model):
    STATUSES = [('todo', 'لم تبدأ'), ('in_progress', 'قيد التنفيذ'), ('done', 'منتهية')]
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='tasks', verbose_name='المشروع')
    stage = models.ForeignKey(Stage, null=True, blank=True, on_delete=models.CASCADE,
                              related_name='tasks', verbose_name='المرحلة')
    name = models.CharField('اسم المهمة', max_length=200)
    assignee = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                 verbose_name='المسؤول')
    start_date = models.DateField('البداية', null=True, blank=True)
    end_date = models.DateField('النهاية', null=True, blank=True)
    pct = models.FloatField('نسبة الإنجاز %', default=0)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='todo')
    predecessor = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name='successors', verbose_name='المهمة السابقة')

    class Meta:
        verbose_name = 'المهمة'
        verbose_name_plural = 'المهام'
        ordering = ['project', 'start_date', 'id']

    def __str__(self):
        return self.name


class BOQItem(models.Model):
    """بند جدول الكميات (دراسة المشروع): التكلفة المباشرة + المصاريف + هامش الربح = سعر البيع"""
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='boq_items', verbose_name='المشروع')
    line_no = models.PositiveIntegerField('رقم البند', default=1)
    name = models.CharField('وصف العمل', max_length=250)
    unit = models.CharField('الوحدة', max_length=30, default='قطعة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    material_cost = models.DecimalField('سعر المادة (للوحة)', max_digits=14, decimal_places=3, default=0)
    labor_cost = models.DecimalField('تكلفة العمالة (للوحة)', max_digits=14, decimal_places=3, default=0)
    equipment_cost = models.DecimalField('تكلفة المعدات (للوحة)', max_digits=14, decimal_places=3, default=0)
    overhead_pct = models.DecimalField('المصاريف الإضافية %', max_digits=6, decimal_places=2, default=5)
    profit_pct = models.DecimalField('هامش الربح %', max_digits=6, decimal_places=2, default=15)

    class Meta:
        verbose_name = 'بند BOQ'
        verbose_name_plural = 'بنود BOQ'
        ordering = ['project', 'line_no', 'id']

    def __str__(self):
        return f'{self.line_no}. {self.name}'

    @property
    def direct_cost(self):
        return self.material_cost + self.labor_cost + self.equipment_cost

    @property
    def unit_cost(self):
        return self.direct_cost * (1 + self.overhead_pct / 100)

    @property
    def unit_price(self):
        return self.unit_cost * (1 + self.profit_pct / 100)

    @property
    def total_cost(self):
        return self.unit_cost * self.qty

    @property
    def total_price(self):
        return self.unit_price * self.qty


class DailyReport(models.Model):
    """التقرير اليومي للموقع"""
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='daily_reports', verbose_name='المشروع')
    date = models.DateField('التاريخ')
    summary = models.CharField('حالة العمل', max_length=250, blank=True)
    workers_count = models.PositiveIntegerField('عدد العمال', default=0)
    works_done = models.TextField('الأعمال المنفذة', blank=True)
    materials_text = models.TextField('المواد المستخدمة', blank=True)
    equipment_text = models.TextField('المعدات', blank=True)
    problems_text = models.TextField('المشاكل', blank=True)
    stops_text = models.TextField('التوقفات', blank=True)
    notes = models.TextField('ملاحظات', blank=True)
    stage = models.ForeignKey(Stage, null=True, blank=True, on_delete=models.SET_NULL,
                              verbose_name='مرحلة (لتحديث الإنجاز)')
    stage_pct = models.FloatField('إنجاز المرحلة %', null=True, blank=True)

    class Meta:
        verbose_name = 'التقرير اليومي'
        verbose_name_plural = 'التقارير اليومية'
        ordering = ['-date', '-id']

    def __str__(self):
        return f'تقرير {self.project_id} — {self.date}'

    def save(self, *args, **kwargs):
        created = not self.pk
        super().save(*args, **kwargs)
        if created and self.stage_id and self.stage_pct is not None:
            self.stage.actual_pct = self.stage_pct
            self.stage.save(update_fields=['actual_pct'])


class Meeting(models.Model):
    """محضر اجتماع مشروع"""
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='meetings', verbose_name='المشروع')
    title = models.CharField('العنوان', max_length=250)
    meeting_date = models.DateField('التاريخ')
    location = models.CharField('المكان', max_length=150, blank=True)
    attendees = models.TextField('الحاضرون', blank=True)
    decisions = models.TextField('القرارات', blank=True)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'الاجتماع'
        verbose_name_plural = 'الاجتماعات'
        ordering = ['-meeting_date']

    def __str__(self):
        return f'{self.title} — {self.meeting_date}'


class MeetingTask(models.Model):
    """مهمة ناتجة عن اجتماع (يمكن تحويلها لمهمة في الجدول الزمني)"""
    STATUSES = [('open', 'مفتوحة'), ('in_progress', 'قيد المعالجة'), ('done', 'منجزة')]
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='tasks', verbose_name='الاجتماع')
    title = models.CharField('المهمة', max_length=250)
    assignee = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المسؤول')
    due_date = models.DateField('الموعد النهائي', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    task = models.ForeignKey(Task, null=True, blank=True, on_delete=models.SET_NULL,
                             verbose_name='المهمة المرتبطة')

    class Meta:
        verbose_name = 'مهمة اجتماع'
        verbose_name_plural = 'مهام الاجتماعات'

    def __str__(self):
        return self.title
