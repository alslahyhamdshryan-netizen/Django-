"""خدمات المشاريع: BOQ، الإنجاز المرجح، التكاليف."""
from decimal import Decimal

from django.db.models import Sum


def boq_totals(project):
    """(إجمالي التكلفة، إجمالي سعر البيع، الربح المتوقع) لمشروع من بنود BOQ."""
    items = project.boq_items.all()
    cost = sum((i.total_cost for i in items), Decimal('0'))
    price = sum((i.total_price for i in items), Decimal('0'))
    return cost, price, price - cost


def _weighted(project, attr):
    stages = list(project.stages.all())
    if not stages:
        return Decimal('0')
    total_weight = sum((Decimal(str(s.weight or 0)) for s in stages), Decimal('0'))
    if total_weight > 0:
        return sum((Decimal(str(s.weight or 0)) * Decimal(str(getattr(s, attr) or 0)) for s in stages),
                   Decimal('0')) / total_weight
    return sum((Decimal(str(getattr(s, attr) or 0)) for s in stages), Decimal('0')) / len(stages)


def project_progress(project):
    """نسبة الإنجاز الإجمالية = متوسط مرجح حسب أوزان المراحل (وليس مجرد متوسط النسب)."""
    return float(_weighted(project, 'actual_pct'))


def project_planned(project):
    return float(_weighted(project, 'planned_pct'))


def stage_cost(stage):
    from finance.models import Expense
    return Expense.objects.filter(stage=stage).aggregate(s=Sum('amount'))['s'] or Decimal('0')


def project_cost(project):
    from finance.models import Expense
    return Expense.objects.filter(project=project).aggregate(s=Sum('amount'))['s'] or Decimal('0')
