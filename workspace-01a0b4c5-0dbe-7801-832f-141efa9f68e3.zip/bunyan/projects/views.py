from django import forms
from django.shortcuts import get_object_or_404, redirect, render

from core.crud import crud as _crud
from .models import BOQItem, DailyReport, Meeting, MeetingTask, Project, Stage, Task
from .services import boq_totals, project_planned, project_progress

project_list, project_create, project_update = _crud(
    Project, 'المشاريع', ['code', 'name', 'client', 'manager', 'start_date', 'end_date', 'status'],
    detail='projects:project_detail', create='projects:project_create')

stage_list, stage_create, stage_update = _crud(
    Stage, 'المراحل', ['project', 'name', 'order', 'start_date', 'end_date', 'weight', 'planned_pct', 'actual_pct'],
    order_by=['order'])

task_list, task_create, task_update = _crud(
    Task, 'المهام', ['project', 'stage', 'name', 'assignee', 'start_date', 'end_date', 'pct', 'status'],
    order_by=['start_date'])

boq_list, boq_create, boq_update = _crud(
    BOQItem, 'بنود BOQ', ['project', 'line_no', 'name', 'unit', 'qty', 'material_cost',
                           'labor_cost', 'equipment_cost', 'overhead_pct', 'profit_pct'],
    order_by=['project', 'line_no'])

daily_list, daily_create, daily_update = _crud(
    DailyReport, 'التقارير اليومية', ['project', 'date', 'summary', 'workers_count', 'stage', 'stage_pct'],
    order_by=['-date'])

meeting_list, meeting_create, meeting_update = _crud(
    Meeting, 'الاجتماعات', ['project', 'title', 'meeting_date', 'location', 'attendees'],
    detail='projects:meeting_detail', create='projects:meeting_create')


def project_detail(request, pk):
    p = get_object_or_404(Project, pk=pk)
    from finance.services import project_financials
    f = project_financials(p)
    cost, price, exp = boq_totals(p)
    return render(request, 'projects/project_detail.html', {
        'page_title': p.name,
        'project': p,
        'financials': f,
        'boq_cost': cost,
        'boq_price': price,
        'boq_profit': exp,
        'stages': p.stages.order_by('order')[:30],
        'contracts': p.contracts.all(),
        'docs_count': p.documents.count(),
        'issues': p.issues.all()[:5],
        'punch': p.punch_items.all()[:5],
    })


def boq_view(request, pk):
    p = get_object_or_404(Project, pk=pk)
    cost, price, exp = boq_totals(p)
    items = p.boq_items.all()
    return render(request, 'projects/boq.html', {
        'page_title': f'دراسة المشروع (BOQ) — {p.name}',
        'project': p,
        'items': items,
        'totals': {'cost': cost, 'price': price, 'profit': exp},
    })


def progress_view(request, pk):
    p = get_object_or_404(Project, pk=pk)
    stages = p.stages.order_by('order')
    return render(request, 'projects/progress.html', {
        'page_title': f'قياس الإنجاز — {p.name}',
        'project': p,
        'stages': stages,
        'planned': project_planned(p),
        'actual': project_progress(p),
    })


def gantt_view(request, pk):
    p = get_object_or_404(Project, pk=pk)
    tasks = list(Task.objects.filter(project=p).exclude(start_date__isnull=True))
    if not tasks:
        return render(request, 'projects/gantt.html', {'page_title': 'Gantt', 'project': p, 'rows': [], 'note': 'لا توجد مهام بتواريخ مخططة'})
    start = min(t.start_date for t in tasks)
    end = max(t.end_date or t.start_date for t in tasks)
    total = max((end - start).days, 1)
    rows = []
    for t in tasks:
        s = max(0, (t.start_date - start).days) / total * 100
        w = max(2, ((t.end_date or t.start_date) - t.start_date).days + 1) / total * 100
        rows.append({'task': t, 'start': s, 'width': w,
                     'color': {'todo': '#9ca3af', 'in_progress': '#2563eb', 'done': '#16a34a'}.get(t.status, '#9ca3af')})
    months = []
    from datetime import date
    from django.utils import timezone
    d = date(start.year, start.month, 1)
    while d <= end:
        months.append({'pos': (d - start).days / total * 100, 'label': d.strftime('%m/%Y')})
        d = date(d.year + (d.month == 12), (d.month % 12) + 1, 1)
    # خط اليوم
    today = timezone.localdate()
    today_pos = None
    if start <= today <= end:
        today_pos = (today - start).days / total * 100
    return render(request, 'projects/gantt.html', {
        'page_title': f'الجدول الزمني (Gantt) — {p.name}',
        'project': p, 'rows': rows, 'months': months, 'note': None,
        'today_pos': today_pos,
        'total_days': total,
        'g_start': start.isoformat(),
        'g_end': end.isoformat(),
    })


def task_move(request, pk):
    """تحريك مهمة في Gantt (سحب وإفلات): يعيد JSON."""
    import json
    from django.http import JsonResponse
    from django.utils.dateparse import parse_date
    t = get_object_or_404(Task, pk=pk)
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'error': 'method'}, status=405)
    try:
        data = json.loads(request.body or b'{}')
    except Exception:
        data = request.POST
    s = parse_date(data.get('start_date') or '')
    e = parse_date(data.get('end_date') or '')
    if s:
        t.start_date = s
    if e and (not t.start_date or e >= t.start_date):
        t.end_date = e
    t.save()
    return JsonResponse({'ok': True, 'start_date': str(t.start_date), 'end_date': str(t.end_date)})


def print_financials(request, pk):
    """نسخة طباعة (PDF عبر المتصفح) للمراقبة المالية للمشروع."""
    p = get_object_or_404(Project, pk=pk)
    from finance.services import project_financials
    from finance.models import Expense
    from django.db.models import Sum
    from django.utils import timezone
    f = project_financials(p)
    cost, price, exp = boq_totals(p)
    by_cat = {}
    for cat, _l in Expense.CATEGORIES:
        by_cat[cat] = Expense.objects.filter(project=p, category=cat).aggregate(s=Sum('amount'))['s'] or 0
    return render(request, 'projects/print_financials.html', {
        'project': p,
        'financials': f,
        'boq': {'cost': cost, 'price': price, 'profit': exp},
        'stages': p.stages.order_by('order'),
        'by_cat': by_cat,
        'payments_in': p.payments.filter(pay_type='incoming').order_by('-date')[:10],
        'payments_out': p.payments.filter(pay_type='outgoing').order_by('-date')[:10],
        'print_date': timezone.localdate(),
    })


# ---------- الاجتماعات ----------
class MeetingForm(forms.ModelForm):
    class Meta:
        model = Meeting
        fields = ['project', 'title', 'meeting_date', 'location', 'attendees', 'decisions', 'notes']


class MeetingTaskForm(forms.ModelForm):
    class Meta:
        model = MeetingTask
        fields = ['meeting', 'title', 'assignee', 'due_date', 'status']


def meeting_detail(request, pk):
    from django.utils import timezone
    m = get_object_or_404(Meeting, pk=pk)
    return render(request, 'projects/meeting_detail.html', {
        'page_title': m.title,
        'meeting': m,
        'tasks': m.tasks.all(),
        'today': timezone.localdate(),
    })


def meeting_task_form(request, pk=None):
    t = get_object_or_404(MeetingTask, pk=pk) if pk else None
    if request.method == 'POST':
        form = MeetingTaskForm(request.POST, instance=t)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/projects/meetings/{obj.meeting_id}/')
    else:
        form = MeetingTaskForm(instance=t)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل مهمة اجتماع' if t else 'إضافة مهمة لمحضر اجتماع', 'form': form})


def meeting_task_convert(request, pk):
    """تحويل مهمة الاجتماع إلى مهمة في جدول زمني المشروع."""
    t = get_object_or_404(MeetingTask, pk=pk)
    if request.method == 'POST' and t.task is None:
        t.task = Task.objects.create(
            project=t.meeting.project,
            name=f'[{t.meeting.title}] {t.title}',
            assignee=t.assignee,
            start_date=t.meeting.meeting_date,
            end_date=t.due_date,
            status='todo',
        )
        t.save()
    return redirect(f'/projects/meetings/{t.meeting_id}/')
