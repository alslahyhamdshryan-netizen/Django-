from django.urls import path

from . import views

app_name = 'projects'

urlpatterns = [
    path('', views.project_list, name='project_list'),
    path('add/', views.project_create, name='project_create'),
    path('<int:pk>/', views.project_detail, name='project_detail'),
    path('<int:pk>/edit/', views.project_update, name='project_update'),
    path('<int:pk>/boq/', views.boq_view, name='project_boq'),
    path('<int:pk>/progress/', views.progress_view, name='project_progress'),
    path('<int:pk>/gantt/', views.gantt_view, name='project_gantt'),
    path('<int:pk>/print/', views.print_financials, name='project_print'),
    path('stages/', views.stage_list, name='stage_list'),
    path('stages/add/', views.stage_create, name='stage_create'),
    path('stages/<int:pk>/edit/', views.stage_update, name='stage_update'),
    path('boq-items/', views.boq_list, name='boq_list'),
    path('boq-items/add/', views.boq_create, name='boq_create'),
    path('boq-items/<int:pk>/edit/', views.boq_update, name='boq_update'),
    path('tasks/', views.task_list, name='task_list'),
    path('tasks/add/', views.task_create, name='task_create'),
    path('tasks/<int:pk>/edit/', views.task_update, name='task_update'),
    path('tasks/<int:pk>/move/', views.task_move, name='task_move'),
    path('daily/', views.daily_list, name='daily_list'),
    path('daily/add/', views.daily_create, name='daily_create'),
    path('daily/<int:pk>/edit/', views.daily_update, name='daily_update'),
    path('meetings/', views.meeting_list, name='meeting_list'),
    path('meetings/add/', views.meeting_create, name='meeting_create'),
    path('meetings/<int:pk>/', views.meeting_detail, name='meeting_detail'),
    path('meetings/<int:pk>/edit/', views.meeting_update, name='meeting_update'),
    path('meeting-tasks/add/', views.meeting_task_form, name='meeting_task_create'),
    path('meeting-tasks/<int:pk>/edit/', views.meeting_task_form, name='meeting_task_update'),
    path('meeting-tasks/<int:pk>/convert/', views.meeting_task_convert, name='meeting_task_convert'),
]
