from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from core.crud import crud
from core.decorators import roles
from .models import ChangeOrder, ChangeOrderItem, Contract, ContractItem, PaymentSchedule, Quote
from .services import (apply_change_order, change_order_impact,
                       create_contract_from_quote, quote_totals, refresh_quote_total)


def _next_quote_no():
    n = Quote.objects.count() + 1
    return f'Q-{timezone.localdate().year}-{n:03d}'


def _next_contract_no():
    n = Contract.objects.count() + 1
    return f'C-{timezone.localdate().year}-{n:03d}'


def _next_co_no():
    n = ChangeOrder.objects.count() + 1
    return f'CO-{timezone.localdate().year}-{n:03d}'


# ---------- عروض الأسعار ----------
def quote_list(request):
    from core.utils import field_list, row_for
    columns = field_list(Quote, ['ref_no', 'project', 'status', 'total', 'valid_until'])
    qs = Quote.objects.select_related('project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'عروض الأسعار',
        'columns': columns,
        'create_url': 'contracts:quote_create',
        'create_label': 'إضافة عرض',
        'rows': [row_for(q, columns, f'/contracts/quotes/{q.pk}/') for q in qs],
    })


def quote_form(request, pk=None):
    q = get_object_or_404(Quote, pk=pk) if pk else None
    if request.method == 'POST':
        form = QuoteForm(request.POST, instance=q)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.ref_no = _next_quote_no()
            obj.save()
            refresh_quote_total(obj)
            return redirect(f'/contracts/quotes/{obj.pk}/')
    else:
        form = QuoteForm(instance=q)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل عرض سعر' if q else 'إضافة عرض سعر',
        'form': form,
    })


from django import forms  # noqa: E402


class QuoteForm(forms.ModelForm):
    class Meta:
        model = Quote
        fields = ['project', 'valid_until', 'discount_pct', 'tax_pct', 'duration_days', 'terms', 'notes']


class ChangeOrderForm(forms.ModelForm):
    class Meta:
        model = ChangeOrder
        fields = ['contract', 'title', 'description', 'cost_delta', 'price_delta', 'days_delta', 'notes']


def quote_detail(request, pk):
    q = get_object_or_404(Quote, pk=pk)
    totals = quote_totals(q)
    items = q.project.boq_items.all()
    return render(request, 'contracts/quote_detail.html', {
        'page_title': f'عرض السعر {q.ref_no}',
        'quote': q,
        'totals': totals,
        'items': items,
    })


def quote_status(request, pk):
    q = get_object_or_404(Quote, pk=pk)
    status = request.POST.get('status')
    allowed = {'draft': ['review', 'approved'], 'review': ['approved', 'rejected'],
               'approved': ['sent'], 'sent': ['accepted', 'rejected'],
               'rejected': ['draft'], 'accepted': []}
    if status in allowed.get(q.status, []):
        q.status = status
        if status == 'accepted':
            q.accepted_at = timezone.now()
        q.save()
    return redirect(f'/contracts/quotes/{q.pk}/')


def quote_convert(request, pk):
    """تحويل عرض السعر المقبول إلى عقد."""
    q = get_object_or_404(Quote, pk=pk)
    if q.status != 'accepted':
        return render(request, 'core/generic_list.html', {'page_title': 'خطأ', 'columns': [], 'rows': [],
                                                          'error_msg': 'لا يمكن التحويل إلا لعرض مقبول'})
    if request.method == 'POST':
        contract_no = request.POST.get('contract_no') or _next_contract_no()
        from django.utils.dateparse import parse_date
        start = parse_date(request.POST.get('start_date') or '') or timezone.localdate()
        end_raw = request.POST.get('end_date')
        end = parse_date(end_raw) if end_raw else None
        c = create_contract_from_quote(q, contract_no, start, end)
        return redirect(f'/contracts/contracts/{c.pk}/')
    return render(request, 'contracts/convert_form.html', {
        'page_title': 'تحويل إلى عقد',
        'quote': q,
        'contract_no': _next_contract_no(),
        'default_end': None,
    })


# ---------- العقود ----------
def contract_list(request):
    from core.utils import field_list, row_for
    columns = field_list(Contract, ['contract_no', 'project', 'value', 'start_date', 'end_date', 'status'])
    qs = Contract.objects.select_related('project').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'العقود',
        'columns': columns,
        'create_url': 'contracts:contract_create',
        'create_label': 'إضافة عقد',
        'rows': [row_for(c, columns, f'/contracts/contracts/{c.pk}/') for c in qs],
    })


class ContractForm(forms.ModelForm):
    class Meta:
        model = Contract
        fields = ['project', 'contract_no', 'value', 'start_date', 'end_date',
                  'payment_terms', 'warranty_months', 'penalty_text', 'status', 'notes']


def contract_form(request, pk=None):
    c = get_object_or_404(Contract, pk=pk) if pk else None
    if request.method == 'POST':
        form = ContractForm(request.POST, instance=c)
        if form.is_valid():
            obj = form.save()
            if not c:
                obj.contract_no = obj.contract_no or _next_contract_no()
                obj.save()
            return redirect(f'/contracts/contracts/{obj.pk}/')
    else:
        form = ContractForm(instance=c, initial={} if c else {'contract_no': _next_contract_no()})
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل عقد' if c else 'إضافة عقد',
        'form': form,
    })


def contract_detail(request, pk):
    from finance.services import project_financials
    c = get_object_or_404(Contract, pk=pk)
    f = project_financials(c.project)
    return render(request, 'contracts/contract_detail.html', {
        'page_title': f'العقد {c.contract_no}',
        'contract': c,
        'items': c.items.all(),
        'schedules': c.schedules.all(),
        'cos': c.change_orders.all(),
        'financials': f,
        'items_total': sum((i.line_total for i in c.items.all()), 0),
    })


class ContractItemForm(forms.ModelForm):
    class Meta:
        model = ContractItem
        fields = '__all__'


def contract_item_form(request, pk=None):
    it = get_object_or_404(ContractItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = ContractItemForm(request.POST, instance=it)
        if form.is_valid():
            form.save()
            return redirect(f"/contracts/contracts/{it.contract_id}/" if it else '/contracts/')
    else:
        form = ContractItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند عقد', 'form': form})


class PaymentScheduleForm(forms.ModelForm):
    class Meta:
        model = PaymentSchedule
        fields = '__all__'


def schedule_form(request, pk=None):
    s = get_object_or_404(PaymentSchedule, pk=pk) if pk else None
    if request.method == 'POST':
        form = PaymentScheduleForm(request.POST, instance=s)
        if form.is_valid():
            form.save()
            return redirect(f"/contracts/contracts/{s.contract_id}/" if s else '/contracts/')
    else:
        form = PaymentScheduleForm(instance=s)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل دفعة' if s else 'إضافة دفعة (جدول الدفع)', 'form': form})


# ---------- أوامر التغيير ----------
def co_list(request):
    from core.utils import field_list, row_for
    columns = field_list(ChangeOrder, ['co_no', 'contract', 'title', 'price_delta', 'cost_delta', 'days_delta', 'status'])
    qs = ChangeOrder.objects.select_related('contract').order_by('-id')
    return render(request, 'core/generic_list.html', {
        'page_title': 'أوامر التغيير',
        'columns': columns,
        'create_url': 'contracts:co_create',
        'create_label': 'إضافة أمر تغيير',
        'rows': [row_for(co, columns, f'/contracts/change-orders/{co.pk}/') for co in qs],
    })


def co_form(request, pk=None):
    co = get_object_or_404(ChangeOrder, pk=pk) if pk else None
    if request.method == 'POST':
        form = ChangeOrderForm(request.POST, instance=co)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.pk:
                obj.co_no = _next_co_no()
            obj.save()
            return redirect(f'/contracts/change-orders/{obj.pk}/')
    else:
        form = ChangeOrderForm(instance=co)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل أمر تغيير' if co else 'إضافة أمر تغيير', 'form': form})


class ChangeOrderItemForm(forms.ModelForm):
    class Meta:
        model = ChangeOrderItem
        fields = '__all__'


def co_item_form(request, pk=None):
    it = get_object_or_404(ChangeOrderItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = ChangeOrderItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect(f'/contracts/change-orders/{obj.co_id}/')
    else:
        form = ChangeOrderItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند لأمر التغيير', 'form': form})


def co_detail(request, pk):
    co = get_object_or_404(ChangeOrder, pk=pk)
    impact = change_order_impact(co)
    return render(request, 'contracts/co_detail.html', {
        'page_title': f'أمر التغيير {co.co_no}',
        'co': co,
        'impact': impact,
        'items': co.items.all(),
    })


@roles('admin', 'pm', 'accountant')
def co_status(request, pk):
    co = get_object_or_404(ChangeOrder, pk=pk)
    status = request.POST.get('status')
    allowed = {'draft': ['review', 'rejected'], 'review': ['approved', 'rejected'],
               'approved': ['applied'], 'rejected': ['draft']}
    if status in allowed.get(co.status, []):
        if status == 'approved':
            co.approved_by = request.user
        co.status = status
        co.save()
    return redirect(f'/contracts/change-orders/{co.pk}/')


@roles('admin', 'pm', 'accountant')
def co_apply(request, pk):
    co = get_object_or_404(ChangeOrder, pk=pk)
    if request.method == 'POST':
        try:
            apply_change_order(co, user=request.user)
        except ValueError:
            pass
    return redirect(f'/contracts/change-orders/{co.pk}/')
