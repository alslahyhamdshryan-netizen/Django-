"""خدمات العقود: عروض الأسعار، التحويل لعقد، أوامر التغيير."""
from datetime import timedelta
from decimal import Decimal

from django.utils import timezone

from projects.services import boq_totals


def quote_totals(quote):
    """إجماليات عرض السعر من بنود BOQ للمشروع + خصم + ضريبة."""
    _cost, price, _exp = boq_totals(quote.project)
    subtotal = price
    discount = subtotal * (quote.discount_pct or 0) / 100
    taxable = subtotal - discount
    tax = taxable * (quote.tax_pct or 0) / 100
    total = taxable + tax
    return {'subtotal': subtotal, 'discount': discount, 'tax': tax, 'total': total}


def refresh_quote_total(quote):
    quote.total = quote_totals(quote)['total']
    quote.save(update_fields=['total'])
    return quote.total


def create_contract_from_quote(quote, contract_no, start_date, end_date=None):
    """تحويل عرض السعر المقبول إلى عقد: البنود + جدول دفعات افتراضي (20/40/30/10)."""
    from .models import Contract, ContractItem, PaymentSchedule

    totals = quote_totals(quote)
    if end_date is None:
        end_date = (start_date + timedelta(days=quote.duration_days or 365)) if quote.duration_days \
            else start_date + timedelta(days=365)

    contract = Contract.objects.create(
        project=quote.project,
        quote=quote,
        contract_no=contract_no,
        value=totals['total'],
        start_date=start_date,
        end_date=end_date,
        payment_terms=quote.terms or '',
        status='active',
        notes=f'مولّد من عرض السعر {quote.ref_no}',
    )

    for item in quote.project.boq_items.all():
        ContractItem.objects.create(
            contract=contract,
            boq_item=item,
            description=item.name,
            unit=item.unit,
            qty=item.qty,
            unit_cost=item.unit_cost,
            unit_price=item.unit_price,
        )

    pct_schedule = [
        ('دفعة مقدمة', 'عند توقيع العقد', 20, 0.1),
        ('دفعة تقدّم', 'عند بلوغ 50% من الإنجاز', 40, 0.5),
        ('دفعة تقدّم', 'عند بلوغ 80% من الإنجاز', 30, 0.8),
        ('الدفعة الختامية', 'عند التسليم النهائي', 10, 1.0),
    ]
    total_days = max((end_date - start_date).days, 1)
    for seq, (name, trigger, pct, fraction) in enumerate(pct_schedule, start=1):
        due = start_date + timedelta(days=int(total_days * fraction))
        PaymentSchedule.objects.create(
            contract=contract,
            seq=seq,
            name=name,
            trigger=trigger,
            pct=Decimal(pct),
            amount=contract.value * Decimal(pct) / 100,
            due_date=due,
        )

    quote.status = 'accepted'
    quote.accepted_at = timezone.now()
    quote.save()
    contract.project.status = 'in_progress'
    contract.project.save()
    return contract


def change_order_impact(co):
    """تأثير أمر التغيير على قيمة العقد والتكلفة والربح والمدة."""
    value = co.price_delta or Decimal('0')
    cost = co.cost_delta or Decimal('0')
    return {
        'value': value,
        'cost': cost,
        'profit': value - cost,
        'days': co.days_delta or 0,
        'new_value': (co.contract.value or Decimal('0')) + value,
        'new_end_date': (co.contract.end_date or timezone.localdate()) + timedelta(days=co.days_delta or 0),
    }


def apply_change_order(co, user=None):
    """اعتماد أمر التغيير: تحديث العقد (القيمة + المدة) وإضافة بنوده."""
    from .models import ContractItem
    if co.status not in ('approved', 'review'):
        raise ValueError('لا يمكن تطبيق أمر تغيير غير معتمد')
    impact = change_order_impact(co)
    co.contract.value += impact['value']
    co.contract.end_date += timedelta(days=impact['days'])
    co.contract.save()
    for it in co.items.all():
        ContractItem.objects.create(
            contract=co.contract,
            description=it.description,
            unit=it.unit,
            qty=it.qty,
            unit_cost=it.unit_cost,
            unit_price=it.unit_price,
        )
    if user is not None and co.approved_by_id is None:
        co.approved_by = user
    co.status = 'applied'
    co.applied_at = timezone.now()
    co.save()
    return co
