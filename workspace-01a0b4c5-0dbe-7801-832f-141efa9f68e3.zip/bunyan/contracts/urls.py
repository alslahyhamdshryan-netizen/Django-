from django.urls import path

from . import views

app_name = 'contracts'

urlpatterns = [
    # عروض الأسعار
    path('quotes/', views.quote_list, name='quote_list'),
    path('quotes/add/', views.quote_form, name='quote_create'),
    path('quotes/<int:pk>/', views.quote_detail, name='quote_detail'),
    path('quotes/<int:pk>/edit/', views.quote_form, name='quote_update'),
    path('quotes/<int:pk>/status/', views.quote_status, name='quote_status'),
    path('quotes/<int:pk>/convert/', views.quote_convert, name='quote_convert'),
    # العقود
    path('contracts/', views.contract_list, name='contract_list'),
    path('contracts/add/', views.contract_form, name='contract_create'),
    path('contracts/<int:pk>/', views.contract_detail, name='contract_detail'),
    path('contracts/<int:pk>/edit/', views.contract_form, name='contract_update'),
    path('items/', views.contract_item_form, name='contract_item'),
    path('items/add/', views.contract_item_form, name='contract_item_create'),
    path('items/<int:pk>/edit/', views.contract_item_form, name='contract_item_update'),
    path('schedules/', views.schedule_form, name='schedule_create'),
    path('schedules/add/', views.schedule_form, name='schedule_add'),
    path('schedules/<int:pk>/edit/', views.schedule_form, name='schedule_update'),
    # أوامر التغيير
    path('change-orders/', views.co_list, name='co_list'),
    path('change-orders/add/', views.co_form, name='co_create'),
    path('change-orders/<int:pk>/', views.co_detail, name='co_detail'),
    path('change-orders/<int:pk>/edit/', views.co_form, name='co_update'),
    path('change-orders/<int:pk>/status/', views.co_status, name='co_status'),
    path('change-orders/<int:pk>/apply/', views.co_apply, name='co_apply'),
    path('co-items/add/', views.co_item_form, name='co_item_create'),
    path('co-items/<int:pk>/edit/', views.co_item_form, name='co_item_update'),
]
