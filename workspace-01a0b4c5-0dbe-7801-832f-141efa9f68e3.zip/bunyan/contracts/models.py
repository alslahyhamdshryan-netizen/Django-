from django.db import models


class Quote(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('review', 'قيد المراجعة'),
        ('approved', 'معتمد'),
        ('sent', 'مرسل'),
        ('accepted', 'مقبول'),
        ('rejected', 'مرفوض'),
    ]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='quotes',
                                verbose_name='المشروع')
    ref_no = models.CharField('رقم العرض', max_length=30, unique=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    valid_until = models.DateField('صالح حتى', null=True, blank=True)
    discount_pct = models.DecimalField('الخصم %', max_digits=6, decimal_places=2, default=0)
    tax_pct = models.DecimalField('الضريبة %', max_digits=6, decimal_places=2, default=0)
    duration_days = models.PositiveIntegerField('مدة التنفيذ (يوم)', null=True, blank=True)
    terms = models.TextField('الشروط', blank=True)
    notes = models.TextField('ملاحظات', blank=True)
    total = models.DecimalField('الإجمالي', max_digits=16, decimal_places=2, default=0)
    accepted_at = models.DateTimeField('تاريخ القبول', null=True, blank=True)

    class Meta:
        verbose_name = 'عرض سعر'
        verbose_name_plural = 'عروض الأسعار'

    def __str__(self):
        return f'{self.ref_no} — {self.project.name}'

    @property
    def client(self):
        return self.project.client


class Contract(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('active', 'نشط'),
        ('completed', 'منتهي'),
        ('closed', 'مغلق'),
    ]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='contracts',
                                verbose_name='المشروع')
    quote = models.OneToOneField(Quote, null=True, blank=True, on_delete=models.SET_NULL,
                                 verbose_name='عرض السعر المصدر')
    contract_no = models.CharField('رقم العقد', max_length=30, unique=True)
    value = models.DecimalField('قيمة العقد', max_digits=16, decimal_places=2, default=0)
    start_date = models.DateField('تاريخ البداية')
    end_date = models.DateField('تاريخ النهاية')
    payment_terms = models.TextField('شروط الدفع', blank=True)
    warranty_months = models.PositiveIntegerField('فترة الضمان (شهر)', default=12)
    penalty_text = models.CharField('الغرامات', max_length=250, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'العقد'
        verbose_name_plural = 'العقود'

    def __str__(self):
        return f'{self.contract_no} — {self.project.name}'

    @property
    def client(self):
        return self.project.client

    @property
    def paid_amount(self):
        from finance.models import Payment
        return Payment.objects.filter(pay_type='incoming', contract=self, project=self.project)\
            .aggregate(s=models.Sum('amount'))['s'] or 0

    @property
    def remaining_amount(self):
        return self.value - self.paid_amount

    @property
    def progress(self):
        return self.project.progress

    @property
    def change_total(self):
        return ChangeOrder.objects.filter(contract=self, status='applied')\
            .aggregate(s=models.Sum('price_delta'))['s'] or 0


class ContractItem(models.Model):
    contract = models.ForeignKey(Contract, on_delete=models.CASCADE, related_name='items', verbose_name='العقد')
    boq_item = models.ForeignKey('projects.BOQItem', null=True, blank=True, on_delete=models.SET_NULL,
                                 verbose_name='بند BOQ')
    description = models.CharField('الوصف', max_length=250)
    unit = models.CharField('الوحدة', max_length=30, default='قطعة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)
    unit_price = models.DecimalField('سعر البيع (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند عقد'
        verbose_name_plural = 'بنود العقد'

    def __str__(self):
        return self.description

    @property
    def line_total(self):
        return self.qty * self.unit_price


class PaymentSchedule(models.Model):
    STATUSES = [('open', 'مفتوح'), ('partial', 'جزئي'), ('paid', 'مدفوع')]
    contract = models.ForeignKey(Contract, on_delete=models.CASCADE, related_name='schedules', verbose_name='العقد')
    seq = models.PositiveIntegerField('الترتيب', default=1)
    name = models.CharField('اسم الدفعة', max_length=100)
    trigger = models.CharField('الشرط', max_length=100, blank=True)
    pct = models.DecimalField('النسبة %', max_digits=6, decimal_places=2, default=0)
    amount = models.DecimalField('المبلغ', max_digits=16, decimal_places=2, default=0)
    due_date = models.DateField('الاستحقاق', null=True, blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    paid_amount = models.DecimalField('المسدّد', max_digits=16, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'جدول الدفعات'
        verbose_name_plural = 'جداول الدفعات'
        ordering = ['contract', 'seq']

    def __str__(self):
        return f'{self.name} ({self.pct}%)'


class ChangeOrder(models.Model):
    STATUSES = [
        ('draft', 'مسودة'),
        ('review', 'قيد المراجعة'),
        ('approved', 'معتمد'),
        ('rejected', 'مرفوض'),
        ('applied', 'تم التطبيق'),
    ]
    contract = models.ForeignKey(Contract, on_delete=models.CASCADE, related_name='change_orders', verbose_name='العقد')
    co_no = models.CharField('رقم الأمر', max_length=30, unique=True)
    title = models.CharField('العنوان', max_length=250)
    description = models.TextField('الوصف', blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='draft')
    cost_delta = models.DecimalField('التأثير على التكلفة', max_digits=16, decimal_places=2, default=0)
    price_delta = models.DecimalField('التأثير على قيمة العقد', max_digits=16, decimal_places=2, default=0)
    days_delta = models.IntegerField('التأثير على المدة (يوم)', default=0)
    approved_by = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL,
                                    verbose_name='اعتمده')
    applied_at = models.DateTimeField('تاريخ التطبيق', null=True, blank=True)
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'أمر تغيير'
        verbose_name_plural = 'أوامر التغيير'

    def __str__(self):
        return f'{self.co_no} — {self.title}'


class ChangeOrderItem(models.Model):
    co = models.ForeignKey(ChangeOrder, on_delete=models.CASCADE, related_name='items', verbose_name='أمر التغيير')
    description = models.CharField('الوصف', max_length=250)
    unit = models.CharField('الوحدة', max_length=30, default='قطعة')
    qty = models.DecimalField('الكمية', max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField('التكلفة (للوحة)', max_digits=14, decimal_places=3, default=0)
    unit_price = models.DecimalField('سعر البيع (للوحة)', max_digits=14, decimal_places=3, default=0)

    class Meta:
        verbose_name = 'بند أمر تغيير'
        verbose_name_plural = 'بنود أوامر التغيير'

    def __str__(self):
        return self.description
