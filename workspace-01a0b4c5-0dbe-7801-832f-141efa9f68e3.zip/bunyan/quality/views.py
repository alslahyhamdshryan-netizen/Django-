from django import forms
from django.shortcuts import redirect, render

from core.crud import crud as _crud
from core.utils import field_list, row_for
from .models import (ChecklistItem, ChecklistTemplate, Inspection,
                     InspectionAnswer, Incident, Issue, Risk)

checklist_list, checklist_create, checklist_update = _crud(
    ChecklistTemplate, 'قوائم الفحص', ['name', 'description'])
incident_list, incident_create, incident_update = _crud(
    Incident, 'الحوادث', ['project', 'date', 'incident_type', 'severity', 'status'],
    order_by=['-date'])
risk_list, risk_create, risk_update = _crud(
    Risk, 'المخاطر', ['project', 'description', 'likelihood', 'impact', 'owner', 'status'])

issue_list, issue_create, issue_update = _crud(
    Issue, 'المشاكل', ['project', 'title', 'priority', 'status', 'assignee', 'due_date'])


class InspectionForm(forms.ModelForm):
    class Meta:
        model = Inspection
        fields = ['project', 'stage', 'checklist', 'inspector', 'date', 'status', 'notes']


def inspection_list(request):
    columns = field_list(Inspection, ['date', 'project', 'stage', 'checklist', 'inspector', 'status'])
    qs = Inspection.objects.select_related('project').order_by('-date')
    return render(request, 'core/generic_list.html', {
        'page_title': 'الفحوصات', 'columns': columns,
        'create_url': 'quality:inspection_create', 'create_label': 'إضافة فحص',
        'rows': [row_for(i, columns) for i in qs]})


def inspection_form(request, pk=None):
    from django.shortcuts import get_object_or_404
    i = get_object_or_404(Inspection, pk=pk) if pk else None
    if request.method == 'POST':
        form = InspectionForm(request.POST, instance=i)
        if form.is_valid():
            form.save()
            return redirect('quality:inspection_list')
    else:
        form = InspectionForm(instance=i)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل فحص' if i else 'إضافة فحص جودة', 'form': form})


class AnswerForm(forms.ModelForm):
    class Meta:
        model = InspectionAnswer
        fields = '__all__'


def answer_form(request, pk=None):
    from django.shortcuts import get_object_or_404
    a = get_object_or_404(InspectionAnswer, pk=pk) if pk else None
    if request.method == 'POST':
        form = AnswerForm(request.POST, instance=a)
        if form.is_valid():
            form.save()
            return redirect('quality:inspection_list')
    else:
        form = AnswerForm(instance=a)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل إجابة' if a else 'إضافة إجابة لفحص', 'form': form})


class ChecklistItemForm(forms.ModelForm):
    class Meta:
        model = ChecklistItem
        fields = '__all__'


def checklist_item_form(request, pk=None):
    from django.shortcuts import get_object_or_404
    it = get_object_or_404(ChecklistItem, pk=pk) if pk else None
    if request.method == 'POST':
        form = ChecklistItemForm(request.POST, instance=it)
        if form.is_valid():
            obj = form.save()
            return redirect('quality:checklist_list')
    else:
        form = ChecklistItemForm(instance=it)
    return render(request, 'core/generic_form.html', {
        'form_title': 'تعديل بند' if it else 'إضافة بند لقائمة فحص', 'form': form})
