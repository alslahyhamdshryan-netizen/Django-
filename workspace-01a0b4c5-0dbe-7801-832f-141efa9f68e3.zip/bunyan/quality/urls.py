from django.urls import path

from . import views

app_name = 'quality'

urlpatterns = [
    path('checklists/', views.checklist_list, name='checklist_list'),
    path('checklists/add/', views.checklist_create, name='checklist_create'),
    path('checklists/<int:pk>/edit/', views.checklist_update, name='checklist_update'),
    path('checklist-items/add/', views.checklist_item_form, name='checklist_item_create'),
    path('checklist-items/<int:pk>/edit/', views.checklist_item_form, name='checklist_item_update'),
    path('inspections/', views.inspection_list, name='inspection_list'),
    path('inspections/add/', views.inspection_form, name='inspection_create'),
    path('inspections/<int:pk>/edit/', views.inspection_form, name='inspection_update'),
    path('inspection-answers/add/', views.answer_form, name='answer_create'),
    path('inspection-answers/<int:pk>/edit/', views.answer_form, name='answer_update'),
    path('issues/', views.issue_list, name='issue_list'),
    path('issues/add/', views.issue_create, name='issue_create'),
    path('issues/<int:pk>/edit/', views.issue_update, name='issue_update'),
    path('incidents/', views.incident_list, name='incident_list'),
    path('incidents/add/', views.incident_create, name='incident_create'),
    path('incidents/<int:pk>/edit/', views.incident_update, name='incident_update'),
    path('risks/', views.risk_list, name='risk_list'),
    path('risks/add/', views.risk_create, name='risk_create'),
    path('risks/<int:pk>/edit/', views.risk_update, name='risk_update'),
]
