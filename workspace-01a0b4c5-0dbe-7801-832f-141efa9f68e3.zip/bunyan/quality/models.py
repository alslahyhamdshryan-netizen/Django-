from django.db import models


class ChecklistTemplate(models.Model):
    name = models.CharField('اسم القائمة', max_length=150)
    description = models.TextField('الوصف', blank=True)

    class Meta:
        verbose_name = 'قائمة فحص'
        verbose_name_plural = 'قوائم الفحص'

    def __str__(self):
        return self.name


class ChecklistItem(models.Model):
    template = models.ForeignKey(ChecklistTemplate, on_delete=models.CASCADE, related_name='items', verbose_name='القائمة')
    question = models.CharField('الشرط/السؤال', max_length=250)
    order = models.PositiveIntegerField('الترتيب', default=0)

    class Meta:
        verbose_name = 'بند قائمة'
        verbose_name_plural = 'بنود القوائم'
        ordering = ['order', 'id']

    def __str__(self):
        return self.question


class Inspection(models.Model):
    STATUSES = [('pass', 'ناجح'), ('rework', 'يحتاج معالجة'), ('fail', 'مرفوض')]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='inspections', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المرحلة')
    checklist = models.ForeignKey(ChecklistTemplate, on_delete=models.PROTECT, related_name='inspections', verbose_name='القائمة')
    inspector = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='الفاحص')
    date = models.DateField('التاريخ')
    status = models.CharField('النتيجة', max_length=20, choices=STATUSES, default='pass')
    notes = models.TextField('ملاحظات', blank=True)

    class Meta:
        verbose_name = 'الفحص'
        verbose_name_plural = 'الفحوصات'
        ordering = ['-date']

    def __str__(self):
        return f'{self.checklist} — {self.date}'


class InspectionAnswer(models.Model):
    ANSWERS = [('pass', 'ناجح'), ('fail', 'غير ناجح'), ('na', 'غير منطبق')]
    inspection = models.ForeignKey(Inspection, on_delete=models.CASCADE, related_name='answers', verbose_name='الفحص')
    item = models.ForeignKey(ChecklistItem, on_delete=models.PROTECT, verbose_name='البند')
    answer = models.CharField('الإجابة', max_length=10, choices=ANSWERS, default='pass')
    note = models.CharField('ملاحظة', max_length=250, blank=True)

    class Meta:
        verbose_name = 'إجابة فحص'
        verbose_name_plural = 'إجابات الفحص'

    def __str__(self):
        return f'{self.item.question} → {self.get_answer_display()}'


class Issue(models.Model):
    PRIORITIES = [('low', 'منخفضة'), ('medium', 'متوسطة'), ('high', 'عالية'), ('critical', 'حرجة')]
    STATUSES = [('open', 'مفتوحة'), ('in_progress', 'قيد المعالجة'), ('resolved', 'تمت المعالجة'), ('closed', 'مغلقة')]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='issues', verbose_name='المشروع')
    stage = models.ForeignKey('projects.Stage', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المرحلة')
    title = models.CharField('العنوان', max_length=250)
    description = models.TextField('الوصف', blank=True)
    priority = models.CharField('الأولوية', max_length=20, choices=PRIORITIES, default='medium')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    assignee = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المسؤول')
    due_date = models.DateField('تاريخ الاستحقاق', null=True, blank=True)
    resolution = models.TextField('طريقة الحل', blank=True)

    class Meta:
        verbose_name = 'المشكلة'
        verbose_name_plural = 'المشاكل'
        ordering = ['-pk']

    def __str__(self):
        return self.title


class Incident(models.Model):
    TYPES = [('injury', 'إصابة'), ('near_miss', 'قرب حادث'), ('equipment', 'معدات'), ('environment', 'بيئة'), ('other', 'أخرى')]
    STATUSES = [('open', 'مفتوح'), ('closed', 'مغلق')]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='incidents', verbose_name='المشروع')
    date = models.DateField('التاريخ')
    incident_type = models.CharField('النوع', max_length=20, choices=TYPES, default='other')
    description = models.TextField('الوصف')
    severity = models.CharField('الخطورة', max_length=20, choices=Issue.PRIORITIES, default='medium')
    injured_count = models.PositiveIntegerField('عدد المصابين', default=0)
    corrective = models.TextField('الإجراء التصحيحي', blank=True)
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')
    closed_at = models.DateField('تاريخ الإغلاق', null=True, blank=True)
    user = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='بواسطة')

    class Meta:
        verbose_name = 'الحادث'
        verbose_name_plural = 'الحوادث'
        ordering = ['-date']

    def __str__(self):
        return f'{self.get_incident_type_display()} — {self.date}'


class Risk(models.Model):
    STATUSES = [('open', 'مفتوح'), ('mitigated', 'تم التخفيف'), ('closed', 'مغلق')]
    project = models.ForeignKey('projects.Project', on_delete=models.PROTECT, related_name='risks', verbose_name='المشروع')
    description = models.TextField('وصف الخطر')
    likelihood = models.PositiveSmallIntegerField('الاحتمالية (1-5)', default=3)
    impact = models.PositiveSmallIntegerField('الأثر (1-5)', default=3)
    preventive = models.TextField('الإجراء الوقائي', blank=True)
    owner = models.ForeignKey('core.User', null=True, blank=True, on_delete=models.SET_NULL, verbose_name='المسؤول')
    status = models.CharField('الحالة', max_length=20, choices=STATUSES, default='open')

    class Meta:
        verbose_name = 'الخطر'
        verbose_name_plural = 'المخاطر'

    def __str__(self):
        return f'{self.description[:60]}'

    @property
    def severity(self):
        return self.likelihood * self.impact
